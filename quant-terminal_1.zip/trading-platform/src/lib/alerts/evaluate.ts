// Evaluates each user's ACTIVE alerts against current data and flips
// matching ones to TRIGGERED. This runs opportunistically (page load,
// currently) rather than on a schedule — see the README for how to wire a
// cron/worker to call this on an interval instead for real-time alerting.
// SIGNAL_CHANGE, NEWS_EVENT, and EARNINGS_EVENT need a previous-state
// comparison this simple pass doesn't keep, so they're left ACTIVE with a
// note rather than guessed at.

import { prisma } from "@/lib/db/prisma";
import { getMarketDataProvider } from "@/lib/market-data";
import { getSignalForTicker } from "@/lib/ai/pipeline";
import { detectSetups } from "@/lib/ai/setups";

export async function evaluateActiveAlerts(userId: string): Promise<number> {
  const alerts = await prisma.alert.findMany({ where: { userId, status: "ACTIVE" } });
  if (alerts.length === 0) return 0;

  const provider = getMarketDataProvider();
  let triggeredCount = 0;

  for (const alert of alerts) {
    let shouldTrigger = false;
    const threshold = alert.threshold !== null ? Number(alert.threshold) : null;

    try {
      if (alert.condition === "PRICE_MOVE_PCT") {
        const quote = await provider.getQuote(alert.ticker);
        if (quote && threshold !== null && Math.abs(quote.changePct) >= threshold) shouldTrigger = true;
      } else if (alert.condition === "VOLUME_UNUSUAL") {
        const quote = await provider.getQuote(alert.ticker);
        if (quote && quote.avgVolume10d > 0) {
          const ratio = quote.volume / quote.avgVolume10d;
          if (ratio >= (threshold ?? 2)) shouldTrigger = true;
        }
      } else if (alert.condition === "OPPORTUNITY_SCORE_ABOVE") {
        const signal = await getSignalForTicker(alert.ticker);
        if (signal && threshold !== null && signal.opportunityScore >= threshold) shouldTrigger = true;
      } else if (alert.condition === "RISK_SCORE_ABOVE") {
        const signal = await getSignalForTicker(alert.ticker);
        if (signal && threshold !== null && signal.riskScore >= threshold) shouldTrigger = true;
      } else if (alert.condition === "BREAKOUT" || alert.condition === "BREAKDOWN") {
        const quote = await provider.getQuote(alert.ticker);
        const candles = await provider.getCandles(alert.ticker, "6M");
        if (quote) {
          const setups = detectSetups(alert.ticker, quote.companyName, candles);
          const wanted = alert.condition === "BREAKOUT" ? "Potential Breakout" : "Potential Breakdown";
          if (setups.some((s) => s.setupType === wanted)) shouldTrigger = true;
        }
      }
    } catch {
      continue; // unknown ticker or transient error — leave alert active
    }

    if (shouldTrigger) {
      await prisma.alert.update({ where: { id: alert.id }, data: { status: "TRIGGERED", triggeredAt: new Date() } });
      triggeredCount++;
    }
  }

  return triggeredCount;
}
