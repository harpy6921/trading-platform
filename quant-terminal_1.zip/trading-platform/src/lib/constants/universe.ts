// The fixed universe of symbols DEMO MODE knows about. A live provider
// would not need this file at all — it would resolve any valid ticker
// against the vendor's own symbol master.

export interface UniverseEntry {
  ticker: string;
  companyName: string;
  sector: Sector;
  industry: string;
  basePrice: number; // seed price the deterministic generator walks from
  baseVolatility: number; // daily stdev, as a fraction (e.g. 0.02 = 2%)
  baseVolume: number;
}

export const SECTORS = [
  "Technology",
  "Healthcare",
  "Financials",
  "Energy",
  "Consumer Discretionary",
  "Consumer Staples",
  "Industrials",
  "Utilities",
  "Real Estate",
  "Communication Services",
] as const;

export type Sector = (typeof SECTORS)[number];

export const UNIVERSE: UniverseEntry[] = [
  { ticker: "AAPL", companyName: "Apple Inc.", sector: "Technology", industry: "Consumer Electronics", basePrice: 228, baseVolatility: 0.016, baseVolume: 55_000_000 },
  { ticker: "MSFT", companyName: "Microsoft Corp.", sector: "Technology", industry: "Software", basePrice: 421, baseVolatility: 0.014, baseVolume: 21_000_000 },
  { ticker: "NVDA", companyName: "NVIDIA Corp.", sector: "Technology", industry: "Semiconductors", basePrice: 118, baseVolatility: 0.031, baseVolume: 210_000_000 },
  { ticker: "GOOGL", companyName: "Alphabet Inc.", sector: "Communication Services", industry: "Internet Content", basePrice: 172, baseVolatility: 0.018, baseVolume: 28_000_000 },
  { ticker: "AMZN", companyName: "Amazon.com Inc.", sector: "Consumer Discretionary", industry: "Internet Retail", basePrice: 186, baseVolatility: 0.019, baseVolume: 34_000_000 },
  { ticker: "META", companyName: "Meta Platforms Inc.", sector: "Communication Services", industry: "Internet Content", basePrice: 512, baseVolatility: 0.022, baseVolume: 15_000_000 },
  { ticker: "TSLA", companyName: "Tesla Inc.", sector: "Consumer Discretionary", industry: "Auto Manufacturers", basePrice: 238, baseVolatility: 0.038, baseVolume: 92_000_000 },
  { ticker: "AVGO", companyName: "Broadcom Inc.", sector: "Technology", industry: "Semiconductors", basePrice: 168, baseVolatility: 0.021, baseVolume: 24_000_000 },
  { ticker: "AMD", companyName: "Advanced Micro Devices", sector: "Technology", industry: "Semiconductors", basePrice: 148, baseVolatility: 0.029, baseVolume: 48_000_000 },
  { ticker: "NFLX", companyName: "Netflix Inc.", sector: "Communication Services", industry: "Entertainment", basePrice: 685, baseVolatility: 0.023, baseVolume: 4_200_000 },
  { ticker: "JPM", companyName: "JPMorgan Chase & Co.", sector: "Financials", industry: "Banks", basePrice: 214, baseVolatility: 0.014, baseVolume: 9_000_000 },
  { ticker: "BAC", companyName: "Bank of America Corp.", sector: "Financials", industry: "Banks", basePrice: 41, baseVolatility: 0.016, baseVolume: 38_000_000 },
  { ticker: "GS", companyName: "Goldman Sachs Group", sector: "Financials", industry: "Capital Markets", basePrice: 512, baseVolatility: 0.017, baseVolume: 2_100_000 },
  { ticker: "V", companyName: "Visa Inc.", sector: "Financials", industry: "Payments", basePrice: 278, baseVolatility: 0.012, baseVolume: 5_800_000 },
  { ticker: "XOM", companyName: "Exxon Mobil Corp.", sector: "Energy", industry: "Oil & Gas", basePrice: 112, baseVolatility: 0.017, baseVolume: 15_000_000 },
  { ticker: "CVX", companyName: "Chevron Corp.", sector: "Energy", industry: "Oil & Gas", basePrice: 152, baseVolatility: 0.016, baseVolume: 8_500_000 },
  { ticker: "UNH", companyName: "UnitedHealth Group", sector: "Healthcare", industry: "Managed Care", basePrice: 588, baseVolatility: 0.018, baseVolume: 3_200_000 },
  { ticker: "LLY", companyName: "Eli Lilly and Co.", sector: "Healthcare", industry: "Pharmaceuticals", basePrice: 812, baseVolatility: 0.021, baseVolume: 2_600_000 },
  { ticker: "JNJ", companyName: "Johnson & Johnson", sector: "Healthcare", industry: "Pharmaceuticals", basePrice: 162, baseVolatility: 0.011, baseVolume: 6_400_000 },
  { ticker: "PG", companyName: "Procter & Gamble Co.", sector: "Consumer Staples", industry: "Household Products", basePrice: 168, baseVolatility: 0.010, baseVolume: 6_100_000 },
  { ticker: "KO", companyName: "Coca-Cola Co.", sector: "Consumer Staples", industry: "Beverages", basePrice: 68, baseVolatility: 0.009, baseVolume: 12_000_000 },
  { ticker: "WMT", companyName: "Walmart Inc.", sector: "Consumer Staples", industry: "Discount Stores", basePrice: 82, baseVolatility: 0.012, baseVolume: 16_000_000 },
  { ticker: "CAT", companyName: "Caterpillar Inc.", sector: "Industrials", industry: "Machinery", basePrice: 372, baseVolatility: 0.018, baseVolume: 2_400_000 },
  { ticker: "BA", companyName: "Boeing Co.", sector: "Industrials", industry: "Aerospace & Defense", basePrice: 178, baseVolatility: 0.027, baseVolume: 8_600_000 },
  { ticker: "NEE", companyName: "NextEra Energy", sector: "Utilities", industry: "Electric Utilities", basePrice: 74, baseVolatility: 0.013, baseVolume: 9_400_000 },
  { ticker: "DUK", companyName: "Duke Energy Corp.", sector: "Utilities", industry: "Electric Utilities", basePrice: 112, baseVolatility: 0.010, baseVolume: 3_100_000 },
  { ticker: "PLD", companyName: "Prologis Inc.", sector: "Real Estate", industry: "Industrial REITs", basePrice: 118, baseVolatility: 0.016, baseVolume: 3_900_000 },
  { ticker: "AMT", companyName: "American Tower Corp.", sector: "Real Estate", industry: "Specialized REITs", basePrice: 208, baseVolatility: 0.015, baseVolume: 1_900_000 },
  { ticker: "CRM", companyName: "Salesforce Inc.", sector: "Technology", industry: "Software", basePrice: 258, baseVolatility: 0.020, baseVolume: 5_200_000 },
  { ticker: "ORCL", companyName: "Oracle Corp.", sector: "Technology", industry: "Software", basePrice: 168, baseVolatility: 0.019, baseVolume: 8_100_000 },
  { ticker: "ADBE", companyName: "Adobe Inc.", sector: "Technology", industry: "Software", basePrice: 512, baseVolatility: 0.020, baseVolume: 2_800_000 },
  { ticker: "INTC", companyName: "Intel Corp.", sector: "Technology", industry: "Semiconductors", basePrice: 22, baseVolatility: 0.030, baseVolume: 68_000_000 },
  { ticker: "DIS", companyName: "Walt Disney Co.", sector: "Communication Services", industry: "Entertainment", basePrice: 96, baseVolatility: 0.018, baseVolume: 9_800_000 },
  { ticker: "PFE", companyName: "Pfizer Inc.", sector: "Healthcare", industry: "Pharmaceuticals", basePrice: 26, baseVolatility: 0.016, baseVolume: 34_000_000 },
  { ticker: "COST", companyName: "Costco Wholesale Corp.", sector: "Consumer Staples", industry: "Discount Stores", basePrice: 912, baseVolatility: 0.014, baseVolume: 1_800_000 },
  { ticker: "HD", companyName: "Home Depot Inc.", sector: "Consumer Discretionary", industry: "Home Improvement Retail", basePrice: 382, baseVolatility: 0.013, baseVolume: 2_900_000 },
  { ticker: "MCD", companyName: "McDonald's Corp.", sector: "Consumer Discretionary", industry: "Restaurants", basePrice: 292, baseVolatility: 0.011, baseVolume: 2_400_000 },
  { ticker: "T", companyName: "AT&T Inc.", sector: "Communication Services", industry: "Telecom", basePrice: 21, baseVolatility: 0.013, baseVolume: 32_000_000 },
  { ticker: "SO", companyName: "Southern Co.", sector: "Utilities", industry: "Electric Utilities", basePrice: 88, baseVolatility: 0.010, baseVolume: 4_400_000 },
];

export const INDEX_DEFS = [
  { symbol: "SPX", label: "S&P 500", basePrice: 5615 },
  { symbol: "NDX", label: "Nasdaq 100", basePrice: 19870 },
  { symbol: "DJI", label: "Dow Jones", basePrice: 41250 },
  { symbol: "RUT", label: "Russell 2000", basePrice: 2215 },
  { symbol: "VIX", label: "VIX", basePrice: 14.8 },
] as const;

export function findUniverseEntry(ticker: string): UniverseEntry | undefined {
  return UNIVERSE.find((u) => u.ticker.toUpperCase() === ticker.toUpperCase());
}
