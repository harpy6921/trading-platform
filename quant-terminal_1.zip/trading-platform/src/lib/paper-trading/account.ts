import { prisma } from "@/lib/db/prisma";

const DEFAULT_STARTING_BALANCE = 100_000;

export async function getOrCreatePrimaryAccount(userId: string) {
  const existing = await prisma.paperAccount.findFirst({ where: { userId }, orderBy: { createdAt: "asc" } });
  if (existing) return existing;
  return prisma.paperAccount.create({
    data: {
      userId,
      name: "Paper Account",
      startingBalance: DEFAULT_STARTING_BALANCE,
      cashBalance: DEFAULT_STARTING_BALANCE,
      commissionPerOrder: 0,
      slippageBps: 5,
    },
  });
}
