import { Prisma, OrderSide, OrderStatus, OrderType } from "@prisma/client";
import { prisma } from "@/lib/db/prisma";
import { getMarketDataProvider } from "@/lib/market-data";

export interface PlaceOrderParams {
  accountId: string;
  ticker: string;
  side: "BUY" | "SELL";
  type: "MARKET" | "LIMIT";
  quantity: number;
  limitPrice?: number;
}

export class PaperTradingError extends Error {}

/**
 * Simulates a fill against the current DEMO/live quote, applies commission
 * and optional slippage (basis points, configured per account), updates
 * the position's average cost basis, and — for closing SELL orders —
 * records realized P&L. Everything happens in one DB transaction so the
 * cash balance, position, and order row can never drift out of sync.
 */
export async function placePaperOrder(params: PlaceOrderParams) {
  const provider = getMarketDataProvider();
  const quote = await provider.getQuote(params.ticker);
  if (!quote) {
    throw new PaperTradingError(`Unknown or unsupported ticker "${params.ticker}".`);
  }
  if (params.quantity <= 0) {
    throw new PaperTradingError("Quantity must be greater than zero.");
  }

  return prisma.$transaction(async (tx) => {
    const account = await tx.paperAccount.findUnique({ where: { id: params.accountId } });
    if (!account) throw new PaperTradingError("Paper trading account not found.");

    const slippageFactor = account.slippageBps / 10000;
    let referencePrice = quote.price;

    if (params.type === "LIMIT") {
      if (!params.limitPrice || params.limitPrice <= 0) {
        throw new PaperTradingError("Limit orders require a positive limit price.");
      }
      const marketableForBuy = params.side === "BUY" && quote.price <= params.limitPrice;
      const marketableForSell = params.side === "SELL" && quote.price >= params.limitPrice;
      if (!marketableForBuy && !marketableForSell) {
        // Not immediately marketable — recorded as a resting/rejected order
        // rather than silently no-op'ing, since this is a simplified
        // simulator without an order book to hold it open on.
        const rejected = await tx.paperOrder.create({
          data: {
            accountId: account.id,
            ticker: params.ticker.toUpperCase(),
            side: params.side as OrderSide,
            type: params.type as OrderType,
            quantity: new Prisma.Decimal(params.quantity),
            limitPrice: new Prisma.Decimal(params.limitPrice),
            status: OrderStatus.REJECTED,
          },
        });
        throw new PaperTradingError(
          `Limit price not marketable against the current quote (${quote.price.toFixed(2)}). Order ${rejected.id} recorded as rejected.`
        );
      }
      referencePrice = params.limitPrice;
    }

    // Slippage always works against the trader: buys fill slightly higher, sells slightly lower.
    const fillPrice =
      params.side === "BUY" ? referencePrice * (1 + slippageFactor) : referencePrice * (1 - slippageFactor);
    const roundedFill = Math.round(fillPrice * 10000) / 10000;
    const commission = Number(account.commissionPerOrder);
    const grossValue = roundedFill * params.quantity;

    const existingPosition = await tx.paperPosition.findUnique({
      where: { accountId_ticker: { accountId: account.id, ticker: params.ticker.toUpperCase() } },
    });

    let realizedPnl: number | null = null;

    if (params.side === "BUY") {
      const totalCost = grossValue + commission;
      if (totalCost > Number(account.cashBalance)) {
        throw new PaperTradingError(
          `Insufficient buying power: order requires ~$${totalCost.toFixed(2)}, cash available is $${Number(account.cashBalance).toFixed(2)}.`
        );
      }

      if (existingPosition) {
        const oldQty = Number(existingPosition.quantity);
        const oldCost = Number(existingPosition.avgCostBasis);
        const newQty = oldQty + params.quantity;
        const newAvgCost = (oldQty * oldCost + params.quantity * roundedFill) / newQty;
        await tx.paperPosition.update({
          where: { id: existingPosition.id },
          data: { quantity: new Prisma.Decimal(newQty), avgCostBasis: new Prisma.Decimal(newAvgCost) },
        });
      } else {
        await tx.paperPosition.create({
          data: {
            accountId: account.id,
            ticker: params.ticker.toUpperCase(),
            quantity: new Prisma.Decimal(params.quantity),
            avgCostBasis: new Prisma.Decimal(roundedFill),
          },
        });
      }

      await tx.paperAccount.update({
        where: { id: account.id },
        data: { cashBalance: new Prisma.Decimal(Number(account.cashBalance) - totalCost) },
      });
    } else {
      // SELL
      const heldQty = existingPosition ? Number(existingPosition.quantity) : 0;
      if (params.quantity > heldQty) {
        throw new PaperTradingError(
          `Cannot sell ${params.quantity} shares of ${params.ticker}: only ${heldQty} held in this account.`
        );
      }
      const costBasis = existingPosition ? Number(existingPosition.avgCostBasis) : 0;
      realizedPnl = (roundedFill - costBasis) * params.quantity - commission;
      const proceeds = grossValue - commission;

      const remainingQty = heldQty - params.quantity;
      if (existingPosition) {
        if (remainingQty <= 0) {
          await tx.paperPosition.delete({ where: { id: existingPosition.id } });
        } else {
          await tx.paperPosition.update({
            where: { id: existingPosition.id },
            data: { quantity: new Prisma.Decimal(remainingQty) },
          });
        }
      }

      await tx.paperAccount.update({
        where: { id: account.id },
        data: { cashBalance: new Prisma.Decimal(Number(account.cashBalance) + proceeds) },
      });
    }

    const order = await tx.paperOrder.create({
      data: {
        accountId: account.id,
        ticker: params.ticker.toUpperCase(),
        side: params.side as OrderSide,
        type: params.type as OrderType,
        quantity: new Prisma.Decimal(params.quantity),
        limitPrice: params.limitPrice ? new Prisma.Decimal(params.limitPrice) : null,
        fillPrice: new Prisma.Decimal(roundedFill),
        commission: new Prisma.Decimal(commission),
        status: OrderStatus.FILLED,
        filledAt: new Date(),
        realizedPnl: realizedPnl !== null ? new Prisma.Decimal(realizedPnl) : null,
      },
    });

    return order;
  });
}

/** Marks-to-market every open position and returns total account equity (cash + positions). */
export async function computePortfolioValue(accountId: string) {
  const provider = getMarketDataProvider();
  const account = await prisma.paperAccount.findUniqueOrThrow({ where: { id: accountId } });
  const positions = await prisma.paperPosition.findMany({ where: { accountId } });

  const quotes = await provider.getQuotes(positions.map((p) => p.ticker));
  const quoteByTicker = new Map(quotes.map((q) => [q.ticker, q]));

  const positionValues = positions.map((p) => {
    const quote = quoteByTicker.get(p.ticker);
    const price = quote?.price ?? Number(p.avgCostBasis);
    const qty = Number(p.quantity);
    const marketValue = price * qty;
    const costBasis = Number(p.avgCostBasis) * qty;
    return {
      ticker: p.ticker,
      quantity: qty,
      avgCostBasis: Number(p.avgCostBasis),
      currentPrice: price,
      marketValue,
      unrealizedPnl: marketValue - costBasis,
      unrealizedPnlPct: costBasis > 0 ? (marketValue - costBasis) / costBasis : 0,
      changePct: quote?.changePct ?? 0,
      dataSource: quote?.source ?? "demo",
    };
  });

  const positionsValue = positionValues.reduce((s, p) => s + p.marketValue, 0);
  const cash = Number(account.cashBalance);
  const equity = cash + positionsValue;
  const startingBalance = Number(account.startingBalance);

  return {
    accountId,
    cash,
    positionsValue,
    equity,
    totalReturn: equity - startingBalance,
    totalReturnPct: startingBalance > 0 ? (equity - startingBalance) / startingBalance : 0,
    positions: positionValues,
  };
}
