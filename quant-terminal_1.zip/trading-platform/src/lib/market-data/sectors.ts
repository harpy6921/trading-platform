import { getMarketDataProvider } from "@/lib/market-data";
import { SECTORS, type Sector } from "@/lib/constants/universe";
import type { ScreenerRow } from "@/lib/market-data/types";

export interface SectorBreakdown {
  sector: Sector;
  avgChangePct: number;
  avgVolatility: number;
  count: number;
  strongest: ScreenerRow[];
  weakest: ScreenerRow[];
}

export async function getSectorBreakdown(): Promise<SectorBreakdown[]> {
  const provider = getMarketDataProvider();
  const rows = await provider.getScreenerUniverse();

  return SECTORS.map((sector) => {
    const members = rows.filter((r) => r.sector === sector);
    if (members.length === 0) {
      return { sector, avgChangePct: 0, avgVolatility: 0, count: 0, strongest: [], weakest: [] };
    }
    const avgChangePct = members.reduce((s, m) => s + m.changePct, 0) / members.length;
    const avgVolatility = members.reduce((s, m) => s + m.volatility30d, 0) / members.length;
    const sorted = [...members].sort((a, b) => b.changePct - a.changePct);
    return {
      sector,
      avgChangePct,
      avgVolatility,
      count: members.length,
      strongest: sorted.slice(0, 3),
      weakest: sorted.slice(-3).reverse(),
    };
  }).sort((a, b) => b.avgChangePct - a.avgChangePct);
}

export function summarizeSectorLeadership(breakdown: SectorBreakdown[]): string {
  const leaders = breakdown.slice(0, 2).filter((b) => b.count > 0);
  const laggards = breakdown.slice(-2).filter((b) => b.count > 0);
  if (leaders.length === 0) return "Data unavailable.";
  const leaderText = leaders.map((l) => `${l.sector} (${l.avgChangePct >= 0 ? "+" : ""}${l.avgChangePct.toFixed(2)}%)`).join(", ");
  const laggardText = laggards.map((l) => `${l.sector} (${l.avgChangePct >= 0 ? "+" : ""}${l.avgChangePct.toFixed(2)}%)`).join(", ");
  return `Based on today's average change per sector, ${leaderText} are showing the strongest conditions, while ${laggardText} are showing the weakest. This reflects same-session price action only, not a forward-looking call.`;
}
