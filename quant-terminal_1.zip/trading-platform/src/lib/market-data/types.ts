// Core types for the market-data abstraction layer.
// Every provider (demo or live) implements MarketDataProvider and returns
// these shapes, so nothing above this layer needs to know or care which
// backend actually supplied the numbers — it only needs to check `.source`.

export type DataSource = "demo" | "live" | "delayed";

export interface Quote {
  ticker: string;
  companyName: string;
  price: number;
  change: number;
  changePct: number;
  volume: number;
  avgVolume10d: number;
  marketCap: number | null;
  dayHigh: number;
  dayLow: number;
  prevClose: number;
  updatedAt: string; // ISO timestamp
  source: DataSource;
}

export interface Candle {
  time: number; // unix seconds
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export type ChartRange = "1D" | "5D" | "1M" | "3M" | "6M" | "1Y" | "5Y";

export interface IndexQuote {
  symbol: string; // e.g. "SPX"
  label: string; // e.g. "S&P 500"
  value: number;
  change: number;
  changePct: number;
  intraday: { time: number; value: number }[];
  source: DataSource;
}

export interface MoverEntry {
  ticker: string;
  companyName: string;
  price: number;
  changePct: number;
  volume: number;
}

export interface MarketMovers {
  gainers: MoverEntry[];
  losers: MoverEntry[];
  mostActive: MoverEntry[];
  highestVolume: MoverEntry[];
  source: DataSource;
}

export interface Fundamentals {
  ticker: string;
  peRatio: number | null;
  forwardPe: number | null;
  epsTtm: number | null;
  revenueGrowthYoy: number | null; // fraction, e.g. 0.12
  earningsGrowthYoy: number | null;
  grossMargin: number | null;
  debtToEquity: number | null;
  dividendYield: number | null;
  beta: number | null;
  sector: string;
  industry: string;
  source: DataSource;
}

export type NewsSentiment =
  | "very_bullish"
  | "bullish"
  | "neutral"
  | "bearish"
  | "very_bearish";

export interface NewsItem {
  id: string;
  ticker: string | null;
  headline: string;
  source: string;
  publishedAt: string;
  sentiment: NewsSentiment;
  url: string;
  dataSource: DataSource;
}

export interface EarningsEvent {
  ticker: string;
  companyName: string;
  date: string; // ISO date
  timeOfDay: "before_open" | "after_close" | "unknown";
  epsEstimate: number | null;
  revenueEstimateM: number | null;
  source: DataSource;
}

export interface ScreenerRow {
  ticker: string;
  companyName: string;
  sector: string;
  price: number;
  changePct: number;
  marketCap: number | null;
  volume: number;
  rsi14: number;
  aboveSma50: boolean;
  aboveSma200: boolean;
  volatility30d: number;
  earningsGrowthYoy: number | null;
  revenueGrowthYoy: number | null;
  peRatio: number | null;
  newsSentimentScore: number; // -2..2
}

/**
 * Every adapter (demo, or a future live vendor such as Polygon/IEX/Alpaca)
 * implements this single interface. Route handlers and server components
 * only ever talk to `getMarketDataProvider()` from ./index.ts — never to a
 * concrete class — so swapping providers never touches page code.
 */
export interface MarketDataProvider {
  readonly source: DataSource;
  getQuote(ticker: string): Promise<Quote | null>;
  getQuotes(tickers: string[]): Promise<Quote[]>;
  getCandles(ticker: string, range: ChartRange): Promise<Candle[]>;
  getIndices(): Promise<IndexQuote[]>;
  getMovers(): Promise<MarketMovers>;
  getFundamentals(ticker: string): Promise<Fundamentals | null>;
  getNews(params: { ticker?: string; sector?: string; limit?: number }): Promise<NewsItem[]>;
  getEarningsCalendar(daysAhead: number): Promise<EarningsEvent[]>;
  getScreenerUniverse(): Promise<ScreenerRow[]>;
  searchSymbols(query: string): Promise<{ ticker: string; companyName: string; type: "stock" | "etf" }[]>;
}
