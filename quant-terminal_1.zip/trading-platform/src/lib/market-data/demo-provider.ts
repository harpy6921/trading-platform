// DEMO MODE provider.
//
// Every number produced here is synthetic. Nothing in this file talks to
// the network. It exists so the whole application — dashboard through
// paper trading — is fully navigable with zero API keys configured, and so
// every page has a concrete shape to render before a real vendor is wired
// in. Every payload carries `source: "demo"`, and the UI is required to
// render a visible DEMO MODE badge whenever that source appears (see
// components/layout/DemoModeBanner.tsx and the per-card badges).
//
// This file must never be reachable when MARKET_DATA_PROVIDER points at a
// live adapter — see ./index.ts for the switch.

import {
  UNIVERSE,
  INDEX_DEFS,
  SECTORS,
  findUniverseEntry,
  type UniverseEntry,
} from "@/lib/constants/universe";
import { dailySeed, hashString, mulberry32, gaussian } from "./rng";
import { rsi, sma, realizedVolatility, last } from "@/lib/indicators";
import type {
  MarketDataProvider,
  Quote,
  Candle,
  ChartRange,
  IndexQuote,
  MarketMovers,
  MoverEntry,
  Fundamentals,
  NewsItem,
  NewsSentiment,
  EarningsEvent,
  ScreenerRow,
} from "./types";

const TRADING_DAYS_HISTORY = 5 * 252; // ~5 years

// ── History cache (per process) ──────────────────────────────────────
// Historical shape is seeded by ticker only, so it stays stable across
// requests; only "today's" final bar is reseeded daily, which is what
// makes the demo market feel like it moves session to session.
const historyCache = new Map<string, Candle[]>();

function buildHistory(entry: UniverseEntry): Candle[] {
  const cached = historyCache.get(entry.ticker);
  if (cached) return cached;

  const rng = mulberry32(hashString(`hist:${entry.ticker}`));
  const candles: Candle[] = [];
  let price = entry.basePrice * 0.55; // start lower so history shows a broad uptrend like a real multi-year chart
  const drift = 0.00035; // slight long-run upward drift
  const now = new Date();

  for (let i = TRADING_DAYS_HISTORY; i >= 1; i--) {
    const date = new Date(now);
    date.setUTCDate(date.getUTCDate() - i);
    // skip weekends
    const day = date.getUTCDay();
    if (day === 0 || day === 6) continue;

    const shock = gaussian(rng) * entry.baseVolatility;
    const ret = drift + shock;
    const open = price;
    price = Math.max(0.5, price * (1 + ret));
    const close = price;
    const high = Math.max(open, close) * (1 + Math.abs(gaussian(rng)) * entry.baseVolatility * 0.4);
    const low = Math.min(open, close) * (1 - Math.abs(gaussian(rng)) * entry.baseVolatility * 0.4);
    const volume = Math.max(
      10_000,
      Math.round(entry.baseVolume * (0.6 + rng() * 0.8))
    );

    candles.push({
      time: Math.floor(date.getTime() / 1000),
      open: round2(open),
      high: round2(high),
      low: round2(low),
      close: round2(close),
      volume,
    });
  }

  historyCache.set(entry.ticker, candles);
  return candles;
}

function todaysCandle(entry: UniverseEntry, priorClose: number): Candle {
  const rng = mulberry32(dailySeed(`today:${entry.ticker}`));
  const shock = gaussian(rng) * entry.baseVolatility;
  const open = priorClose * (1 + gaussian(rng) * entry.baseVolatility * 0.2);
  const close = Math.max(0.5, open * (1 + shock));
  const high = Math.max(open, close) * (1 + Math.abs(gaussian(rng)) * entry.baseVolatility * 0.3);
  const low = Math.min(open, close) * (1 - Math.abs(gaussian(rng)) * entry.baseVolatility * 0.3);
  const volume = Math.max(
    10_000,
    Math.round(entry.baseVolume * (0.7 + rng() * 0.9))
  );
  const now = new Date();
  return {
    time: Math.floor(now.getTime() / 1000),
    open: round2(open),
    high: round2(high),
    low: round2(low),
    close: round2(close),
    volume,
  };
}

function fullSeries(entry: UniverseEntry): Candle[] {
  const hist = buildHistory(entry);
  const priorClose = hist[hist.length - 1]?.close ?? entry.basePrice;
  const today = todaysCandle(entry, priorClose);
  return [...hist, today];
}

function intradayBars(entry: UniverseEntry, todayOpen: number, todayClose: number): Candle[] {
  const rng = mulberry32(dailySeed(`intraday:${entry.ticker}`));
  const bars: Candle[] = [];
  const barsCount = 78; // 6.5h session in 5-minute bars
  const now = new Date();
  const marketOpen = new Date(now);
  marketOpen.setUTCHours(13, 30, 0, 0); // 9:30 ET in UTC (approx, ignoring DST)

  let price = todayOpen;
  const totalDrift = (todayClose - todayOpen) / barsCount;

  for (let i = 0; i < barsCount; i++) {
    const t = new Date(marketOpen.getTime() + i * 5 * 60 * 1000);
    const noise = gaussian(rng) * entry.baseVolatility * 0.12 * todayOpen;
    price = Math.max(0.5, price + totalDrift + noise);
    const open = price;
    const wiggle = Math.abs(gaussian(rng)) * entry.baseVolatility * 0.06 * todayOpen;
    bars.push({
      time: Math.floor(t.getTime() / 1000),
      open: round2(open),
      high: round2(open + wiggle),
      low: round2(Math.max(0.5, open - wiggle)),
      close: round2(open),
      volume: Math.max(1000, Math.round((entry.baseVolume / barsCount) * (0.5 + rng()))),
    });
  }
  // force the final bar to close exactly at todayClose so intraday + daily agree
  if (bars.length > 0) {
    bars[bars.length - 1]!.close = round2(todayClose);
  }
  return bars;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

function toQuote(entry: UniverseEntry): Quote {
  const series = fullSeries(entry);
  const todayC = series[series.length - 1]!;
  const prevC = series[series.length - 2] ?? todayC;
  const closes = series.map((c) => c.close);
  const avgVol10 =
    series.slice(-11, -1).reduce((sum, c) => sum + c.volume, 0) / Math.max(1, series.slice(-11, -1).length);

  const rng = mulberry32(hashString(`mcap:${entry.ticker}`));
  const sharesOutstandingB = 0.3 + rng() * 8; // billions, purely illustrative

  return {
    ticker: entry.ticker,
    companyName: entry.companyName,
    price: todayC.close,
    change: round2(todayC.close - prevC.close),
    changePct: round2(((todayC.close - prevC.close) / prevC.close) * 100),
    volume: todayC.volume,
    avgVolume10d: Math.round(avgVol10),
    marketCap: Math.round(todayC.close * sharesOutstandingB * 1_000_000_000),
    dayHigh: todayC.high,
    dayLow: todayC.low,
    prevClose: prevC.close,
    updatedAt: new Date().toISOString(),
    source: "demo",
  };
}

function newsSentimentBank(): Record<NewsSentiment, string[]> {
  return {
    very_bullish: [
      "{company} shares surge after results top expectations across every key metric",
      "Analysts pile on upgrades for {company} citing accelerating demand",
      "{company} guidance raise sends shares to fresh highs",
    ],
    bullish: [
      "{company} beats on revenue as {industry} demand stays resilient",
      "{company} announces buyback expansion, signaling management confidence",
      "Momentum builds in {sector} names including {company}",
    ],
    neutral: [
      "{company} holds an industry conference; no material guidance change",
      "{company} in line with estimates as {sector} sector treads water",
      "Analysts maintain existing ratings on {company} ahead of earnings",
    ],
    bearish: [
      "{company} flags softening demand in latest channel checks",
      "{company} shares slip as {sector} sector rotation weighs",
      "Competitive pressure cited as headwind for {company}",
    ],
    very_bearish: [
      "{company} slashes guidance, citing broad-based weakness",
      "Regulatory scrutiny intensifies around {company} operations",
      "{company} shares tumble on downgrade wave following disappointing print",
    ],
  };
}

function generateNewsForTicker(entry: UniverseEntry, count: number): NewsItem[] {
  const rng = mulberry32(dailySeed(`news:${entry.ticker}`));
  const bank = newsSentimentBank();
  const sentiments: NewsSentiment[] = [
    "very_bullish",
    "bullish",
    "neutral",
    "bearish",
    "very_bearish",
  ];
  const sources = ["MarketPulse Wire", "Ledger Daily", "Desk Notes", "Sector Brief", "Tape Read"];
  const items: NewsItem[] = [];
  for (let i = 0; i < count; i++) {
    const sentiment = sentiments[Math.floor(rng() * sentiments.length)]!;
    const templates = bank[sentiment];
    const template = templates[Math.floor(rng() * templates.length)]!;
    const headline = template
      .replaceAll("{company}", entry.companyName)
      .replaceAll("{sector}", entry.sector)
      .replaceAll("{industry}", entry.industry);
    const hoursAgo = Math.floor(rng() * 72);
    const publishedAt = new Date(Date.now() - hoursAgo * 3600 * 1000).toISOString();
    items.push({
      id: `${entry.ticker}-${i}-${hoursAgo}`,
      ticker: entry.ticker,
      headline,
      source: sources[Math.floor(rng() * sources.length)]!,
      publishedAt,
      sentiment,
      url: "#",
      dataSource: "demo",
    });
  }
  return items.sort((a, b) => (a.publishedAt < b.publishedAt ? 1 : -1));
}

function sentimentScore(sentiment: NewsSentiment): number {
  return { very_bullish: 2, bullish: 1, neutral: 0, bearish: -1, very_bearish: -2 }[sentiment];
}

function buildFundamentals(entry: UniverseEntry): Fundamentals {
  const rng = mulberry32(hashString(`fund:${entry.ticker}`));
  const sectorPeBase: Partial<Record<string, number>> = {
    Technology: 32,
    "Communication Services": 24,
    "Consumer Discretionary": 26,
    Healthcare: 22,
    Financials: 13,
    Energy: 11,
    "Consumer Staples": 21,
    Industrials: 19,
    Utilities: 18,
    "Real Estate": 17,
  };
  const peBase = sectorPeBase[entry.sector] ?? 20;
  const peRatio = round2(peBase * (0.6 + rng() * 0.9));
  const growthBase = entry.sector === "Technology" || entry.sector === "Consumer Discretionary" ? 0.14 : 0.05;

  return {
    ticker: entry.ticker,
    peRatio,
    forwardPe: round2(peRatio * (0.82 + rng() * 0.2)),
    epsTtm: round2(entry.basePrice / peRatio),
    revenueGrowthYoy: round4(growthBase + (rng() - 0.4) * 0.15),
    earningsGrowthYoy: round4(growthBase + (rng() - 0.4) * 0.22),
    grossMargin: round4(0.3 + rng() * 0.45),
    debtToEquity: round2(rng() * 1.6),
    dividendYield: entry.sector === "Utilities" || entry.sector === "Energy" ? round4(0.02 + rng() * 0.03) : round4(rng() * 0.015),
    beta: round2(0.6 + rng() * 1.1),
    sector: entry.sector,
    industry: entry.industry,
    source: "demo",
  };
}

function round4(n: number): number {
  return Math.round(n * 10000) / 10000;
}

export class DemoMarketDataProvider implements MarketDataProvider {
  readonly source = "demo" as const;

  async getQuote(ticker: string): Promise<Quote | null> {
    const entry = findUniverseEntry(ticker);
    if (!entry) return null;
    return toQuote(entry);
  }

  async getQuotes(tickers: string[]): Promise<Quote[]> {
    const results: Quote[] = [];
    for (const t of tickers) {
      const entry = findUniverseEntry(t);
      if (entry) results.push(toQuote(entry));
    }
    return results;
  }

  async getCandles(ticker: string, range: ChartRange): Promise<Candle[]> {
    const entry = findUniverseEntry(ticker);
    if (!entry) return [];
    const series = fullSeries(entry);

    if (range === "1D") {
      const today = series[series.length - 1]!;
      return intradayBars(entry, today.open, today.close);
    }

    const daysByRange: Record<Exclude<ChartRange, "1D">, number> = {
      "5D": 5,
      "1M": 22,
      "3M": 66,
      "6M": 132,
      "1Y": 252,
      "5Y": TRADING_DAYS_HISTORY,
    };
    const n = daysByRange[range];
    return series.slice(-n);
  }

  async getIndices(): Promise<IndexQuote[]> {
    return INDEX_DEFS.map((def) => {
      const rng = mulberry32(dailySeed(`index:${def.symbol}`));
      const histRng = mulberry32(hashString(`indexhist:${def.symbol}`));
      let price = def.basePrice * 0.85;
      const vol = def.symbol === "VIX" ? 0.06 : 0.009;
      // walk a short history for continuity, then today
      for (let i = 0; i < 60; i++) {
        price = price * (1 + gaussian(histRng) * vol + 0.0002);
      }
      const prevClose = price;
      const changePct = gaussian(rng) * (def.symbol === "VIX" ? 5 : 0.9);
      const value = prevClose * (1 + changePct / 100);

      const intraday: { time: number; value: number }[] = [];
      const marketOpen = new Date();
      marketOpen.setUTCHours(13, 30, 0, 0);
      let p = prevClose;
      const stepDrift = (value - prevClose) / 78;
      for (let i = 0; i < 78; i++) {
        p = p + stepDrift + gaussian(rng) * vol * prevClose * 0.15;
        intraday.push({
          time: Math.floor(marketOpen.getTime() / 1000) + i * 5 * 60,
          value: Math.round(p * 100) / 100,
        });
      }
      if (intraday.length) intraday[intraday.length - 1]!.value = Math.round(value * 100) / 100;

      return {
        symbol: def.symbol,
        label: def.label,
        value: round2(value),
        change: round2(value - prevClose),
        changePct: round2(changePct),
        intraday,
        source: "demo" as const,
      };
    });
  }

  async getMovers(): Promise<MarketMovers> {
    const quotes = UNIVERSE.map((e) => toQuote(e));
    const toEntry = (q: Quote): MoverEntry => ({
      ticker: q.ticker,
      companyName: q.companyName,
      price: q.price,
      changePct: q.changePct,
      volume: q.volume,
    });

    const gainers = [...quotes].sort((a, b) => b.changePct - a.changePct).slice(0, 8).map(toEntry);
    const losers = [...quotes].sort((a, b) => a.changePct - b.changePct).slice(0, 8).map(toEntry);
    const mostActive = [...quotes]
      .sort((a, b) => b.volume / b.avgVolume10d - a.volume / a.avgVolume10d)
      .slice(0, 8)
      .map(toEntry);
    const highestVolume = [...quotes].sort((a, b) => b.volume - a.volume).slice(0, 8).map(toEntry);

    return { gainers, losers, mostActive, highestVolume, source: "demo" };
  }

  async getFundamentals(ticker: string): Promise<Fundamentals | null> {
    const entry = findUniverseEntry(ticker);
    if (!entry) return null;
    return buildFundamentals(entry);
  }

  async getNews(params: { ticker?: string; sector?: string; limit?: number }): Promise<NewsItem[]> {
    const limit = params.limit ?? 30;
    let entries = UNIVERSE;
    if (params.ticker) {
      const e = findUniverseEntry(params.ticker);
      entries = e ? [e] : [];
    } else if (params.sector) {
      entries = UNIVERSE.filter((e) => e.sector === params.sector);
    }
    const all = entries.flatMap((e) => generateNewsForTicker(e, params.ticker ? 12 : 3));
    return all.sort((a, b) => (a.publishedAt < b.publishedAt ? 1 : -1)).slice(0, limit);
  }

  async getEarningsCalendar(daysAhead: number): Promise<EarningsEvent[]> {
    const events: EarningsEvent[] = [];
    for (const entry of UNIVERSE) {
      const rng = mulberry32(hashString(`earnings:${entry.ticker}`));
      const offsetDays = Math.floor(rng() * 75); // cycles roughly quarterly
      if (offsetDays > daysAhead) continue;
      const date = new Date();
      date.setUTCDate(date.getUTCDate() + offsetDays);
      const fundamentals = buildFundamentals(entry);
      events.push({
        ticker: entry.ticker,
        companyName: entry.companyName,
        date: date.toISOString().slice(0, 10),
        timeOfDay: rng() > 0.5 ? "after_close" : "before_open",
        epsEstimate: fundamentals.epsTtm ? round2(fundamentals.epsTtm / 4) : null,
        revenueEstimateM: Math.round(entry.baseVolume * entry.basePrice * 0.00004),
        source: "demo",
      });
    }
    return events.sort((a, b) => (a.date > b.date ? 1 : -1));
  }

  async getScreenerUniverse(): Promise<ScreenerRow[]> {
    const rows: ScreenerRow[] = [];
    for (const entry of UNIVERSE) {
      const series = fullSeries(entry);
      const closes = series.map((c) => c.close);
      const quote = toQuote(entry);
      const fundamentals = buildFundamentals(entry);
      const sma50 = last(sma(closes, 50));
      const sma200 = last(sma(closes, 200));
      const rsi14 = last(rsi(closes, 14)) ?? 50;
      const vol30 = realizedVolatility(closes, 30);
      const news = generateNewsForTicker(entry, 5);
      const newsSentimentScore =
        news.reduce((sum, n) => sum + sentimentScore(n.sentiment), 0) / news.length;

      rows.push({
        ticker: entry.ticker,
        companyName: entry.companyName,
        sector: entry.sector,
        price: quote.price,
        changePct: quote.changePct,
        marketCap: quote.marketCap,
        volume: quote.volume,
        rsi14: round2(rsi14),
        aboveSma50: sma50 !== null ? quote.price > sma50 : false,
        aboveSma200: sma200 !== null ? quote.price > sma200 : false,
        volatility30d: round4(vol30),
        earningsGrowthYoy: fundamentals.earningsGrowthYoy,
        revenueGrowthYoy: fundamentals.revenueGrowthYoy,
        peRatio: fundamentals.peRatio,
        newsSentimentScore: round2(newsSentimentScore),
      });
    }
    return rows;
  }

  async searchSymbols(query: string) {
    const q = query.trim().toUpperCase();
    if (!q) return [];
    return UNIVERSE.filter(
      (e) => e.ticker.includes(q) || e.companyName.toUpperCase().includes(q)
    )
      .slice(0, 10)
      .map((e) => ({ ticker: e.ticker, companyName: e.companyName, type: "stock" as const }));
  }
}

export { SECTORS };
