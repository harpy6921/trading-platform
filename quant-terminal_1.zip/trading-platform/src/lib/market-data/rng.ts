// A small seeded PRNG (mulberry32) plus a string hash, used so every piece
// of DEMO MODE data is *deterministic* — the same ticker on the same day
// always produces the same quote, chart, and fundamentals within a given
// process, rather than jumping around on every re-render. Re-seeding by
// calendar day gives the appearance of a market that moves session to
// session, exactly like a real feed would, without ever being random junk.

export function hashString(input: string): number {
  let h = 2166136261;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export function mulberry32(seed: number): () => number {
  let a = seed;
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/** Seed that changes once per UTC day, so "today's" demo market is stable. */
export function dailySeed(key: string): number {
  const day = new Date().toISOString().slice(0, 10);
  return hashString(`${key}:${day}`);
}

/** Standard-normal sample via Box-Muller, driven by a supplied RNG. */
export function gaussian(rng: () => number): number {
  const u1 = Math.max(rng(), 1e-9);
  const u2 = rng();
  return Math.sqrt(-2 * Math.log(u1)) * Math.cos(2 * Math.PI * u2);
}
