import { DemoMarketDataProvider } from "./demo-provider";
import type { MarketDataProvider } from "./types";

// Every route handler and server component calls getMarketDataProvider()
// and never imports a concrete adapter directly. That is the entire
// contract that lets a real vendor replace demo data later without
// touching a single page or API route.
//
// To add a live vendor:
//   1. Create src/lib/market-data/<vendor>-provider.ts implementing
//      MarketDataProvider, reading MARKET_DATA_API_KEY /
//      MARKET_DATA_BASE_URL from process.env (server-side only).
//   2. Add a case below.
//   3. Set MARKET_DATA_PROVIDER=<vendor> and the credentials in .env.
//
// If a live adapter throws or is missing required env vars, we
// intentionally do NOT silently fall back to demo data — that would
// risk presenting synthetic numbers as real. Instead the route handler
// should surface the error; see src/lib/utils/api.ts for the shared
// error envelope.

let cached: MarketDataProvider | null = null;

export function getMarketDataProvider(): MarketDataProvider {
  if (cached) return cached;

  const providerName = (process.env.MARKET_DATA_PROVIDER || "demo").toLowerCase();

  switch (providerName) {
    case "demo":
      cached = new DemoMarketDataProvider();
      return cached;

    // case "polygon":
    //   return new PolygonMarketDataProvider({
    //     apiKey: requireEnv("MARKET_DATA_API_KEY"),
    //     baseUrl: process.env.MARKET_DATA_BASE_URL ?? "https://api.polygon.io",
    //   });

    default:
      throw new Error(
        `Unknown MARKET_DATA_PROVIDER "${providerName}". Set it to "demo", or ` +
          `implement and register a live adapter in src/lib/market-data/index.ts.`
      );
  }
}

export function isDemoMode(): boolean {
  return getMarketDataProvider().source === "demo";
}

export * from "./types";
