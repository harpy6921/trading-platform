// A deliberately simple, transparent backtester: one position at a time,
// full account equity allocated per trade, no leverage, no shorting. It
// exists to let a user sanity-check a rule idea against history — not to
// simulate a real portfolio (that's what the paper-trading engine is for).
// Every number reported is computed directly from the candles passed in;
// nothing here is fabricated, and a strategy that produces zero trades is
// reported as zero trades rather than padded with a synthetic result.

import { sma, rsi, realizedVolatility } from "@/lib/indicators";
import type { Candle } from "@/lib/market-data/types";

export type StrategyType = "sma_crossover" | "rsi_reversion" | "momentum" | "volume_breakout";

export interface BacktestConfig {
  strategy: StrategyType;
  params: Record<string, number>;
  exitHoldingDays: number; // max bars to hold a position regardless of signal
}

export interface BacktestTrade {
  entryDate: string;
  exitDate: string;
  entryPrice: number;
  exitPrice: number;
  returnPct: number;
  barsHeld: number;
}

export interface BacktestResult {
  trades: BacktestTrade[];
  totalReturnPct: number;
  winRate: number;
  avgTradeReturnPct: number;
  maxDrawdownPct: number;
  profitFactor: number | null;
  equityCurve: { date: string; equity: number }[];
  warnings: string[];
}

function toISODate(unixSeconds: number): string {
  return new Date(unixSeconds * 1000).toISOString().slice(0, 10);
}

function entrySignals(candles: Candle[], config: BacktestConfig): boolean[] {
  const closes = candles.map((c) => c.close);
  const n = candles.length;
  const signals = new Array(n).fill(false);

  if (config.strategy === "sma_crossover") {
    const fast = sma(closes, config.params.fastPeriod ?? 20);
    const slow = sma(closes, config.params.slowPeriod ?? 50);
    for (let i = 1; i < n; i++) {
      if (fast[i] === null || slow[i] === null || fast[i - 1] === null || slow[i - 1] === null) continue;
      if (fast[i - 1]! <= slow[i - 1]! && fast[i]! > slow[i]!) signals[i] = true;
    }
  } else if (config.strategy === "rsi_reversion") {
    const series = rsi(closes, config.params.period ?? 14);
    const oversold = config.params.oversold ?? 30;
    for (let i = 1; i < n; i++) {
      if (series[i] === null || series[i - 1] === null) continue;
      if (series[i - 1]! < oversold && series[i]! >= oversold) signals[i] = true;
    }
  } else if (config.strategy === "momentum") {
    const lookback = config.params.lookbackDays ?? 10;
    const thresholdPct = config.params.thresholdPct ?? 3;
    for (let i = lookback; i < n; i++) {
      const ret = ((closes[i]! - closes[i - lookback]!) / closes[i - lookback]!) * 100;
      if (ret >= thresholdPct) signals[i] = true;
    }
  } else if (config.strategy === "volume_breakout") {
    const multiplier = config.params.volumeMultiplier ?? 1.8;
    const lookback = 20;
    for (let i = lookback; i < n; i++) {
      const window = candles.slice(i - lookback, i);
      const avgVol = window.reduce((s, c) => s + c.volume, 0) / window.length;
      const rangeHigh = Math.max(...window.map((c) => c.high));
      if (candles[i]!.volume > avgVol * multiplier && candles[i]!.close > rangeHigh) signals[i] = true;
    }
  }

  return signals;
}

export function runBacktest(candles: Candle[], config: BacktestConfig): BacktestResult {
  const warnings: string[] = [];
  if (candles.length < 80) {
    warnings.push("Limited history available — results from short histories are especially prone to overfitting.");
  }

  const signals = entrySignals(candles, config);
  const trades: BacktestTrade[] = [];

  let equity = 10_000;
  const equityCurve: { date: string; equity: number }[] = [];
  let peak = equity;
  let maxDrawdownPct = 0;

  let i = 0;
  while (i < candles.length) {
    equityCurve.push({ date: toISODate(candles[i]!.time), equity });
    peak = Math.max(peak, equity);
    const drawdown = peak > 0 ? ((peak - equity) / peak) * 100 : 0;
    maxDrawdownPct = Math.max(maxDrawdownPct, drawdown);

    if (signals[i]) {
      const entryIdx = i;
      const entryPrice = candles[entryIdx]!.open;
      const maxExitIdx = Math.min(candles.length - 1, entryIdx + config.exitHoldingDays);
      const exitIdx = maxExitIdx;
      const exitPrice = candles[exitIdx]!.close;
      const returnPct = ((exitPrice - entryPrice) / entryPrice) * 100;

      trades.push({
        entryDate: toISODate(candles[entryIdx]!.time),
        exitDate: toISODate(candles[exitIdx]!.time),
        entryPrice,
        exitPrice,
        returnPct,
        barsHeld: exitIdx - entryIdx,
      });

      equity = equity * (1 + returnPct / 100);
      i = exitIdx + 1; // one position at a time
    } else {
      i++;
    }
  }

  const wins = trades.filter((t) => t.returnPct > 0);
  const losses = trades.filter((t) => t.returnPct <= 0);
  const grossProfit = wins.reduce((s, t) => s + t.returnPct, 0);
  const grossLoss = Math.abs(losses.reduce((s, t) => s + t.returnPct, 0));

  if (trades.length === 0) {
    warnings.push("No trades were triggered by this rule over the selected history — try loosening the parameters.");
  }
  if (trades.length > 0 && trades.length < 15) {
    warnings.push("Fewer than 15 trades — win rate and average return are not statistically meaningful at this sample size.");
  }
  warnings.push(
    "Survivorship bias: this backtest only runs against a security that exists and trades today, which tends to flatter historical strategy results."
  );

  return {
    trades,
    totalReturnPct: ((equity - 10_000) / 10_000) * 100,
    winRate: trades.length ? (wins.length / trades.length) * 100 : 0,
    avgTradeReturnPct: trades.length ? trades.reduce((s, t) => s + t.returnPct, 0) / trades.length : 0,
    maxDrawdownPct,
    profitFactor: grossLoss > 0 ? grossProfit / grossLoss : null,
    equityCurve,
    warnings,
  };
}
