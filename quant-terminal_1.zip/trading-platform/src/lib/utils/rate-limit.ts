// A minimal fixed-window rate limiter. Good enough for a single-process
// deployment and for local development; it deliberately keeps no external
// dependency so the app runs with zero infra beyond Postgres. If you scale
// to multiple instances, swap the Map below for Redis (INCR + EXPIRE) —
// the call sites (checkRateLimit) do not need to change.

const WINDOW_MS = 60_000;
const buckets = new Map<string, { count: number; resetAt: number }>();

export interface RateLimitResult {
  allowed: boolean;
  remaining: number;
  resetAt: number;
}

export function checkRateLimit(key: string, limitPerMinute: number): RateLimitResult {
  const now = Date.now();
  const bucket = buckets.get(key);

  if (!bucket || now > bucket.resetAt) {
    buckets.set(key, { count: 1, resetAt: now + WINDOW_MS });
    return { allowed: true, remaining: limitPerMinute - 1, resetAt: now + WINDOW_MS };
  }

  if (bucket.count >= limitPerMinute) {
    return { allowed: false, remaining: 0, resetAt: bucket.resetAt };
  }

  bucket.count += 1;
  return { allowed: true, remaining: limitPerMinute - bucket.count, resetAt: bucket.resetAt };
}

export function clientKeyFromRequest(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  return forwarded?.split(",")[0]?.trim() || "unknown";
}
