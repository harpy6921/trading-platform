import { NextResponse } from "next/server";
import { ZodError } from "zod";
import { UnauthorizedError } from "@/lib/auth/session";
import { PaperTradingError } from "@/lib/paper-trading/engine";
import { checkRateLimit, clientKeyFromRequest } from "./rate-limit";

export function ok<T>(data: T, init?: number) {
  return NextResponse.json({ ok: true, data }, { status: init ?? 200 });
}

export function fail(message: string, status = 400, details?: unknown) {
  return NextResponse.json({ ok: false, error: message, details }, { status });
}

/**
 * Wraps a route handler with: rate limiting, consistent error → HTTP status
 * mapping, and logging. Every API route in this app should be wrapped with
 * this rather than hand-rolling try/catch, so error handling is uniform.
 */
export function withRoute(
  handler: (req: Request, ctx: { params: Record<string, string> }) => Promise<Response>,
  opts: { rateLimitPerMinute?: number } = {}
) {
  return async (req: Request, ctx: { params: Record<string, string> }) => {
    if (opts.rateLimitPerMinute) {
      const key = `${clientKeyFromRequest(req)}:${new URL(req.url).pathname}`;
      const result = checkRateLimit(key, opts.rateLimitPerMinute);
      if (!result.allowed) {
        return fail("Rate limit exceeded. Please slow down.", 429, {
          resetAt: new Date(result.resetAt).toISOString(),
        });
      }
    }

    try {
      return await handler(req, ctx);
    } catch (err) {
      if (err instanceof UnauthorizedError) return fail(err.message, 401);
      if (err instanceof PaperTradingError) return fail(err.message, 422);
      if (err instanceof ZodError) return fail("Invalid request.", 400, err.flatten());
      // eslint-disable-next-line no-console
      console.error("[api_error]", err);
      return fail("Internal server error.", 500);
    }
  };
}
