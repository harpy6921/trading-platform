import { getMarketDataProvider } from "@/lib/market-data";
import { realizedVolatility } from "@/lib/indicators";
import type { ScreenerRow } from "@/lib/market-data/types";

export interface PortfolioObservation {
  kind: "concentration" | "sector" | "volatility" | "diversification" | "correlation";
  severity: "info" | "notice" | "warning";
  text: string;
}

export interface PositionInput {
  ticker: string;
  marketValue: number;
}

export async function analyzePortfolio(positions: PositionInput[], equity: number): Promise<PortfolioObservation[]> {
  const observations: PortfolioObservation[] = [];
  if (positions.length === 0) {
    return [{ kind: "diversification", severity: "info", text: "No open positions yet — observations will appear once the paper account holds at least one position." }];
  }

  const provider = getMarketDataProvider();
  const universe = await provider.getScreenerUniverse();
  const bySector = new Map<string, ScreenerRow>(universe.map((r) => [r.ticker, r]));

  // Concentration: any single position over 25% of equity
  for (const p of positions) {
    const weight = equity > 0 ? p.marketValue / equity : 0;
    if (weight > 0.25) {
      observations.push({
        kind: "concentration",
        severity: weight > 0.4 ? "warning" : "notice",
        text: `${p.ticker} makes up ${(weight * 100).toFixed(0)}% of total equity — a single-name move in ${p.ticker} will disproportionately move the whole account.`,
      });
    }
  }

  // Sector exposure
  const sectorWeights = new Map<string, number>();
  for (const p of positions) {
    const sector = bySector.get(p.ticker)?.sector ?? "Unknown";
    const weight = equity > 0 ? p.marketValue / equity : 0;
    sectorWeights.set(sector, (sectorWeights.get(sector) ?? 0) + weight);
  }
  for (const [sector, weight] of sectorWeights) {
    if (weight > 0.4) {
      const tickers = positions.filter((p) => (bySector.get(p.ticker)?.sector ?? "Unknown") === sector).map((p) => p.ticker);
      observations.push({
        kind: "sector",
        severity: weight > 0.6 ? "warning" : "notice",
        text: `${(weight * 100).toFixed(0)}% of equity is concentrated in ${sector} (${tickers.join(", ")}) — a sector-wide move would affect these positions together.`,
      });
    }
  }

  // Diversification
  if (positions.length < 3) {
    observations.push({
      kind: "diversification",
      severity: "notice",
      text: `Only ${positions.length} open position${positions.length === 1 ? "" : "s"} — a small number of names means less diversification against single-stock risk.`,
    });
  }

  // Volatility
  const avgVol =
    positions.reduce((s, p) => s + (bySector.get(p.ticker)?.volatility30d ?? 0), 0) / positions.length;
  if (avgVol > 0.4) {
    observations.push({
      kind: "volatility",
      severity: "notice",
      text: `Average 30-day volatility across current holdings is ${(avgVol * 100).toFixed(0)}%, on the higher end — expect wider day-to-day swings in account value.`,
    });
  }

  return observations;
}

/** Pairwise Pearson correlation of daily returns, for up to 8 held tickers. */
export async function computeCorrelationMatrix(tickers: string[]): Promise<{ tickers: string[]; matrix: number[][] } | null> {
  const limited = tickers.slice(0, 8);
  if (limited.length < 2) return null;

  const provider = getMarketDataProvider();
  const seriesByTicker = await Promise.all(
    limited.map(async (t) => {
      const candles = await provider.getCandles(t, "3M");
      const closes = candles.map((c) => c.close);
      const returns: number[] = [];
      for (let i = 1; i < closes.length; i++) returns.push((closes[i]! - closes[i - 1]!) / closes[i - 1]!);
      return returns;
    })
  );

  const n = Math.min(...seriesByTicker.map((s) => s.length));
  const trimmed = seriesByTicker.map((s) => s.slice(-n));

  function correlation(a: number[], b: number[]): number {
    const meanA = a.reduce((x, y) => x + y, 0) / a.length;
    const meanB = b.reduce((x, y) => x + y, 0) / b.length;
    let cov = 0,
      varA = 0,
      varB = 0;
    for (let i = 0; i < a.length; i++) {
      cov += (a[i]! - meanA) * (b[i]! - meanB);
      varA += (a[i]! - meanA) ** 2;
      varB += (b[i]! - meanB) ** 2;
    }
    const denom = Math.sqrt(varA * varB);
    return denom === 0 ? 0 : cov / denom;
  }

  const matrix = trimmed.map((a) => trimmed.map((b) => Math.round(correlation(a, b) * 100) / 100));
  return { tickers: limited, matrix };
}

// realizedVolatility import kept for potential direct callers/tests
export { realizedVolatility };
