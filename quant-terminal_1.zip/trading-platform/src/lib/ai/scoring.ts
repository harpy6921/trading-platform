// The numerical half of the AI pipeline described in the product brief:
//   Market Data → Technical Indicators → Fundamentals → News/Sentiment →
//   Sector/Market Context → Feature Engineering → Scoring Model → (signal)
//
// Everything in this file is deterministic arithmetic over real inputs —
// there is no call to a language model here, and nothing is invented. The
// language model (see ./explain.ts) only ever narrates numbers this file
// already computed; it never sees raw prices and is never allowed to
// produce a number itself. That separation is intentional and load-bearing
// for the "never fabricate" requirement: if this file has no data for a
// factor, it returns null and the explainer must say so.

import { ema, macd, rsi, sma, bollingerBands, realizedVolatility, last } from "@/lib/indicators";
import type { Candle, Fundamentals, NewsItem } from "@/lib/market-data/types";
import type {
  FeatureSnapshot,
  SignalLabel,
  RiskLevel,
  TimeHorizon,
  ScenarioCase,
  MarketRegimeLabel,
} from "@/types";

export const MODEL_VERSION = "quant-terminal-scoring-v0.3.0-demo";

function sentimentToScore(items: NewsItem[]): number {
  if (items.length === 0) return 0;
  const map: Record<string, number> = {
    very_bullish: 2,
    bullish: 1,
    neutral: 0,
    bearish: -1,
    very_bearish: -2,
  };
  const sum = items.reduce((s, n) => s + (map[n.sentiment] ?? 0), 0);
  return sum / items.length;
}

export function buildFeatureSnapshot(params: {
  candles: Candle[];
  fundamentals: Fundamentals | null;
  news: NewsItem[];
  sectorReturnPct: number; // sector's own trailing return, for relative-strength comparison
  regime: MarketRegimeLabel;
}): FeatureSnapshot {
  const { candles, fundamentals, news, sectorReturnPct, regime } = params;
  const closes = candles.map((c) => c.close);
  const price = closes[closes.length - 1] ?? 0;

  const sma50Series = sma(closes, 50);
  const sma200Series = sma(closes, 200);
  const sma50 = last(sma50Series);
  const sma200 = last(sma200Series);
  const rsi14 = last(rsi(closes, 14));
  const macdResult = macd(closes);
  const macdHistogram = last(macdResult.histogram);
  const bands = bollingerBands(closes, 20, 2);
  const upper = last(bands.upper);
  const lower = last(bands.lower);
  const middle = last(bands.middle);

  let bollingerPosition: FeatureSnapshot["bollingerPosition"] = "lower_half";
  if (upper !== null && price >= upper) bollingerPosition = "above_upper";
  else if (lower !== null && price <= lower) bollingerPosition = "below_lower";
  else if (middle !== null && price >= middle) bollingerPosition = "upper_half";
  else bollingerPosition = "lower_half";

  let smaTrend: FeatureSnapshot["smaTrend"] = "below_both";
  if (sma50 !== null && sma200 !== null) {
    if (price > sma50 && price > sma200) smaTrend = "above_both";
    else if (price > sma50 && price <= sma200) smaTrend = "above_50_below_200";
    else if (price <= sma50 && price > sma200) smaTrend = "below_50_above_200";
    else smaTrend = "below_both";
  }

  const volatility30d = realizedVolatility(closes, 30);

  const recent10 = candles.slice(-10);
  const avgVol10 =
    recent10.length > 1
      ? recent10.slice(0, -1).reduce((s, c) => s + c.volume, 0) / (recent10.length - 1)
      : candles[candles.length - 1]?.volume ?? 1;
  const latestVolume = candles[candles.length - 1]?.volume ?? 0;
  const volumeVsAvg = avgVol10 > 0 ? latestVolume / avgVol10 : 1;

  // trailing 21-session return for the ticker, to compare against sector
  const lookback = Math.min(21, closes.length - 1);
  const tickerReturnPct =
    lookback > 0 ? ((price - closes[closes.length - 1 - lookback]!) / closes[closes.length - 1 - lookback]!) * 100 : 0;
  const sectorRelativeStrength = (tickerReturnPct - sectorReturnPct) / 100;

  return {
    price,
    rsi14,
    macdHistogram,
    smaTrend,
    bollingerPosition,
    volatility30d,
    volumeVsAvg,
    newsSentimentScore: sentimentToScore(news),
    sectorRelativeStrength,
    earningsGrowthYoy: fundamentals?.earningsGrowthYoy ?? null,
    revenueGrowthYoy: fundamentals?.revenueGrowthYoy ?? null,
    peRatio: fundamentals?.peRatio ?? null,
    marketRegime: regime,
  };
}

interface WeightedFactor {
  name: string;
  score: number; // -1..1
  weight: number;
}

/** Returns the weighted factor breakdown so reasons/explanations can cite exactly what moved the needle. */
export function scoreFactors(f: FeatureSnapshot): WeightedFactor[] {
  const factors: WeightedFactor[] = [];

  // Technical: trend
  const trendScore =
    f.smaTrend === "above_both" ? 1 : f.smaTrend === "above_50_below_200" ? 0.3 : f.smaTrend === "below_50_above_200" ? -0.3 : -1;
  factors.push({ name: "Price vs. moving averages", score: trendScore, weight: 0.18 });

  // Technical: RSI — reward oversold-recovering / penalize overbought, mild U-shape
  let rsiScore = 0;
  if (f.rsi14 !== null) {
    if (f.rsi14 >= 70) rsiScore = -0.6;
    else if (f.rsi14 <= 30) rsiScore = 0.5;
    else rsiScore = (f.rsi14 - 50) / 50; // mild trend-following in the middle band
  }
  factors.push({ name: "RSI(14) positioning", score: rsiScore, weight: 0.12 });

  // Technical: MACD histogram sign/magnitude
  const macdScore = f.macdHistogram !== null ? Math.max(-1, Math.min(1, f.macdHistogram / (0.02 * f.price || 1))) : 0;
  factors.push({ name: "MACD momentum", score: macdScore, weight: 0.14 });

  // Technical: Bollinger position
  const bbScore =
    f.bollingerPosition === "above_upper" ? -0.3 : f.bollingerPosition === "upper_half" ? 0.4 : f.bollingerPosition === "lower_half" ? -0.4 : 0.2;
  factors.push({ name: "Bollinger Band position", score: bbScore, weight: 0.08 });

  // Volume confirmation
  const volScore = Math.max(-1, Math.min(1, (f.volumeVsAvg - 1) * 0.8));
  factors.push({ name: "Volume vs. 10-day average", score: volScore, weight: 0.08 });

  // Fundamentals
  const growthScore =
    f.earningsGrowthYoy !== null ? Math.max(-1, Math.min(1, f.earningsGrowthYoy * 4)) : 0;
  factors.push({ name: "Earnings growth (YoY)", score: growthScore, weight: 0.12 });

  const revScore = f.revenueGrowthYoy !== null ? Math.max(-1, Math.min(1, f.revenueGrowthYoy * 5)) : 0;
  factors.push({ name: "Revenue growth (YoY)", score: revScore, weight: 0.08 });

  // News sentiment
  factors.push({ name: "News sentiment", score: f.newsSentimentScore / 2, weight: 0.1 });

  // Sector relative strength
  factors.push({
    name: "Relative strength vs. sector",
    score: Math.max(-1, Math.min(1, f.sectorRelativeStrength * 8)),
    weight: 0.1,
  });

  return factors;
}

function regimeAdjustment(regime: MarketRegimeLabel): number {
  // A small dampener/booster applied to the composite score, reflecting how
  // reliable bullish setups tend to be in each broad regime. This never
  // flips a signal on its own — it nudges confidence.
  switch (regime) {
    case "Bullish":
      return 0.06;
    case "Bearish":
      return -0.08;
    case "High Volatility":
      return -0.1;
    case "Transitional":
      return -0.03;
    case "Neutral":
    default:
      return 0;
  }
}

export interface ScoreOutput {
  composite: number; // -1..1
  factors: WeightedFactor[];
  signal: SignalLabel;
  confidence: number;
  riskLevel: RiskLevel;
  timeHorizon: TimeHorizon;
  topReasons: string[];
}

export function computeScore(f: FeatureSnapshot): ScoreOutput {
  const factors = scoreFactors(f);
  const totalWeight = factors.reduce((s, x) => s + x.weight, 0);
  const weighted = factors.reduce((s, x) => s + x.score * x.weight, 0) / totalWeight;
  const composite = Math.max(-1, Math.min(1, weighted + regimeAdjustment(f.marketRegime)));

  let signal: SignalLabel;
  if (composite >= 0.45) signal = "STRONG_BUY";
  else if (composite >= 0.15) signal = "BUY";
  else if (composite > -0.15) signal = "HOLD";
  else if (composite > -0.45) signal = "SELL";
  else signal = "STRONG_SELL";

  // Confidence reflects both how far from neutral the composite sits and
  // how much the individual factors agree with each other (low dispersion
  // = higher confidence that this isn't just one noisy input).
  const mean = factors.reduce((s, x) => s + x.score, 0) / factors.length;
  const variance = factors.reduce((s, x) => s + (x.score - mean) ** 2, 0) / factors.length;
  const agreement = Math.max(0, 1 - Math.sqrt(variance));
  const magnitude = Math.abs(composite);
  const confidence = Math.round(Math.max(35, Math.min(95, 40 + magnitude * 45 + agreement * 15)));

  const riskLevel: RiskLevel =
    f.volatility30d > 0.55 || f.marketRegime === "High Volatility"
      ? "High"
      : f.volatility30d > 0.35
        ? "Elevated"
        : f.volatility30d > 0.2
          ? "Moderate"
          : "Low";

  const timeHorizon: TimeHorizon =
    Math.abs(composite) > 0.4 ? "Swing (1-4 weeks)" : magnitude > 0.15 ? "Position (1-6 months)" : "Short-term (days)";

  const topReasons = [...factors]
    .sort((a, b) => Math.abs(b.score * b.weight) - Math.abs(a.score * a.weight))
    .slice(0, 4)
    .map((x) => describeFactor(x));

  return { composite, factors, signal, confidence, riskLevel, timeHorizon, topReasons };
}

function describeFactor(x: WeightedFactor): string {
  const direction = x.score > 0.05 ? "supportive" : x.score < -0.05 ? "unfavorable" : "neutral";
  return `${x.name}: ${direction} (factor score ${x.score.toFixed(2)})`;
}

/** 0-100 opportunity score — emphasizes bullish composite, fundamentals, and momentum agreement. */
export function computeOpportunityScore(f: FeatureSnapshot, score: ScoreOutput): number {
  if (score.composite <= 0) return Math.max(0, Math.round(20 + score.composite * 40));
  const base = score.composite * 100;
  const growthBoost = (f.earningsGrowthYoy ?? 0) > 0.1 ? 6 : 0;
  const volumeBoost = f.volumeVsAvg > 1.3 ? 5 : 0;
  return Math.max(0, Math.min(100, Math.round(base * 0.85 + growthBoost + volumeBoost + 10)));
}

/** 0-100 risk score — emphasizes bearish composite, volatility, and deteriorating fundamentals. */
export function computeRiskScore(f: FeatureSnapshot, score: ScoreOutput): number {
  const bearishBase = score.composite < 0 ? -score.composite * 100 : 0;
  const volatilityComponent = Math.min(40, f.volatility30d * 100);
  const growthPenalty = (f.earningsGrowthYoy ?? 0) < -0.05 ? 10 : 0;
  const overboughtPenalty = f.rsi14 !== null && f.rsi14 > 75 ? 8 : 0;
  const raw = bearishBase * 0.55 + volatilityComponent * 0.55 + growthPenalty + overboughtPenalty;
  return Math.max(0, Math.min(100, Math.round(raw)));
}

export function generateScenarios(price: number, f: FeatureSnapshot, score: ScoreOutput): ScenarioCase[] {
  // Scenario spread widens with realized volatility and is centered on the
  // model's directional lean — explicitly framed as model scenarios, not
  // price targets or guarantees.
  const horizonMonths = score.timeHorizon === "Short-term (days)" ? 0.5 : score.timeHorizon === "Swing (1-4 weeks)" ? 1 : 4;
  const sigma = f.volatility30d * Math.sqrt(horizonMonths / 12);
  const drift = score.composite * sigma * 0.6;

  const bull = price * (1 + drift + sigma);
  const base = price * (1 + drift);
  const bear = price * (1 + drift - sigma);

  return [
    {
      label: "Bull case",
      targetPrice: Math.round(bull * 100) / 100,
      narrative:
        "If the supportive factors strengthen further (continued volume confirmation, sentiment staying positive, no regime deterioration), the model's upside scenario over this horizon.",
    },
    {
      label: "Base case",
      targetPrice: Math.round(base * 100) / 100,
      narrative: "Model's central scenario if current technical and fundamental conditions persist roughly unchanged.",
    },
    {
      label: "Bear case",
      targetPrice: Math.round(bear * 100) / 100,
      narrative:
        "If momentum fades, volume dries up, or sentiment reverses, the model's downside scenario over this horizon.",
    },
  ];
}
