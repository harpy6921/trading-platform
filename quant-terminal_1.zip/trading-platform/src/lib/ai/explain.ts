// The language half of the AI pipeline. This module NEVER receives raw
// market access — only the already-computed FeatureSnapshot/ScoreOutput
// from scoring.ts — so it is structurally incapable of inventing a price,
// a percentage, or a fact that wasn't already calculated. Its only job is
// turning numbers into sentences.
//
// If AI_API_KEY is configured, we ask a language model to phrase the
// explanation more naturally, but we pass it the exact factor list and
// forbid it from introducing new figures. If the key is missing or the
// call fails for any reason, generateExplanation() falls back to the
// deterministic template below so every page keeps working with zero AI
// provider configured.

import type { FeatureSnapshot, ScenarioCase } from "@/types";
import type { ScoreOutput } from "./scoring";

export interface Explanation {
  headline: string;
  reasons: string[];
  bullCase: string;
  bearCase: string;
}

function signalPhrase(signal: ScoreOutput["signal"]): string {
  switch (signal) {
    case "STRONG_BUY":
      return "Model indicates strongly bullish conditions";
    case "BUY":
      return "Model indicates bullish conditions";
    case "HOLD":
      return "Model indicates a neutral, wait-and-see setup";
    case "SELL":
      return "Model identifies bearish conditions";
    case "STRONG_SELL":
      return "Model identifies strongly bearish conditions";
  }
}

function templateExplanation(
  ticker: string,
  f: FeatureSnapshot,
  score: ScoreOutput
): Explanation {
  const headline = `${signalPhrase(score.signal)} for ${ticker}, with ${score.confidence}% model confidence.`;

  const reasons = score.topReasons.slice();

  const supportive = score.factors.filter((x) => x.score > 0.1).sort((a, b) => b.score * b.weight - a.score * a.weight);
  const unfavorable = score.factors.filter((x) => x.score < -0.1).sort((a, b) => a.score * a.weight - b.score * b.weight);

  const bullCase = supportive.length
    ? `Algorithm detected a potentially favorable setup: ${supportive
        .slice(0, 3)
        .map((x) => x.name.toLowerCase())
        .join(", ")} are currently aligned in ${ticker}'s favor. This thesis would be undermined by a reversal in volume, sentiment, or the broader ${f.marketRegime.toLowerCase()} market regime.`
    : `No strongly supportive factors were detected for ${ticker} at this time; a bull case would require improvement in momentum, sentiment, or fundamentals before this thesis strengthens.`;

  const bearCase = unfavorable.length
    ? `Model identifies elevated downside risk from: ${unfavorable
        .slice(0, 3)
        .map((x) => x.name.toLowerCase())
        .join(", ")}. A continuation of these conditions, or a broader deterioration in the market regime, would support further downside.`
    : `No strongly unfavorable factors were detected for ${ticker} at this time; downside risk would most likely come from a broader market or sector regime shift rather than ${ticker}-specific weakness.`;

  return { headline, reasons, bullCase, bearCase };
}

export async function generateExplanation(params: {
  ticker: string;
  companyName: string;
  features: FeatureSnapshot;
  score: ScoreOutput;
  scenarios: ScenarioCase[];
}): Promise<Explanation> {
  const fallback = templateExplanation(params.ticker, params.features, params.score);

  const apiKey = process.env.AI_API_KEY;
  if (!apiKey) return fallback;

  try {
    const narrated = await narrateWithLLM(apiKey, params, fallback);
    return narrated ?? fallback;
  } catch {
    // Any failure (network, rate limit, malformed response) silently
    // degrades to the template — the page must never break because the
    // optional AI narration layer is unavailable.
    return fallback;
  }
}

async function narrateWithLLM(
  apiKey: string,
  params: {
    ticker: string;
    companyName: string;
    features: FeatureSnapshot;
    score: ScoreOutput;
    scenarios: ScenarioCase[];
  },
  fallback: Explanation
): Promise<Explanation | null> {
  const model = process.env.AI_MODEL || "claude-sonnet-4-6";
  const system =
    "You rewrite trading-model output into clear, professional prose for a research terminal. " +
    "You MUST NOT introduce any number, price, percentage, or fact that is not already present in " +
    "the JSON you are given. Never claim certainty about future price movement. Keep each field to " +
    "1-3 sentences. Respond with ONLY minified JSON: " +
    '{"headline":"...","reasons":["...","..."],"bullCase":"...","bearCase":"..."}';

  const payload = {
    ticker: params.ticker,
    companyName: params.companyName,
    signal: params.score.signal,
    confidence: params.score.confidence,
    riskLevel: params.score.riskLevel,
    factors: params.score.factors.map((f) => ({ name: f.name, score: Number(f.score.toFixed(2)) })),
    scenarios: params.scenarios.map((s) => ({ label: s.label, targetPrice: s.targetPrice })),
    marketRegime: params.features.marketRegime,
  };

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": apiKey,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model,
      max_tokens: 500,
      system,
      messages: [{ role: "user", content: JSON.stringify(payload) }],
    }),
    // Explanations are best-effort narration; never let a slow AI call
    // hang a page load.
    signal: AbortSignal.timeout(8000),
  });

  if (!res.ok) return null;
  const data = await res.json();
  const text = (data.content ?? []).map((b: { type: string; text?: string }) => (b.type === "text" ? b.text : "")).join("");
  try {
    const parsed = JSON.parse(text);
    if (!parsed.headline || !Array.isArray(parsed.reasons) || !parsed.bullCase || !parsed.bearCase) {
      return null;
    }
    return {
      headline: String(parsed.headline),
      reasons: parsed.reasons.map(String).slice(0, 6),
      bullCase: String(parsed.bullCase),
      bearCase: String(parsed.bearCase),
    };
  } catch {
    return null;
  }
}
