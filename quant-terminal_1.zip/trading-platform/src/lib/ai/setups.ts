import { sma, rsi, macd, realizedVolatility, last } from "@/lib/indicators";
import type { Candle } from "@/lib/market-data/types";
import type { SetupType, TechnicalSetup } from "@/types";

export function detectSetups(ticker: string, companyName: string, candles: Candle[]): TechnicalSetup[] {
  if (candles.length < 60) return [];
  const closes = candles.map((c) => c.close);
  const price = closes[closes.length - 1]!;
  const now = new Date().toISOString();
  const setups: TechnicalSetup[] = [];

  const push = (setupType: SetupType, evidence: string[]) =>
    setups.push({ ticker, companyName, setupType, evidence, detectedAt: now });

  // Breakout / breakdown vs. 20-day range
  const window = candles.slice(-21, -1);
  const rangeHigh = Math.max(...window.map((c) => c.high));
  const rangeLow = Math.min(...window.map((c) => c.low));
  const avgVol = window.reduce((s, c) => s + c.volume, 0) / window.length;
  const latestVolume = candles[candles.length - 1]!.volume;

  if (price > rangeHigh && latestVolume > avgVol * 1.4) {
    push("Potential Breakout", [
      `Price ${price.toFixed(2)} closed above the prior 20-session high of ${rangeHigh.toFixed(2)}`,
      `Volume ${(latestVolume / avgVol).toFixed(1)}x the 20-session average, suggesting participation behind the move`,
    ]);
  }
  if (price < rangeLow && latestVolume > avgVol * 1.4) {
    push("Potential Breakdown", [
      `Price ${price.toFixed(2)} closed below the prior 20-session low of ${rangeLow.toFixed(2)}`,
      `Volume ${(latestVolume / avgVol).toFixed(1)}x the 20-session average, suggesting participation behind the move`,
    ]);
  }

  // Moving-average crossover (golden / death cross on 50/200)
  const sma50 = sma(closes, 50);
  const sma200 = sma(closes, 200);
  if (sma50.length >= 3 && sma200.length >= 3) {
    const s50now = sma50[sma50.length - 1];
    const s50prev = sma50[sma50.length - 4] ?? sma50[sma50.length - 2];
    const s200now = sma200[sma200.length - 1];
    const s200prev = sma200[sma200.length - 4] ?? sma200[sma200.length - 2];
    if (s50now !== null && s50prev !== null && s200now !== null && s200prev !== null) {
      if (s50prev <= s200prev && s50now > s200now) {
        push("Moving-Average Crossover", [
          `50-day SMA (${s50now.toFixed(2)}) crossed above the 200-day SMA (${s200now.toFixed(2)})`,
          "Historically referred to as a 'golden cross'",
        ]);
      } else if (s50prev >= s200prev && s50now < s200now) {
        push("Moving-Average Crossover", [
          `50-day SMA (${s50now.toFixed(2)}) crossed below the 200-day SMA (${s200now.toFixed(2)})`,
          "Historically referred to as a 'death cross'",
        ]);
      }
    }
  }

  // Trend reversal via RSI recovering from oversold, or MACD histogram sign flip
  const rsiSeries = rsi(closes, 14);
  const rsiNow = last(rsiSeries);
  const rsiRecentMin = Math.min(...rsiSeries.slice(-6).filter((v): v is number => v !== null));
  if (rsiNow !== null && rsiRecentMin < 30 && rsiNow > 35) {
    push("Trend Reversal", [
      `RSI(14) recovered from an oversold reading (low of ${rsiRecentMin.toFixed(1)}) to ${rsiNow.toFixed(1)}`,
    ]);
  }
  const macdResult = macd(closes);
  const histNow = last(macdResult.histogram);
  const histSeries = macdResult.histogram.slice(-4).filter((v): v is number => v !== null);
  if (histNow !== null && histSeries.length >= 2) {
    const prevSign = Math.sign(histSeries[0]!);
    const nowSign = Math.sign(histNow);
    if (prevSign !== 0 && nowSign !== 0 && prevSign !== nowSign) {
      push("Trend Reversal", [
        `MACD histogram flipped from ${prevSign > 0 ? "positive" : "negative"} to ${nowSign > 0 ? "positive" : "negative"} over the last several sessions`,
      ]);
    }
  }

  // Momentum continuation: 5 of last 7 sessions up, price above rising SMA50
  const last7 = candles.slice(-7);
  const upDays = last7.filter((c, i) => (i === 0 ? true : c.close > last7[i - 1]!.close)).length;
  const sma50Now = last(sma50);
  const sma50Prev20 = sma50[sma50.length - 21] ?? null;
  if (upDays >= 5 && sma50Now !== null && sma50Prev20 !== null && sma50Now > sma50Prev20 && price > sma50Now) {
    push("Momentum Continuation", [
      `${upDays} of the last 7 sessions closed higher`,
      `Price is trading above a rising 50-day SMA (${sma50Now.toFixed(2)})`,
    ]);
  }

  // Unusual volume
  if (latestVolume > avgVol * 2) {
    push("Unusual Volume", [
      `Latest session volume is ${(latestVolume / avgVol).toFixed(1)}x the trailing 20-session average`,
    ]);
  }

  // Volatility expansion
  const vol10 = realizedVolatility(closes, 10);
  const vol60 = realizedVolatility(closes, 60);
  if (vol60 > 0 && vol10 > vol60 * 1.6) {
    push("Volatility Expansion", [
      `10-session realized volatility (${(vol10 * 100).toFixed(1)}%) is running well above the 60-session baseline (${(vol60 * 100).toFixed(1)}%)`,
    ]);
  }

  // Support / resistance test — price within 1% of a prior 60-day swing level
  const swingWindow = candles.slice(-60, -1);
  if (swingWindow.length > 0) {
    const swingHigh = Math.max(...swingWindow.map((c) => c.high));
    const swingLow = Math.min(...swingWindow.map((c) => c.low));
    if (Math.abs(price - swingHigh) / swingHigh < 0.01) {
      push("Resistance Test", [`Price ${price.toFixed(2)} is within 1% of the 60-session high (${swingHigh.toFixed(2)})`]);
    }
    if (Math.abs(price - swingLow) / swingLow < 0.01) {
      push("Support Test", [`Price ${price.toFixed(2)} is within 1% of the 60-session low (${swingLow.toFixed(2)})`]);
    }
  }

  return setups;
}
