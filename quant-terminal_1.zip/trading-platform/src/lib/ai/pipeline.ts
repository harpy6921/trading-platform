import { getMarketDataProvider } from "@/lib/market-data";
import { buildFeatureSnapshot, computeScore, computeOpportunityScore, computeRiskScore, generateScenarios, MODEL_VERSION } from "./scoring";
import { generateExplanation } from "./explain";
import { detectMarketRegime } from "./regime";
import { detectSetups } from "./setups";
import type { AISignal, OpportunityResult, RiskScanResult, MarketRegimeLabel, TechnicalSetup } from "@/types";
import type { Candle } from "@/lib/market-data/types";

function trailingReturnPct(candles: Candle[], lookback = 21): number {
  if (candles.length <= lookback) return 0;
  const now = candles[candles.length - 1]!.close;
  const then = candles[candles.length - 1 - lookback]!.close;
  return then === 0 ? 0 : ((now - then) / then) * 100;
}

async function getCurrentRegimeLabel(): Promise<MarketRegimeLabel> {
  const provider = getMarketDataProvider();
  const [indices, movers] = await Promise.all([provider.getIndices(), provider.getMovers()]);
  return detectMarketRegime(indices, movers).label;
}

/** Average trailing 21-session return across every ticker in a sector — used for relative-strength scoring. */
async function sectorTrailingReturnPct(sector: string, excludeTicker: string): Promise<number> {
  const provider = getMarketDataProvider();
  const universe = await provider.getScreenerUniverse();
  const peers = universe.filter((r) => r.sector === sector && r.ticker !== excludeTicker).slice(0, 6);
  if (peers.length === 0) return 0;
  const returns = await Promise.all(
    peers.map(async (p) => {
      const candles = await provider.getCandles(p.ticker, "1M");
      return trailingReturnPct(candles, Math.min(21, candles.length - 1));
    })
  );
  return returns.reduce((a, b) => a + b, 0) / returns.length;
}

export async function getSignalForTicker(ticker: string): Promise<AISignal | null> {
  const provider = getMarketDataProvider();
  const [quote, candles, fundamentals, news, regime] = await Promise.all([
    provider.getQuote(ticker),
    provider.getCandles(ticker, "1Y"),
    provider.getFundamentals(ticker),
    provider.getNews({ ticker, limit: 10 }),
    getCurrentRegimeLabel(),
  ]);
  if (!quote || candles.length < 30) return null;

  const sectorReturnPct = fundamentals ? await sectorTrailingReturnPct(fundamentals.sector, ticker) : 0;

  const features = buildFeatureSnapshot({ candles, fundamentals, news, sectorReturnPct, regime });
  const score = computeScore(features);
  const scenarios = generateScenarios(quote.price, features, score);
  const explanation = await generateExplanation({
    ticker,
    companyName: quote.companyName,
    features,
    score,
    scenarios,
  });

  return {
    ticker,
    signal: score.signal,
    confidence: score.confidence,
    riskLevel: score.riskLevel,
    timeHorizon: score.timeHorizon,
    timestamp: new Date().toISOString(),
    modelVersion: MODEL_VERSION,
    price: quote.price,
    reasons: explanation.reasons,
    bullCase: explanation.bullCase,
    bearCase: explanation.bearCase,
    features,
    scenarios,
    opportunityScore: computeOpportunityScore(features, score),
    riskScore: computeRiskScore(features, score),
  };
}

export async function scanOpportunities(limit = 20): Promise<OpportunityResult[]> {
  const provider = getMarketDataProvider();
  const universe = await provider.getScreenerUniverse();
  const regime = await getCurrentRegimeLabel();

  const results = await Promise.all(
    universe.map(async (row) => {
      const [candles, fundamentals, news] = await Promise.all([
        provider.getCandles(row.ticker, "1Y"),
        provider.getFundamentals(row.ticker),
        provider.getNews({ ticker: row.ticker, limit: 6 }),
      ]);
      const sectorReturnPct = await sectorTrailingReturnPct(row.sector, row.ticker);
      const features = buildFeatureSnapshot({ candles, fundamentals, news, sectorReturnPct, regime });
      const score = computeScore(features);
      const opportunityScore = computeOpportunityScore(features, score);
      const explanation = await generateExplanation({
        ticker: row.ticker,
        companyName: row.companyName,
        features,
        score,
        scenarios: [],
      });
      const result: OpportunityResult = {
        ticker: row.ticker,
        companyName: row.companyName,
        price: row.price,
        changePct: row.changePct,
        opportunityScore,
        signal: score.signal,
        confidence: score.confidence,
        riskLevel: score.riskLevel,
        explanation: explanation.headline,
      };
      return result;
    })
  );

  return results.sort((a, b) => b.opportunityScore - a.opportunityScore).slice(0, limit);
}

export async function scanRisks(limit = 20): Promise<RiskScanResult[]> {
  const provider = getMarketDataProvider();
  const universe = await provider.getScreenerUniverse();
  const regime = await getCurrentRegimeLabel();

  const results = await Promise.all(
    universe.map(async (row) => {
      const [candles, fundamentals, news] = await Promise.all([
        provider.getCandles(row.ticker, "1Y"),
        provider.getFundamentals(row.ticker),
        provider.getNews({ ticker: row.ticker, limit: 6 }),
      ]);
      const sectorReturnPct = await sectorTrailingReturnPct(row.sector, row.ticker);
      const features = buildFeatureSnapshot({ candles, fundamentals, news, sectorReturnPct, regime });
      const score = computeScore(features);
      const riskScore = computeRiskScore(features, score);
      const explanation = await generateExplanation({
        ticker: row.ticker,
        companyName: row.companyName,
        features,
        score,
        scenarios: [],
      });
      const result: RiskScanResult = {
        ticker: row.ticker,
        companyName: row.companyName,
        price: row.price,
        changePct: row.changePct,
        riskScore,
        signal: score.signal,
        confidence: score.confidence,
        riskLevel: score.riskLevel,
        explanation: explanation.headline,
      };
      return result;
    })
  );

  return results.sort((a, b) => b.riskScore - a.riskScore).slice(0, limit);
}

/** Scans the supported universe for recognizable technical setups. */
export async function scanSetups(limit = 12): Promise<TechnicalSetup[]> {
  const provider = getMarketDataProvider();
  const universe = await provider.getScreenerUniverse();

  const perTicker = await Promise.all(
    universe.map(async (row) => {
      const candles = await provider.getCandles(row.ticker, "6M");
      return detectSetups(row.ticker, row.companyName, candles);
    })
  );

  return perTicker.flat().slice(0, limit);
}

/** Full AISignal for every ticker in the supported universe — backs the AI Signals page. */
export async function getAllSignals(limit = 40): Promise<AISignal[]> {
  const provider = getMarketDataProvider();
  const universe = await provider.getScreenerUniverse();
  const signals = await Promise.all(universe.slice(0, limit).map((row) => getSignalForTicker(row.ticker)));
  return signals.filter((s): s is AISignal => s !== null);
}
