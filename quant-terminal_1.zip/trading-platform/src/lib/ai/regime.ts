import type { IndexQuote, MarketMovers } from "@/lib/market-data/types";
import type { MarketRegime, MarketRegimeLabel } from "@/types";

export function detectMarketRegime(indices: IndexQuote[], movers: MarketMovers): MarketRegime {
  const spx = indices.find((i) => i.symbol === "SPX");
  const ndx = indices.find((i) => i.symbol === "NDX");
  const rut = indices.find((i) => i.symbol === "RUT");
  const vix = indices.find((i) => i.symbol === "VIX");

  const broadMomentum =
    [spx?.changePct, ndx?.changePct, rut?.changePct].filter((v): v is number => typeof v === "number").reduce((a, b) => a + b, 0) / 3;

  const vixLevel = vix?.value ?? 16;
  const gainerVolume = movers.gainers.reduce((s, m) => s + m.volume, 0);
  const loserVolume = movers.losers.reduce((s, m) => s + m.volume, 0);
  const breadthRatio = loserVolume > 0 ? gainerVolume / loserVolume : 1;

  const factors: MarketRegime["factors"] = [
    {
      name: "Index momentum (SPX/NDX/RUT avg)",
      reading: `${broadMomentum >= 0 ? "+" : ""}${broadMomentum.toFixed(2)}%`,
      leaning: broadMomentum > 0.15 ? "bullish" : broadMomentum < -0.15 ? "bearish" : "neutral",
    },
    {
      name: "VIX level",
      reading: vixLevel.toFixed(1),
      leaning: vixLevel > 22 ? "bearish" : vixLevel < 15 ? "bullish" : "neutral",
    },
    {
      name: "Volume breadth (gainer vs. loser volume)",
      reading: `${breadthRatio.toFixed(2)}x`,
      leaning: breadthRatio > 1.2 ? "bullish" : breadthRatio < 0.8 ? "bearish" : "neutral",
    },
    {
      name: "Small-cap participation (Russell 2000)",
      reading: `${(rut?.changePct ?? 0) >= 0 ? "+" : ""}${(rut?.changePct ?? 0).toFixed(2)}%`,
      leaning: (rut?.changePct ?? 0) > 0.2 ? "bullish" : (rut?.changePct ?? 0) < -0.2 ? "bearish" : "neutral",
    },
  ];

  let label: MarketRegimeLabel;
  if (vixLevel > 26) {
    label = "High Volatility";
  } else if (broadMomentum > 0.3 && breadthRatio > 1.1 && vixLevel < 20) {
    label = "Bullish";
  } else if (broadMomentum < -0.3 && breadthRatio < 0.9) {
    label = "Bearish";
  } else if (Math.abs(broadMomentum) < 0.12 && vixLevel < 20) {
    label = "Neutral";
  } else {
    label = "Transitional";
  }

  const explanationByLabel: Record<MarketRegimeLabel, string> = {
    Bullish:
      "Broad indices are advancing together with healthy volume breadth and contained volatility — conditions historically associated with trend-following and breakout setups working more reliably.",
    Bearish:
      "Broad indices are declining together with volume favoring decliners — conditions where short-side and defensive setups have historically been more reliable, and long breakout setups less so.",
    Neutral:
      "Indices are roughly flat with volatility contained — a range-bound tape where mean-reversion setups have historically outperformed strong trend-following.",
    "High Volatility":
      "Elevated VIX signals wide, fast price swings across the market — historically the environment where technical setups (including this model's) are least reliable and position sizing matters most.",
    Transitional:
      "Signals are mixed across momentum, volatility, and breadth — a regime that often precedes a clearer trend but can also whipsaw; setups should be weighted with extra caution until the picture clarifies.",
  };

  return {
    label,
    detectedAt: new Date().toISOString(),
    explanation: explanationByLabel[label],
    factors,
    reliabilityNote:
      label === "High Volatility"
        ? "Signal confidence across the platform is generally dampened in this regime — treat scores as lower-conviction than usual."
        : label === "Bearish"
          ? "Bullish setups may see a lower historical hit rate while this regime persists; risk-scanner output should be weighted more heavily."
          : "Standard signal reliability assumptions apply, though no regime guarantees any individual setup's outcome.",
  };
}
