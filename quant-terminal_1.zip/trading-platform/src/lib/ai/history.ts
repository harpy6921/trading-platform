// Persists every generated AI signal so the Performance page can report
// real win rates instead of fabricated ones. Two things are true by
// design: (1) nothing is backfilled — a signal only exists in history once
// it has actually been generated and viewed, and (2) an outcome is only
// recorded once the configured horizon has actually elapsed in wall-clock
// time (checked against `createdAt`), using whatever price the active
// provider reports at evaluation time. In DEMO MODE that means outcomes
// accumulate honestly as demo "days" pass, exactly like a live deployment
// would accumulate them against real prices.
//
// Every function here is best-effort: if the database isn't migrated yet,
// callers catch the error and fall back to an empty state rather than
// crashing the page — see src/app/performance/page.tsx.

import { prisma } from "@/lib/db/prisma";
import { getMarketDataProvider } from "@/lib/market-data";
import type { AISignal } from "@/types";

const HORIZONS_DAYS = [5, 10, 21];

export async function recordSignalIfNew(signal: AISignal): Promise<void> {
  const startOfDay = new Date();
  startOfDay.setUTCHours(0, 0, 0, 0);

  const existing = await prisma.signalRecord.findFirst({
    where: { ticker: signal.ticker, createdAt: { gte: startOfDay } },
  });
  if (existing) return;

  await prisma.signalRecord.create({
    data: {
      ticker: signal.ticker,
      signal: signal.signal,
      confidence: signal.confidence,
      priceAtSignal: signal.price,
      modelVersion: signal.modelVersion,
      features: signal.features as unknown as object,
    },
  });
}

export async function evaluatePendingOutcomes(limit = 25): Promise<number> {
  const provider = getMarketDataProvider();
  const cutoff = new Date();
  cutoff.setUTCDate(cutoff.getUTCDate() - Math.min(...HORIZONS_DAYS));

  const candidates = await prisma.signalRecord.findMany({
    where: { createdAt: { lte: cutoff } },
    include: { outcomes: true },
    take: limit,
    orderBy: { createdAt: "asc" },
  });

  let evaluated = 0;
  for (const record of candidates) {
    const ageDays = Math.floor((Date.now() - record.createdAt.getTime()) / 86_400_000);
    const dueHorizons = HORIZONS_DAYS.filter(
      (h) => ageDays >= h && !record.outcomes.some((o) => o.horizonDays === h)
    );
    if (dueHorizons.length === 0) continue;

    const quote = await provider.getQuote(record.ticker);
    if (!quote) continue;

    const priceAtSignal = Number(record.priceAtSignal);
    const returnPct = priceAtSignal > 0 ? ((quote.price - priceAtSignal) / priceAtSignal) * 100 : 0;

    for (const horizon of dueHorizons) {
      await prisma.signalOutcome.create({
        data: {
          signalId: record.id,
          horizonDays: horizon,
          priceAtHorizon: quote.price,
          returnPct,
        },
      });
      evaluated++;
    }
  }
  return evaluated;
}

export interface PerformanceSummary {
  totalSignals: number;
  evaluatedOutcomes: number;
  winRate: number | null;
  avgReturnPct: number | null;
  medianReturnPct: number | null;
  bySignalType: { signal: string; count: number; avgReturnPct: number | null }[];
  byHorizon: { horizonDays: number; count: number; winRate: number | null; avgReturnPct: number | null }[];
}

export async function getPerformanceSummary(): Promise<PerformanceSummary> {
  const totalSignals = await prisma.signalRecord.count();
  const outcomes = await prisma.signalOutcome.findMany({ include: { signal: true } });

  const returns = outcomes.map((o) => Number(o.returnPct));
  const wins = returns.filter((r) => r > 0).length;

  const bySignalTypeMap = new Map<string, number[]>();
  for (const o of outcomes) {
    const key = o.signal.signal;
    if (!bySignalTypeMap.has(key)) bySignalTypeMap.set(key, []);
    bySignalTypeMap.get(key)!.push(Number(o.returnPct));
  }

  const byHorizonMap = new Map<number, number[]>();
  for (const o of outcomes) {
    if (!byHorizonMap.has(o.horizonDays)) byHorizonMap.set(o.horizonDays, []);
    byHorizonMap.get(o.horizonDays)!.push(Number(o.returnPct));
  }

  function avg(arr: number[]): number | null {
    return arr.length ? arr.reduce((a, b) => a + b, 0) / arr.length : null;
  }
  function median(arr: number[]): number | null {
    if (arr.length === 0) return null;
    const sorted = [...arr].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    return sorted.length % 2 !== 0 ? sorted[mid]! : (sorted[mid - 1]! + sorted[mid]!) / 2;
  }

  return {
    totalSignals,
    evaluatedOutcomes: outcomes.length,
    winRate: outcomes.length ? (wins / outcomes.length) * 100 : null,
    avgReturnPct: avg(returns),
    medianReturnPct: median(returns),
    bySignalType: Array.from(bySignalTypeMap.entries()).map(([signal, arr]) => ({
      signal,
      count: arr.length,
      avgReturnPct: avg(arr),
    })),
    byHorizon: HORIZONS_DAYS.map((h) => {
      const arr = byHorizonMap.get(h) ?? [];
      return {
        horizonDays: h,
        count: arr.length,
        winRate: arr.length ? (arr.filter((r) => r > 0).length / arr.length) * 100 : null,
        avgReturnPct: avg(arr),
      };
    }),
  };
}
