import { getMarketDataProvider } from "@/lib/market-data";
import { OnboardingClient } from "@/components/onboarding/OnboardingClient";

export default async function OnboardingPage() {
  const rows = await getMarketDataProvider().getScreenerUniverse();
  const options = rows.slice(0, 20).map((r) => ({ ticker: r.ticker, companyName: r.companyName }));

  return (
    <div className="mx-auto max-w-2xl">
      <OnboardingClient options={options} />
    </div>
  );
}
