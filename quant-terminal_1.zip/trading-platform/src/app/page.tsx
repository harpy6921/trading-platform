import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getMarketDataProvider } from "@/lib/market-data";
import { detectMarketRegime } from "@/lib/ai/regime";
import { scanOpportunities, scanRisks, scanSetups } from "@/lib/ai/pipeline";
import { MarketIndexCard } from "@/components/market/MarketIndexCard";
import { MarketRegimeCard } from "@/components/market/MarketRegimeCard";
import { MoversTable } from "@/components/market/MoversTable";
import { SignalBadge } from "@/components/stock/SignalBadge";
import { Card, CardHeader } from "@/components/ui/Card";
import { formatCurrency, formatPct, cx } from "@/lib/utils/format";

export const revalidate = 0;

export default async function DashboardPage() {
  const provider = getMarketDataProvider();
  const [indices, movers] = await Promise.all([provider.getIndices(), provider.getMovers()]);
  const regime = detectMarketRegime(indices, movers);
  const [opportunities, risks, setups] = await Promise.all([
    scanOpportunities(5),
    scanRisks(5),
    scanSetups(6),
  ]);

  return (
    <div className="mx-auto max-w-7xl space-y-6">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Market Dashboard</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Broad market snapshot, detected regime, movers, and this session's top AI-flagged names.
        </p>
      </div>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {indices.map((idx) => (
          <MarketIndexCard key={idx.symbol} index={idx} />
        ))}
      </section>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketRegimeCard regime={regime} />
        </div>
        <MoversTable movers={movers} />
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <Card>
          <CardHeader
            title="AI Opportunities"
            subtitle="Highest Opportunity Scores right now"
            right={
              <Link href="/opportunities" className="flex items-center gap-1 text-xs text-amber hover:underline">
                View all <ArrowRight size={12} />
              </Link>
            }
          />
          <ul className="space-y-2.5">
            {opportunities.map((o) => (
              <li key={o.ticker}>
                <Link href={`/stock/${o.ticker}`} className="flex items-center justify-between gap-2 rounded-md px-1.5 py-1 hover:bg-base-700/40">
                  <div className="min-w-0">
                    <p className="font-mono text-sm font-medium text-ink-100">{o.ticker}</p>
                    <SignalBadge signal={o.signal} size="sm" />
                  </div>
                  <div className="text-right">
                    <p className="stat-tabular text-sm font-semibold text-amber">{o.opportunityScore}</p>
                    <p className="text-[10px] text-ink-500">opp. score</p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader
            title="AI Risk Scanner"
            subtitle="Highest Risk Scores right now"
            right={
              <Link href="/risk-scanner" className="flex items-center gap-1 text-xs text-amber hover:underline">
                View all <ArrowRight size={12} />
              </Link>
            }
          />
          <ul className="space-y-2.5">
            {risks.map((r) => (
              <li key={r.ticker}>
                <Link href={`/stock/${r.ticker}`} className="flex items-center justify-between gap-2 rounded-md px-1.5 py-1 hover:bg-base-700/40">
                  <div className="min-w-0">
                    <p className="font-mono text-sm font-medium text-ink-100">{r.ticker}</p>
                    <SignalBadge signal={r.signal} size="sm" />
                  </div>
                  <div className="text-right">
                    <p className="stat-tabular text-sm font-semibold text-fall">{r.riskScore}</p>
                    <p className="text-[10px] text-ink-500">risk score</p>
                  </div>
                </Link>
              </li>
            ))}
          </ul>
        </Card>

        <Card>
          <CardHeader
            title="Detected Setups"
            subtitle="Pattern evidence, not predictions"
            right={
              <Link href="/screener" className="flex items-center gap-1 text-xs text-amber hover:underline">
                Screener <ArrowRight size={12} />
              </Link>
            }
          />
          <ul className="space-y-2.5">
            {setups.length === 0 && <p className="text-sm text-ink-500">No setups detected this session.</p>}
            {setups.map((s, i) => (
              <li key={`${s.ticker}-${i}`}>
                <Link href={`/stock/${s.ticker}`} className="block rounded-md px-1.5 py-1.5 hover:bg-base-700/40">
                  <div className="flex items-center justify-between">
                    <span className="font-mono text-sm font-medium text-ink-100">{s.ticker}</span>
                    <span className="text-xs text-ink-300">{s.setupType}</span>
                  </div>
                  <p className="mt-0.5 truncate text-xs text-ink-500">{s.evidence[0]}</p>
                </Link>
              </li>
            ))}
          </ul>
        </Card>
      </div>
    </div>
  );
}
