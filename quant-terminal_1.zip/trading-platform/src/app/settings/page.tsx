import { getCurrentUser } from "@/lib/auth/session";
import { getMarketDataProvider, isDemoMode } from "@/lib/market-data";
import { SignInPrompt } from "@/components/ui/SignInPrompt";
import { Card, CardHeader } from "@/components/ui/Card";
import { SignOutButton } from "@/components/auth/SignOutButton";

export const revalidate = 0;

export default async function SettingsPage() {
  const user = await getCurrentUser();
  const demo = isDemoMode();
  const provider = getMarketDataProvider();

  if (!user) {
    return (
      <div className="mx-auto max-w-7xl">
        <SignInPrompt feature="account settings" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-2xl space-y-5">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Settings</h1>
      </div>

      <Card>
        <CardHeader title="Account" />
        <div className="space-y-1 text-sm">
          <p className="text-ink-300">
            <span className="text-ink-500">Email: </span>
            {user.email}
          </p>
          {user.displayName && (
            <p className="text-ink-300">
              <span className="text-ink-500">Name: </span>
              {user.displayName}
            </p>
          )}
          <p className="text-ink-300">
            <span className="text-ink-500">Member since: </span>
            {new Date(user.createdAt).toLocaleDateString()}
          </p>
        </div>
        <div className="mt-4">
          <SignOutButton />
        </div>
      </Card>

      <Card>
        <CardHeader title="Data Source" />
        <p className="text-sm text-ink-300">
          Current market-data provider:{" "}
          <span className={demo ? "text-amber" : "text-rise"}>{provider.source === "demo" ? "DEMO MODE (synthetic data)" : provider.source}</span>
        </p>
        <p className="mt-1 text-xs text-ink-500">
          Configured via <code className="font-mono">MARKET_DATA_PROVIDER</code> in the server environment. See the README for how to connect a live vendor.
        </p>
      </Card>

      <Card>
        <CardHeader title="About the AI models" />
        <p className="text-sm leading-relaxed text-ink-300">
          Signals, Opportunity/Risk Scores, and scenarios are algorithmic outputs from a transparent, rules-based
          scoring model over technical, fundamental, sentiment, and market-regime inputs — not guarantees of future
          performance. See the disclaimer at the bottom of every page.
        </p>
      </Card>
    </div>
  );
}
