export default function Loading() {
  return (
    <div className="mx-auto max-w-7xl animate-pulse space-y-5">
      <div className="space-y-2">
        <div className="h-5 w-48 rounded bg-base-700" />
        <div className="h-3.5 w-80 rounded bg-base-800" />
      </div>
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {Array.from({ length: 5 }).map((_, i) => (
          <div key={i} className="panel h-24" />
        ))}
      </div>
      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="panel h-64 lg:col-span-2" />
        <div className="panel h-64" />
      </div>
    </div>
  );
}
