import { BacktestClient } from "@/components/backtest/BacktestClient";

export default function BacktestingPage() {
  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Strategy Backtesting</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Define a simple rule and run it against historical candles.{" "}
          <span className="text-amber">Backtested results are historical simulations — not live or paper-trading performance.</span>
        </p>
      </div>
      <BacktestClient />
    </div>
  );
}
