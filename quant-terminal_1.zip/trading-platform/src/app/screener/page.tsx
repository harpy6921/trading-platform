import { getMarketDataProvider } from "@/lib/market-data";
import { ScreenerClient } from "@/components/screener/ScreenerClient";

export const revalidate = 0;

export default async function ScreenerPage() {
  const provider = getMarketDataProvider();
  const rows = await provider.getScreenerUniverse();

  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Stock Screener</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Filter and sort the supported universe by technical, fundamental, and AI-derived criteria.
        </p>
      </div>
      <ScreenerClient initialRows={rows} />
    </div>
  );
}
