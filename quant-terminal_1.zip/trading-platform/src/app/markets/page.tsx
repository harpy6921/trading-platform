import { getMarketDataProvider } from "@/lib/market-data";
import { detectMarketRegime } from "@/lib/ai/regime";
import { MarketIndexCard } from "@/components/market/MarketIndexCard";
import { MarketRegimeCard } from "@/components/market/MarketRegimeCard";
import { MoversTable } from "@/components/market/MoversTable";

export const revalidate = 0;

export default async function MarketsPage() {
  const provider = getMarketDataProvider();
  const [indices, movers] = await Promise.all([provider.getIndices(), provider.getMovers()]);
  const regime = detectMarketRegime(indices, movers);

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Markets</h1>
        <p className="mt-0.5 text-sm text-ink-500">Broad index levels, intraday action, and market movers.</p>
      </div>

      <section className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {indices.map((idx) => (
          <MarketIndexCard key={idx.symbol} index={idx} />
        ))}
      </section>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <MarketRegimeCard regime={regime} />
        </div>
        <MoversTable movers={movers} />
      </div>
    </div>
  );
}
