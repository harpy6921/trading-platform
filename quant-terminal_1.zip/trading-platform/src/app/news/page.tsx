import { getMarketDataProvider } from "@/lib/market-data";
import { NewsList } from "@/components/stock/NewsList";
import { Card, CardHeader } from "@/components/ui/Card";
import { SECTORS } from "@/lib/constants/universe";

export const revalidate = 0;

export default async function NewsPage({
  searchParams,
}: {
  searchParams: { sector?: string; sentiment?: string; ticker?: string };
}) {
  const provider = getMarketDataProvider();
  let items = await provider.getNews({
    ticker: searchParams.ticker,
    sector: searchParams.sector,
    limit: 60,
  });
  if (searchParams.sentiment) {
    items = items.filter((i) => i.sentiment === searchParams.sentiment);
  }

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">News & Sentiment</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Sentiment is one input among many in the AI models — treat any single headline as context, not a signal on its own.
        </p>
      </div>

      <form method="GET" className="panel flex flex-wrap items-end gap-3 p-3">
        <label className="text-xs text-ink-500">
          Ticker
          <input name="ticker" defaultValue={searchParams.ticker} placeholder="e.g. AAPL" className="mt-0.5 block w-32 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100" />
        </label>
        <label className="text-xs text-ink-500">
          Sector
          <select name="sector" defaultValue={searchParams.sector ?? ""} className="mt-0.5 block w-44 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100">
            <option value="">All sectors</option>
            {SECTORS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-ink-500">
          Sentiment
          <select name="sentiment" defaultValue={searchParams.sentiment ?? ""} className="mt-0.5 block w-40 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100">
            <option value="">Any</option>
            <option value="very_bullish">Very Bullish</option>
            <option value="bullish">Bullish</option>
            <option value="neutral">Neutral</option>
            <option value="bearish">Bearish</option>
            <option value="very_bearish">Very Bearish</option>
          </select>
        </label>
        <button type="submit" className="rounded-md bg-amber px-3 py-1.5 text-xs font-semibold text-base-950 hover:bg-amber-bright">
          Apply
        </button>
      </form>

      <Card>
        <CardHeader title="Latest Headlines" subtitle={`${items.length} articles`} />
        <NewsList items={items} showTicker />
      </Card>
    </div>
  );
}
