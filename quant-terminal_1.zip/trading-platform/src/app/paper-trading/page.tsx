import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { getOrCreatePrimaryAccount } from "@/lib/paper-trading/account";
import { computePortfolioValue } from "@/lib/paper-trading/engine";
import { SignInPrompt } from "@/components/ui/SignInPrompt";
import { PaperTradingClient } from "@/components/portfolio/PaperTradingClient";

export const revalidate = 0;

export default async function PaperTradingPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <div className="mx-auto max-w-7xl">
        <SignInPrompt feature="paper trading" />
      </div>
    );
  }

  const account = await getOrCreatePrimaryAccount(user.id);
  const portfolio = await computePortfolioValue(account.id);
  const orders = await prisma.paperOrder.findMany({
    where: { accountId: account.id },
    orderBy: { placedAt: "desc" },
    take: 50,
  });

  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Paper Trading</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          <span className="badge border border-amber/30 bg-amber/10 text-amber">PAPER TRADING</span>{" "}
          <span className="ml-1">Simulated orders only — no real money or brokerage connection.</span>
        </p>
      </div>

      <PaperTradingClient
        account={{
          id: account.id,
          name: account.name,
          startingBalance: Number(account.startingBalance),
          commissionPerOrder: Number(account.commissionPerOrder),
          slippageBps: account.slippageBps,
        }}
        portfolio={portfolio}
        orders={orders.map((o) => ({
          id: o.id,
          ticker: o.ticker,
          side: o.side,
          type: o.type,
          quantity: Number(o.quantity),
          fillPrice: o.fillPrice ? Number(o.fillPrice) : null,
          commission: Number(o.commission),
          status: o.status,
          placedAt: o.placedAt.toISOString(),
          realizedPnl: o.realizedPnl ? Number(o.realizedPnl) : null,
        }))}
      />
    </div>
  );
}
