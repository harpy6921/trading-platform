import { getMarketDataProvider } from "@/lib/market-data";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(
  async (req) => {
    const { searchParams } = new URL(req.url);
    const q = searchParams.get("q") || "";
    const provider = getMarketDataProvider();
    const results = await provider.searchSymbols(q);
    return ok(results);
  },
  { rateLimitPerMinute: 120 }
);
