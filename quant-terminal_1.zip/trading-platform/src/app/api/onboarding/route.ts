import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { getOrCreatePrimaryAccount } from "@/lib/paper-trading/account";
import { ok, withRoute } from "@/lib/utils/api";

const schema = z.object({
  startingBalance: z.number().positive().max(100_000_000).default(100_000),
  watchlistTickers: z.array(z.string()).max(20).default([]),
});

export const POST = withRoute(async (req) => {
  const userId = await requireUserId();
  const body = schema.parse(await req.json());

  const account = await getOrCreatePrimaryAccount(userId);
  await prisma.paperAccount.update({
    where: { id: account.id },
    data: { startingBalance: body.startingBalance, cashBalance: body.startingBalance },
  });

  if (body.watchlistTickers.length > 0) {
    const watchlist = await prisma.watchlist.findFirst({ where: { userId }, orderBy: { sortOrder: "asc" } });
    if (watchlist) {
      await prisma.watchlistItem.createMany({
        data: body.watchlistTickers.map((ticker, i) => ({ watchlistId: watchlist.id, ticker: ticker.toUpperCase(), sortOrder: i })),
        skipDuplicates: true,
      });
    }
  }

  await prisma.user.update({ where: { id: userId }, data: { onboardedAt: new Date() } });
  return ok({ onboarded: true });
});
