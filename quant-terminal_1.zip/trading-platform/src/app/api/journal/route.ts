import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { getOrCreatePrimaryAccount } from "@/lib/paper-trading/account";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const userId = await requireUserId();
  const entries = await prisma.journalEntry.findMany({
    where: { userId },
    orderBy: { createdAt: "desc" },
    include: { order: true },
  });
  return ok(entries);
});

const createSchema = z.object({
  ticker: z.string().min(1).max(10),
  thesis: z.string().min(1).max(2000),
  setup: z.string().max(100).optional(),
  confidence: z.number().min(0).max(100).optional(),
  timeHorizon: z.string().max(50).optional(),
  notes: z.string().max(2000).optional(),
  orderId: z.string().optional(),
});

export const POST = withRoute(async (req) => {
  const userId = await requireUserId();
  const account = await getOrCreatePrimaryAccount(userId);
  const body = createSchema.parse(await req.json());

  const entry = await prisma.journalEntry.create({
    data: {
      userId,
      accountId: account.id,
      ticker: body.ticker.toUpperCase(),
      thesis: body.thesis,
      setup: body.setup,
      confidence: body.confidence,
      timeHorizon: body.timeHorizon,
      notes: body.notes,
      orderId: body.orderId,
    },
  });
  return ok(entry, 201);
});
