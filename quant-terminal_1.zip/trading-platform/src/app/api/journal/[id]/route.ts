import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { getMarketDataProvider } from "@/lib/market-data";
import { ok, fail, withRoute } from "@/lib/utils/api";

const closeSchema = z.object({ outcomeNotes: z.string().min(1).max(2000) });

export const PATCH = withRoute(async (req, { params }) => {
  const userId = await requireUserId();
  const entry = await prisma.journalEntry.findUnique({ where: { id: params.id }, include: { order: true } });
  if (!entry || entry.userId !== userId) return fail("Journal entry not found.", 404);

  const body = closeSchema.parse(await req.json());

  let priceContext = "No linked order, so entry price isn't available for comparison.";
  if (entry.order?.fillPrice) {
    const quote = await getMarketDataProvider().getQuote(entry.ticker);
    if (quote) {
      const entryPrice = Number(entry.order.fillPrice);
      const changePct = ((quote.price - entryPrice) / entryPrice) * 100;
      priceContext = `${entry.ticker} has moved ${changePct >= 0 ? "+" : ""}${changePct.toFixed(2)}% from the ${entry.order.side === "BUY" ? "entry" : "exit"} fill of $${entryPrice.toFixed(2)} to the current $${quote.price.toFixed(2)}.`;
    }
  }

  const aiReview =
    `Original thesis: "${entry.thesis}". ` +
    `Outcome recorded: "${body.outcomeNotes}". ` +
    priceContext +
    ` This review reflects only what was recorded for this trade — it does not infer intent or add facts beyond the stated thesis, outcome notes, and observed price change.`;

  const updated = await prisma.journalEntry.update({
    where: { id: entry.id },
    data: { outcomeNotes: body.outcomeNotes, aiReview, closedAt: new Date() },
  });

  return ok(updated);
});
