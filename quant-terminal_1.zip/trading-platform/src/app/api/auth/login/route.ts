import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { verifyPassword } from "@/lib/auth/password";
import { createSession } from "@/lib/auth/session";
import { ok, fail, withRoute } from "@/lib/utils/api";

const schema = z.object({ email: z.string().email(), password: z.string().min(1) });

export const POST = withRoute(
  async (req) => {
    const body = schema.parse(await req.json());
    const user = await prisma.user.findUnique({ where: { email: body.email.toLowerCase() } });
    if (!user) return fail("Invalid email or password.", 401);

    const valid = await verifyPassword(body.password, user.passwordHash);
    if (!valid) return fail("Invalid email or password.", 401);

    await createSession(user.id);
    return ok({ id: user.id, email: user.email });
  },
  { rateLimitPerMinute: 10 }
);
