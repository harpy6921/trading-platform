import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { hashPassword } from "@/lib/auth/password";
import { createSession } from "@/lib/auth/session";
import { ok, fail, withRoute } from "@/lib/utils/api";

const schema = z.object({
  email: z.string().email(),
  password: z.string().min(8, "Password must be at least 8 characters."),
  displayName: z.string().min(1).max(60).optional(),
});

export const POST = withRoute(
  async (req) => {
    const body = schema.parse(await req.json());
    const existing = await prisma.user.findUnique({ where: { email: body.email.toLowerCase() } });
    if (existing) return fail("An account with that email already exists.", 409);

    const passwordHash = await hashPassword(body.password);
    const user = await prisma.user.create({
      data: { email: body.email.toLowerCase(), passwordHash, displayName: body.displayName },
    });

    // Every new user gets a starter watchlist and a $100,000 paper account
    // so onboarding never dead-ends on an empty state.
    await prisma.watchlist.create({ data: { userId: user.id, name: "My Watchlist" } });
    await prisma.paperAccount.create({
      data: { userId: user.id, name: "Paper Account", startingBalance: 100_000, cashBalance: 100_000, commissionPerOrder: 0, slippageBps: 5 },
    });

    await createSession(user.id);
    return ok({ id: user.id, email: user.email }, 201);
  },
  { rateLimitPerMinute: 10 }
);
