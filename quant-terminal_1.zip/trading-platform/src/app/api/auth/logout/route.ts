import { clearSession } from "@/lib/auth/session";
import { ok, withRoute } from "@/lib/utils/api";

export const POST = withRoute(async () => {
  clearSession();
  return ok({ signedOut: true });
});
