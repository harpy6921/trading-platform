import { getAllSignals, getSignalForTicker } from "@/lib/ai/pipeline";
import { recordSignalIfNew } from "@/lib/ai/history";
import { ok, fail, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async (req) => {
  const { searchParams } = new URL(req.url);
  const ticker = searchParams.get("ticker");

  if (ticker) {
    const signal = await getSignalForTicker(ticker);
    if (!signal) return fail(`No signal available for "${ticker}".`, 404);
    await recordSignalIfNew(signal).catch(() => null);
    return ok(signal);
  }

  const signals = await getAllSignals(40);
  await Promise.all(signals.map((s) => recordSignalIfNew(s).catch(() => null)));
  return ok(signals);
});
