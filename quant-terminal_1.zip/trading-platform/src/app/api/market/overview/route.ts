import { getMarketDataProvider } from "@/lib/market-data";
import { detectMarketRegime } from "@/lib/ai/regime";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const provider = getMarketDataProvider();
  const [indices, movers] = await Promise.all([provider.getIndices(), provider.getMovers()]);
  const regime = detectMarketRegime(indices, movers);
  return ok({ indices, movers, regime, source: provider.source });
});
