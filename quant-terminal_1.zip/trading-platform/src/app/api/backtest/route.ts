import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { getMarketDataProvider } from "@/lib/market-data";
import { runBacktest } from "@/lib/backtest/engine";
import { ok, fail, withRoute } from "@/lib/utils/api";

const schema = z.object({
  ticker: z.string().min(1).max(10),
  strategy: z.enum(["sma_crossover", "rsi_reversion", "momentum", "volume_breakout"]),
  params: z.record(z.number()),
  exitHoldingDays: z.number().min(1).max(120).default(10),
  range: z.enum(["1Y", "5Y"]).default("5Y"),
});

export const POST = withRoute(
  async (req) => {
    const body = schema.parse(await req.json());
    const provider = getMarketDataProvider();
    const candles = await provider.getCandles(body.ticker, body.range);
    if (candles.length === 0) return fail(`No historical data available for "${body.ticker}".`, 422);

    const result = runBacktest(candles, {
      strategy: body.strategy,
      params: body.params,
      exitHoldingDays: body.exitHoldingDays,
    });

    // Persisting is best-effort and only happens for signed-in users; the
    // backtest still runs and returns results with no account at all.
    try {
      const userId = await requireUserId();
      await prisma.backtestRun.create({
        data: {
          userId,
          ticker: body.ticker.toUpperCase(),
          ruleConfig: { strategy: body.strategy, params: body.params, exitHoldingDays: body.exitHoldingDays },
          startDate: new Date(candles[0]!.time * 1000),
          endDate: new Date(candles[candles.length - 1]!.time * 1000),
          totalReturn: result.totalReturnPct,
          winRate: result.winRate,
          trades: result.trades.length,
          maxDrawdown: result.maxDrawdownPct,
          profitFactor: result.profitFactor,
          equityCurve: result.equityCurve,
        },
      });
    } catch {
      // not signed in, or DB unavailable — fine, the result below still returns
    }

    return ok({ ...result, source: provider.source });
  },
  { rateLimitPerMinute: 20 }
);
