import { scanRisks } from "@/lib/ai/pipeline";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const results = await scanRisks(40);
  return ok(results);
});
