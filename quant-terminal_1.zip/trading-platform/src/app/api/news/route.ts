import { getMarketDataProvider } from "@/lib/market-data";
import { ok, withRoute } from "@/lib/utils/api";
import type { NewsSentiment } from "@/lib/market-data/types";

export const GET = withRoute(async (req) => {
  const { searchParams } = new URL(req.url);
  const ticker = searchParams.get("ticker") || undefined;
  const sector = searchParams.get("sector") || undefined;
  const sentiment = searchParams.get("sentiment") as NewsSentiment | null;

  const provider = getMarketDataProvider();
  let items = await provider.getNews({ ticker, sector, limit: 60 });
  if (sentiment) items = items.filter((i) => i.sentiment === sentiment);

  return ok(items);
});
