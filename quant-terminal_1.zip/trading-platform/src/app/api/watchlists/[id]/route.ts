import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { ok, fail, withRoute } from "@/lib/utils/api";

async function assertOwnership(userId: string, watchlistId: string) {
  const wl = await prisma.watchlist.findUnique({ where: { id: watchlistId } });
  if (!wl || wl.userId !== userId) throw new Error("NOT_FOUND");
  return wl;
}

const patchSchema = z.object({ name: z.string().min(1).max(60) });

export const PATCH = withRoute(async (req, { params }) => {
  const userId = await requireUserId();
  try {
    await assertOwnership(userId, params.id);
  } catch {
    return fail("Watchlist not found.", 404);
  }
  const body = patchSchema.parse(await req.json());
  const updated = await prisma.watchlist.update({ where: { id: params.id }, data: { name: body.name } });
  return ok(updated);
});

export const DELETE = withRoute(async (_req, { params }) => {
  const userId = await requireUserId();
  try {
    await assertOwnership(userId, params.id);
  } catch {
    return fail("Watchlist not found.", 404);
  }
  await prisma.watchlist.delete({ where: { id: params.id } });
  return ok({ deleted: true });
});
