import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { ok, fail, withRoute } from "@/lib/utils/api";

export const DELETE = withRoute(async (_req, { params }) => {
  const userId = await requireUserId();
  const watchlist = await prisma.watchlist.findUnique({ where: { id: params.id } });
  if (!watchlist || watchlist.userId !== userId) return fail("Watchlist not found.", 404);

  await prisma.watchlistItem.delete({ where: { id: params.itemId } }).catch(() => null);
  return ok({ deleted: true });
});
