import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { getMarketDataProvider } from "@/lib/market-data";
import { ok, fail, withRoute } from "@/lib/utils/api";

const schema = z.object({ ticker: z.string().min(1).max(10) });

export const POST = withRoute(async (req, { params }) => {
  const userId = await requireUserId();
  const watchlist = await prisma.watchlist.findUnique({ where: { id: params.id } });
  if (!watchlist || watchlist.userId !== userId) return fail("Watchlist not found.", 404);

  const body = schema.parse(await req.json());
  const ticker = body.ticker.toUpperCase();

  const quote = await getMarketDataProvider().getQuote(ticker);
  if (!quote) return fail(`Unknown ticker "${ticker}".`, 422);

  const count = await prisma.watchlistItem.count({ where: { watchlistId: watchlist.id } });
  const item = await prisma.watchlistItem.upsert({
    where: { watchlistId_ticker: { watchlistId: watchlist.id, ticker } },
    update: {},
    create: { watchlistId: watchlist.id, ticker, sortOrder: count },
  });
  return ok(item, 201);
});
