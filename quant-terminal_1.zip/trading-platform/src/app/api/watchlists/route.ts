import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const userId = await requireUserId();
  const watchlists = await prisma.watchlist.findMany({
    where: { userId },
    orderBy: { sortOrder: "asc" },
    include: { items: { orderBy: { sortOrder: "asc" } } },
  });
  return ok(watchlists);
});

const createSchema = z.object({ name: z.string().min(1).max(60) });

export const POST = withRoute(async (req) => {
  const userId = await requireUserId();
  const body = createSchema.parse(await req.json());
  const count = await prisma.watchlist.count({ where: { userId } });
  const watchlist = await prisma.watchlist.create({
    data: { userId, name: body.name, sortOrder: count },
  });
  return ok(watchlist, 201);
});
