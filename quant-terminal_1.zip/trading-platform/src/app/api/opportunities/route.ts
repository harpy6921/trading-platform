import { scanOpportunities } from "@/lib/ai/pipeline";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const results = await scanOpportunities(40);
  return ok(results);
});
