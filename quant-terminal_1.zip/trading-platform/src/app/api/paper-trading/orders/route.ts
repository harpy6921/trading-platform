import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { getOrCreatePrimaryAccount } from "@/lib/paper-trading/account";
import { placePaperOrder, computePortfolioValue } from "@/lib/paper-trading/engine";
import { ok, withRoute } from "@/lib/utils/api";

const orderSchema = z.object({
  ticker: z.string().min(1).max(10),
  side: z.enum(["BUY", "SELL"]),
  type: z.enum(["MARKET", "LIMIT"]),
  quantity: z.number().positive(),
  limitPrice: z.number().positive().optional(),
});

export const GET = withRoute(async () => {
  const userId = await requireUserId();
  const account = await getOrCreatePrimaryAccount(userId);
  const orders = await prisma.paperOrder.findMany({
    where: { accountId: account.id },
    orderBy: { placedAt: "desc" },
    take: 200,
  });
  return ok(orders);
});

export const POST = withRoute(
  async (req) => {
    const userId = await requireUserId();
    const account = await getOrCreatePrimaryAccount(userId);
    const body = orderSchema.parse(await req.json());

    const order = await placePaperOrder({
      accountId: account.id,
      ticker: body.ticker,
      side: body.side,
      type: body.type,
      quantity: body.quantity,
      limitPrice: body.limitPrice,
    });

    // Best-effort equity snapshot so the portfolio equity curve has a data
    // point at every trade, in addition to any scheduled snapshot job.
    try {
      const portfolio = await computePortfolioValue(account.id);
      await prisma.equitySnapshot.create({
        data: { accountId: account.id, equity: portfolio.equity, cash: portfolio.cash },
      });
    } catch {
      // non-critical
    }

    return ok(order, 201);
  },
  { rateLimitPerMinute: 60 }
);
