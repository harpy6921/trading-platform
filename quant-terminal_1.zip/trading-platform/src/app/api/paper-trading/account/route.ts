import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { getOrCreatePrimaryAccount } from "@/lib/paper-trading/account";
import { computePortfolioValue } from "@/lib/paper-trading/engine";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const userId = await requireUserId();
  const account = await getOrCreatePrimaryAccount(userId);
  const portfolio = await computePortfolioValue(account.id);
  return ok({
    account: {
      id: account.id,
      name: account.name,
      startingBalance: Number(account.startingBalance),
      commissionPerOrder: Number(account.commissionPerOrder),
      slippageBps: account.slippageBps,
      createdAt: account.createdAt,
    },
    portfolio,
  });
});

const resetSchema = z.object({ startingBalance: z.number().positive().max(100_000_000) });

export const POST = withRoute(async (req) => {
  const userId = await requireUserId();
  const account = await getOrCreatePrimaryAccount(userId);
  const body = resetSchema.parse(await req.json());

  // Configuring a new starting balance resets the paper account: clears
  // positions and orders so simulated results stay internally consistent.
  await prisma.$transaction([
    prisma.paperPosition.deleteMany({ where: { accountId: account.id } }),
    prisma.paperOrder.deleteMany({ where: { accountId: account.id } }),
    prisma.equitySnapshot.deleteMany({ where: { accountId: account.id } }),
    prisma.paperAccount.update({
      where: { id: account.id },
      data: { startingBalance: body.startingBalance, cashBalance: body.startingBalance },
    }),
  ]);

  return ok({ reset: true, startingBalance: body.startingBalance });
});
