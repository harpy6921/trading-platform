import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { ok, fail, withRoute } from "@/lib/utils/api";

const patchSchema = z.object({ status: z.enum(["ACTIVE", "TRIGGERED", "DISMISSED"]) });

export const PATCH = withRoute(async (req, { params }) => {
  const userId = await requireUserId();
  const alert = await prisma.alert.findUnique({ where: { id: params.id } });
  if (!alert || alert.userId !== userId) return fail("Alert not found.", 404);

  const body = patchSchema.parse(await req.json());
  const updated = await prisma.alert.update({ where: { id: alert.id }, data: { status: body.status } });
  return ok(updated);
});

export const DELETE = withRoute(async (_req, { params }) => {
  const userId = await requireUserId();
  const alert = await prisma.alert.findUnique({ where: { id: params.id } });
  if (!alert || alert.userId !== userId) return fail("Alert not found.", 404);
  await prisma.alert.delete({ where: { id: alert.id } });
  return ok({ deleted: true });
});
