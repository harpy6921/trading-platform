import { z } from "zod";
import { prisma } from "@/lib/db/prisma";
import { requireUserId } from "@/lib/auth/session";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const userId = await requireUserId();
  const alerts = await prisma.alert.findMany({ where: { userId }, orderBy: { createdAt: "desc" } });
  return ok(alerts);
});

const createSchema = z.object({
  ticker: z.string().min(1).max(10),
  condition: z.enum([
    "SIGNAL_CHANGE",
    "OPPORTUNITY_SCORE_ABOVE",
    "RISK_SCORE_ABOVE",
    "PRICE_MOVE_PCT",
    "VOLUME_UNUSUAL",
    "VOLATILITY_CHANGE",
    "BREAKOUT",
    "BREAKDOWN",
    "NEWS_EVENT",
    "EARNINGS_EVENT",
  ]),
  threshold: z.number().optional(),
  note: z.string().max(200).optional(),
});

export const POST = withRoute(async (req) => {
  const userId = await requireUserId();
  const body = createSchema.parse(await req.json());
  const alert = await prisma.alert.create({
    data: {
      userId,
      ticker: body.ticker.toUpperCase(),
      condition: body.condition,
      threshold: body.threshold,
      note: body.note,
    },
  });
  return ok(alert, 201);
});
