import { getMarketDataProvider } from "@/lib/market-data";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const provider = getMarketDataProvider();
  const rows = await provider.getScreenerUniverse();
  return ok({ rows, source: provider.source });
});
