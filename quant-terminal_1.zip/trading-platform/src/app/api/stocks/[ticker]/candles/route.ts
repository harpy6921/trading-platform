import { getMarketDataProvider } from "@/lib/market-data";
import { ok, fail, withRoute } from "@/lib/utils/api";
import type { ChartRange } from "@/lib/market-data/types";

const VALID_RANGES: ChartRange[] = ["1D", "5D", "1M", "3M", "6M", "1Y", "5Y"];

export const GET = withRoute(async (req, { params }) => {
  const { searchParams } = new URL(req.url);
  const range = (searchParams.get("range") || "3M") as ChartRange;
  if (!VALID_RANGES.includes(range)) {
    return fail(`Invalid range. Must be one of: ${VALID_RANGES.join(", ")}`, 400);
  }

  const provider = getMarketDataProvider();
  const candles = await provider.getCandles(params.ticker, range);
  return ok({ ticker: params.ticker.toUpperCase(), range, source: provider.source, candles });
}, { rateLimitPerMinute: 120 });
