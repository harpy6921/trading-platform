import { getSectorBreakdown } from "@/lib/market-data/sectors";
import { getMarketDataProvider } from "@/lib/market-data";
import { ok, withRoute } from "@/lib/utils/api";

export const GET = withRoute(async () => {
  const sectors = await getSectorBreakdown();
  return ok({ sectors, source: getMarketDataProvider().source });
});
