import Link from "next/link";
import { getSectorBreakdown, summarizeSectorLeadership } from "@/lib/market-data/sectors";
import { Card, CardHeader } from "@/components/ui/Card";
import { cx, formatCurrency, formatPct } from "@/lib/utils/format";

export const revalidate = 0;

export default async function SectorsPage() {
  const breakdown = await getSectorBreakdown();
  const summary = summarizeSectorLeadership(breakdown);

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Sector Analysis</h1>
        <p className="mt-0.5 text-sm text-ink-500">Relative performance and strongest/weakest names across the ten GICS-style sectors.</p>
      </div>

      <Card>
        <CardHeader title="AI Summary" subtitle="Generated from today's sector-average price action" />
        <p className="text-sm leading-relaxed text-ink-300">{summary}</p>
      </Card>

      <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
        {breakdown.map((s) => (
          <div key={s.sector} className="panel p-4">
            <div className="mb-2 flex items-center justify-between">
              <h3 className="font-display text-sm font-semibold text-ink-100">{s.sector}</h3>
              <span className={cx("stat-tabular text-sm font-semibold", s.avgChangePct >= 0 ? "text-rise" : "text-fall")}>
                {formatPct(s.avgChangePct)}
              </span>
            </div>
            <p className="mb-3 text-xs text-ink-500">
              {s.count} names · avg 30d volatility {formatPct(s.avgVolatility * 100, { signed: false })}
            </p>

            <div className="grid grid-cols-2 gap-3">
              <div>
                <p className="mb-1 text-[10px] uppercase tracking-wide text-rise">Strongest</p>
                <ul className="space-y-1">
                  {s.strongest.map((r) => (
                    <li key={r.ticker}>
                      <Link href={`/stock/${r.ticker}`} className="flex items-center justify-between text-xs hover:text-amber">
                        <span className="font-mono text-ink-200">{r.ticker}</span>
                        <span className="text-rise">{formatPct(r.changePct)}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <p className="mb-1 text-[10px] uppercase tracking-wide text-fall">Weakest</p>
                <ul className="space-y-1">
                  {s.weakest.map((r) => (
                    <li key={r.ticker}>
                      <Link href={`/stock/${r.ticker}`} className="flex items-center justify-between text-xs hover:text-amber">
                        <span className="font-mono text-ink-200">{r.ticker}</span>
                        <span className="text-fall">{formatPct(r.changePct)}</span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
