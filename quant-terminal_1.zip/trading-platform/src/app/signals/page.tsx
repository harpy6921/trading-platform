import Link from "next/link";
import { getAllSignals } from "@/lib/ai/pipeline";
import { recordSignalIfNew } from "@/lib/ai/history";
import { SignalBadge, RiskLevelBadge } from "@/components/stock/SignalBadge";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { formatCurrency, formatRelativeTime } from "@/lib/utils/format";
import type { AISignal } from "@/types";

export const revalidate = 0;

export default async function SignalsPage() {
  const signals = await getAllSignals(40);
  await Promise.all(signals.map((s) => recordSignalIfNew(s).catch(() => null)));

  const columns: Column<AISignal>[] = [
    {
      key: "ticker",
      header: "Ticker",
      sortValue: (s) => s.ticker,
      render: (s) => (
        <Link href={`/stock/${s.ticker}`} className="font-mono font-medium text-ink-100 hover:text-amber">
          {s.ticker}
        </Link>
      ),
    },
    { key: "signal", header: "Signal", render: (s) => <SignalBadge signal={s.signal} size="sm" /> },
    { key: "confidence", header: "Confidence", align: "right", sortValue: (s) => s.confidence, render: (s) => <span className="stat-tabular">{s.confidence}%</span> },
    { key: "risk", header: "Risk", render: (s) => <RiskLevelBadge level={s.riskLevel} /> },
    { key: "horizon", header: "Horizon", render: (s) => <span className="text-xs text-ink-400">{s.timeHorizon}</span> },
    { key: "price", header: "Price", align: "right", sortValue: (s) => s.price, render: (s) => <span className="stat-tabular">{formatCurrency(s.price)}</span> },
    { key: "reason", header: "Top reason", render: (s) => <span className="text-xs text-ink-500">{s.reasons[0] ?? "—"}</span> },
    { key: "updated", header: "Updated", render: (s) => <span className="text-xs text-ink-600">{formatRelativeTime(s.timestamp)}</span> },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">AI Signals</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Algorithmic model output across the supported universe. Signals are probabilistic reads on current
          conditions, not guarantees — open a ticker for the full reasoning, bull case, and bear case.
        </p>
      </div>
      <DataTable columns={columns} rows={signals} rowKey={(s) => s.ticker} defaultSortKey="confidence" />
    </div>
  );
}
