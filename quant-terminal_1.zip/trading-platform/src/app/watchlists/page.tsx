import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { getMarketDataProvider } from "@/lib/market-data";
import { SignInPrompt } from "@/components/ui/SignInPrompt";
import { WatchlistsClient } from "@/components/watchlist/WatchlistsClient";

export const revalidate = 0;

export default async function WatchlistsPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <div className="mx-auto max-w-7xl">
        <SignInPrompt feature="watchlists" />
      </div>
    );
  }

  const watchlists = await prisma.watchlist.findMany({
    where: { userId: user.id },
    orderBy: { sortOrder: "asc" },
    include: { items: { orderBy: { sortOrder: "asc" } } },
  });

  const allTickers = Array.from(new Set(watchlists.flatMap((w) => w.items.map((i) => i.ticker))));
  const quotes = await getMarketDataProvider().getQuotes(allTickers);

  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Watchlists</h1>
        <p className="mt-0.5 text-sm text-ink-500">Group tickers into custom lists and monitor them at a glance.</p>
      </div>
      <WatchlistsClient
        initialWatchlists={watchlists.map((w) => ({
          id: w.id,
          name: w.name,
          items: w.items.map((i) => ({ id: i.id, ticker: i.ticker })),
        }))}
        quotes={quotes}
      />
    </div>
  );
}
