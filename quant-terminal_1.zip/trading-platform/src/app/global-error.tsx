"use client";

// This is the one boundary that also catches errors thrown by the root
// layout itself (e.g. getMarketDataProvider() throwing because
// MARKET_DATA_PROVIDER is set to an unregistered vendor name). Because it
// replaces the root layout when triggered, it has to render its own
// <html>/<body> and can't rely on Tailwind's design tokens loading — kept
// intentionally plain.

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  return (
    <html lang="en">
      <body style={{ background: "#05070A", color: "#F3F5F8", fontFamily: "system-ui, sans-serif" }}>
        <div style={{ maxWidth: 420, margin: "80px auto", textAlign: "center", padding: "0 16px" }}>
          <h1 style={{ fontSize: 18, fontWeight: 600 }}>Application error</h1>
          <p style={{ marginTop: 8, fontSize: 14, color: "#8B93A3", lineHeight: 1.5 }}>
            The app failed to start — this usually means a required environment variable is missing or misconfigured
            (check <code>MARKET_DATA_PROVIDER</code> and <code>DATABASE_URL</code>). See the README.
          </p>
          {error.digest && <p style={{ marginTop: 8, fontSize: 11, color: "#5B6274", fontFamily: "monospace" }}>Ref: {error.digest}</p>}
          <button
            onClick={() => reset()}
            style={{ marginTop: 20, background: "#E8A33D", color: "#05070A", border: "none", borderRadius: 6, padding: "8px 16px", fontSize: 14, fontWeight: 600, cursor: "pointer" }}
          >
            Try again
          </button>
        </div>
      </body>
    </html>
  );
}
