import Link from "next/link";
import { getMarketDataProvider } from "@/lib/market-data";
import { Card, CardHeader } from "@/components/ui/Card";

export const revalidate = 0;

export default async function EventsPage() {
  const provider = getMarketDataProvider();
  const events = await provider.getEarningsCalendar(60);

  const grouped = new Map<string, typeof events>();
  for (const e of events) {
    if (!grouped.has(e.date)) grouped.set(e.date, []);
    grouped.get(e.date)!.push(e);
  }
  const dates = Array.from(grouped.keys()).sort();

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Earnings & Events</h1>
        <p className="mt-0.5 text-sm text-ink-500">Upcoming earnings announcements over the next 60 days for the supported universe.</p>
      </div>

      {dates.length === 0 ? (
        <p className="text-sm text-ink-500">No upcoming events in this window.</p>
      ) : (
        dates.map((date) => (
          <Card key={date}>
            <CardHeader title={new Date(date).toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })} />
            <ul className="divide-y divide-base-700">
              {grouped.get(date)!.map((e) => (
                <li key={e.ticker} className="flex items-center justify-between gap-3 py-2">
                  <Link href={`/stock/${e.ticker}`} className="min-w-0 hover:text-amber">
                    <p className="font-mono text-sm font-medium text-ink-100">{e.ticker}</p>
                    <p className="truncate text-xs text-ink-500">{e.companyName}</p>
                  </Link>
                  <div className="text-right text-xs text-ink-400">
                    <p>{e.timeOfDay === "before_open" ? "Before open" : e.timeOfDay === "after_close" ? "After close" : "Time TBD"}</p>
                    {e.epsEstimate !== null && <p className="text-ink-500">EPS est. ${e.epsEstimate.toFixed(2)}</p>}
                  </div>
                </li>
              ))}
            </ul>
          </Card>
        ))
      )}
    </div>
  );
}
