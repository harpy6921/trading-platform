import Link from "next/link";
import { scanRisks } from "@/lib/ai/pipeline";
import { SignalBadge, RiskLevelBadge } from "@/components/stock/SignalBadge";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { cx, formatCurrency, formatPct } from "@/lib/utils/format";
import type { RiskScanResult } from "@/types";

export const revalidate = 0;

export default async function RiskScannerPage() {
  const results = await scanRisks(40);

  const columns: Column<RiskScanResult>[] = [
    {
      key: "ticker",
      header: "Ticker",
      sortValue: (r) => r.ticker,
      render: (r) => (
        <Link href={`/stock/${r.ticker}`} className="font-mono font-medium text-ink-100 hover:text-amber">
          {r.ticker}
        </Link>
      ),
    },
    { key: "company", header: "Company", render: (r) => <span className="truncate text-xs text-ink-500">{r.companyName}</span> },
    { key: "score", header: "Risk Score", align: "right", sortValue: (r) => r.riskScore, render: (r) => <span className="stat-tabular text-base font-semibold text-fall">{r.riskScore}</span> },
    { key: "signal", header: "Signal", render: (r) => <SignalBadge signal={r.signal} size="sm" /> },
    { key: "confidence", header: "Confidence", align: "right", sortValue: (r) => r.confidence, render: (r) => <span className="stat-tabular">{r.confidence}%</span> },
    { key: "risk", header: "Risk Level", render: (r) => <RiskLevelBadge level={r.riskLevel} /> },
    { key: "price", header: "Price", align: "right", sortValue: (r) => r.price, render: (r) => <span className="stat-tabular">{formatCurrency(r.price)}</span> },
    {
      key: "chg",
      header: "Chg %",
      align: "right",
      sortValue: (r) => r.changePct,
      render: (r) => <span className={cx("stat-tabular font-medium", r.changePct >= 0 ? "text-rise" : "text-fall")}>{formatPct(r.changePct)}</span>,
    },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">AI Risk Scanner</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Ranked by Risk Score (0-100) — a composite emphasizing bearish momentum, volatility, and deteriorating
          fundamentals. A high score means more detected downside risk factors, not a predicted loss.
        </p>
      </div>
      <DataTable columns={columns} rows={results} rowKey={(r) => r.ticker} defaultSortKey="score" />
    </div>
  );
}
