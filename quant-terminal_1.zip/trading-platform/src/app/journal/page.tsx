import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { getOrCreatePrimaryAccount } from "@/lib/paper-trading/account";
import { SignInPrompt } from "@/components/ui/SignInPrompt";
import { JournalClient } from "@/components/journal/JournalClient";

export const revalidate = 0;

export default async function JournalPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <div className="mx-auto max-w-7xl">
        <SignInPrompt feature="the trade journal" />
      </div>
    );
  }

  const account = await getOrCreatePrimaryAccount(user.id);
  const [entries, recentOrders] = await Promise.all([
    prisma.journalEntry.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" }, include: { order: true } }),
    prisma.paperOrder.findMany({ where: { accountId: account.id, status: "FILLED" }, orderBy: { placedAt: "desc" }, take: 30 }),
  ]);

  return (
    <div className="mx-auto max-w-7xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Trade Journal</h1>
        <p className="mt-0.5 text-sm text-ink-500">Record your thesis before a trade, then review what actually happened.</p>
      </div>

      <JournalClient
        entries={entries.map((e) => ({
          id: e.id,
          ticker: e.ticker,
          thesis: e.thesis,
          setup: e.setup,
          confidence: e.confidence,
          timeHorizon: e.timeHorizon,
          notes: e.notes,
          outcomeNotes: e.outcomeNotes,
          aiReview: e.aiReview,
          createdAt: e.createdAt.toISOString(),
          closedAt: e.closedAt ? e.closedAt.toISOString() : null,
          order: e.order ? { ticker: e.order.ticker, side: e.order.side, fillPrice: e.order.fillPrice ? Number(e.order.fillPrice) : null } : null,
        }))}
        availableOrders={recentOrders.map((o) => ({ id: o.id, ticker: o.ticker, side: o.side, fillPrice: o.fillPrice ? Number(o.fillPrice) : null, placedAt: o.placedAt.toISOString() }))}
      />
    </div>
  );
}
