import type { Metadata, Viewport } from "next";
import { Space_Grotesk, Inter, JetBrains_Mono } from "next/font/google";
import { AppShell } from "@/components/layout/AppShell";
import { getMarketDataProvider, isDemoMode } from "@/lib/market-data";
import "./globals.css";

const display = Space_Grotesk({ subsets: ["latin"], variable: "--font-display", weight: ["500", "600", "700"] });
const body = Inter({ subsets: ["latin"], variable: "--font-body" });
const mono = JetBrains_Mono({ subsets: ["latin"], variable: "--font-mono", weight: ["400", "500", "600"] });

export const metadata: Metadata = {
  title: "Quant Terminal — AI Market Intelligence & Paper Trading",
  description:
    "AI-assisted market research, screening, and paper-trading terminal. Model signals, opportunity and risk scanning, backtesting, and portfolio analytics.",
};

export const viewport: Viewport = {
  themeColor: "#05070A",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const provider = getMarketDataProvider();
  const indices = await provider.getIndices().catch(() => []);
  const demo = isDemoMode();

  return (
    <html lang="en" className={`${display.variable} ${body.variable} ${mono.variable}`}>
      <body>
        <AppShell indices={indices} isDemo={demo}>
          {children}
        </AppShell>
      </body>
    </html>
  );
}
