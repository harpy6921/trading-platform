import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { getOrCreatePrimaryAccount } from "@/lib/paper-trading/account";
import { computePortfolioValue } from "@/lib/paper-trading/engine";
import { analyzePortfolio, computeCorrelationMatrix } from "@/lib/ai/portfolio-analyst";
import { SignInPrompt } from "@/components/ui/SignInPrompt";
import { Card, CardHeader } from "@/components/ui/Card";
import { Tooltip, METRIC_GLOSSARY } from "@/components/ui/Tooltip";
import { PortfolioEquityChart } from "@/components/portfolio/PortfolioEquityChart";
import { cx, formatCurrency, formatPct } from "@/lib/utils/format";
import Link from "next/link";

export const revalidate = 0;

export default async function PortfolioPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <div className="mx-auto max-w-7xl">
        <SignInPrompt feature="the portfolio dashboard" />
      </div>
    );
  }

  const account = await getOrCreatePrimaryAccount(user.id);
  const portfolio = await computePortfolioValue(account.id);
  const observations = await analyzePortfolio(
    portfolio.positions.map((p) => ({ ticker: p.ticker, marketValue: p.marketValue })),
    portfolio.equity
  );
  const correlation = await computeCorrelationMatrix(portfolio.positions.map((p) => p.ticker));

  const snapshots = await prisma.equitySnapshot.findMany({
    where: { accountId: account.id },
    orderBy: { takenAt: "asc" },
    take: 500,
  });

  const startingBalance = Number(account.startingBalance);
  const sorted = [...portfolio.positions].sort((a, b) => b.marketValue - a.marketValue);
  const best = [...portfolio.positions].sort((a, b) => b.unrealizedPnlPct - a.unrealizedPnlPct)[0];
  const worst = [...portfolio.positions].sort((a, b) => a.unrealizedPnlPct - b.unrealizedPnlPct)[0];

  // Simple max drawdown from recorded equity snapshots
  let peak = -Infinity;
  let maxDrawdownPct = 0;
  for (const snap of snapshots) {
    const eq = Number(snap.equity);
    peak = Math.max(peak, eq);
    if (peak > 0) maxDrawdownPct = Math.max(maxDrawdownPct, ((peak - eq) / peak) * 100);
  }

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Portfolio</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Paper trading account · <span className="text-amber">simulated funds only</span>
        </p>
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatBox label="Total Equity" value={formatCurrency(portfolio.equity)} />
        <StatBox label="Cash" value={formatCurrency(portfolio.cash)} />
        <StatBox
          label="Total Return"
          value={`${formatCurrency(portfolio.totalReturn)} (${formatPct(portfolio.totalReturnPct * 100)})`}
          tone={portfolio.totalReturn >= 0 ? "rise" : "fall"}
        />
        <StatBox label="Starting Balance" value={formatCurrency(startingBalance)} />
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <Card>
            <CardHeader title="Equity Curve" subtitle="Recorded at each simulated trade" />
            <PortfolioEquityChart data={snapshots.map((s) => ({ time: s.takenAt.toISOString(), equity: Number(s.equity) }))} />
          </Card>

          <Card>
            <CardHeader title="Open Positions" subtitle={`${portfolio.positions.length} position${portfolio.positions.length === 1 ? "" : "s"}`} />
            {portfolio.positions.length === 0 ? (
              <p className="text-sm text-ink-500">
                No open positions.{" "}
                <Link href="/paper-trading" className="text-amber hover:underline">
                  Place a trade
                </Link>{" "}
                to get started.
              </p>
            ) : (
              <ul className="divide-y divide-base-700">
                {sorted.map((p) => (
                  <li key={p.ticker} className="flex items-center justify-between gap-3 py-2.5">
                    <Link href={`/stock/${p.ticker}`} className="min-w-0 hover:text-amber">
                      <p className="font-mono text-sm font-medium text-ink-100">{p.ticker}</p>
                      <p className="text-xs text-ink-500">
                        {p.quantity} sh @ avg {formatCurrency(p.avgCostBasis)}
                      </p>
                    </Link>
                    <div className="text-right">
                      <p className="stat-tabular text-sm text-ink-100">{formatCurrency(p.marketValue)}</p>
                      <p className={cx("stat-tabular text-xs font-medium", p.unrealizedPnl >= 0 ? "text-rise" : "text-fall")}>
                        {formatCurrency(p.unrealizedPnl)} ({formatPct(p.unrealizedPnlPct * 100)})
                      </p>
                    </div>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          {correlation && (
            <Card>
              <CardHeader title="Correlation & Diversification" subtitle="30 trading-day return correlation between held positions" />
              <div className="overflow-x-auto">
                <table className="border-collapse text-xs">
                  <thead>
                    <tr>
                      <th className="p-1.5" />
                      {correlation.tickers.map((t) => (
                        <th key={t} className="p-1.5 font-mono text-ink-400">
                          {t}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {correlation.matrix.map((row, i) => (
                      <tr key={correlation.tickers[i]}>
                        <td className="p-1.5 font-mono text-ink-400">{correlation.tickers[i]}</td>
                        {row.map((v, j) => (
                          <td
                            key={j}
                            className={cx(
                              "stat-tabular p-1.5 text-center",
                              v > 0.6 ? "bg-fall/15 text-fall" : v < -0.2 ? "bg-rise/15 text-rise" : "text-ink-400"
                            )}
                          >
                            {v.toFixed(2)}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="mt-2 text-xs text-ink-500">
                Values near 1.0 mean two positions have historically moved together (concentration risk); near -1.0
                means they've historically moved opposite each other.
              </p>
            </Card>
          )}
        </div>

        <div className="space-y-5">
          <Card>
            <CardHeader title="Risk Statistics" />
            <div className="grid grid-cols-2 gap-2">
              <MiniStat label="Max Drawdown" value={snapshots.length ? formatPct(-maxDrawdownPct, { signed: false }) : "Data unavailable"} glossary="Drawdown" />
              <MiniStat label="Positions" value={String(portfolio.positions.length)} />
              <MiniStat label="Best Position" value={best ? `${best.ticker} ${formatPct(best.unrealizedPnlPct * 100)}` : "—"} />
              <MiniStat label="Worst Position" value={worst ? `${worst.ticker} ${formatPct(worst.unrealizedPnlPct * 100)}` : "—"} />
            </div>
          </Card>

          <Card>
            <CardHeader title="AI Portfolio Analyst" subtitle="Observations, not instructions" />
            <ul className="space-y-2.5">
              {observations.map((o, i) => (
                <li
                  key={i}
                  className={cx(
                    "rounded-md border p-2.5 text-sm leading-relaxed",
                    o.severity === "warning" ? "border-fall/25 bg-fall/5 text-ink-200" : o.severity === "notice" ? "border-amber/25 bg-amber/5 text-ink-200" : "border-base-600 bg-base-900/40 text-ink-300"
                  )}
                >
                  {o.text}
                </li>
              ))}
            </ul>
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value, tone }: { label: string; value: string; tone?: "rise" | "fall" }) {
  return (
    <div className="panel px-3 py-2.5">
      <p className="text-[10px] uppercase tracking-wide text-ink-500">{label}</p>
      <p className={cx("stat-tabular mt-0.5 text-sm font-medium", tone === "rise" && "text-rise", tone === "fall" && "text-fall", !tone && "text-ink-100")}>
        {value}
      </p>
    </div>
  );
}

function MiniStat({ label, value, glossary }: { label: string; value: string; glossary?: keyof typeof METRIC_GLOSSARY }) {
  return (
    <div className="rounded-md border border-base-600 bg-base-900/50 p-2.5">
      <p className="flex items-center text-[10px] uppercase tracking-wide text-ink-500">
        {label}
        {glossary && <Tooltip label={glossary}>{METRIC_GLOSSARY[glossary]}</Tooltip>}
      </p>
      <p className="stat-tabular mt-0.5 text-sm font-medium text-ink-100">{value}</p>
    </div>
  );
}
