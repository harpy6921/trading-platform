"use client";

import { useEffect } from "react";
import { AlertOctagon } from "lucide-react";

export default function GlobalError({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    // eslint-disable-next-line no-console
    console.error("[unhandled_error]", error);
  }, [error]);

  return (
    <div className="mx-auto flex max-w-md flex-col items-center py-20 text-center">
      <AlertOctagon size={28} className="mb-3 text-fall" />
      <h1 className="font-display text-lg font-semibold text-ink-100">Something went wrong</h1>
      <p className="mt-1.5 text-sm text-ink-500">
        An unexpected error occurred loading this page. This has been logged; you can try again below.
      </p>
      {error.digest && <p className="mt-2 font-mono text-[11px] text-ink-700">Ref: {error.digest}</p>}
      <button onClick={() => reset()} className="mt-5 rounded-md bg-amber px-4 py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright">
        Try again
      </button>
    </div>
  );
}
