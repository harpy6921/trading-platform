import { notFound } from "next/navigation";
import type { Metadata } from "next";
import { getMarketDataProvider } from "@/lib/market-data";
import { getSignalForTicker } from "@/lib/ai/pipeline";
import { detectSetups } from "@/lib/ai/setups";
import { StockChart } from "@/components/stock/StockChart";
import { AISignalPanel, ScorePanel } from "@/components/stock/AISignalPanel";
import { FundamentalsPanel } from "@/components/stock/FundamentalsPanel";
import { NewsList } from "@/components/stock/NewsList";
import { Card, CardHeader } from "@/components/ui/Card";
import { SignalBadge } from "@/components/stock/SignalBadge";
import { formatCurrency, formatPct, formatMarketCap, formatCompactNumber, cx } from "@/lib/utils/format";
import { WatchlistAddButton } from "@/components/stock/WatchlistAddButton";
import { PaperTradeButton } from "@/components/stock/PaperTradeButton";

export const revalidate = 0;

export async function generateMetadata({ params }: { params: { ticker: string } }): Promise<Metadata> {
  const ticker = params.ticker.toUpperCase();
  const quote = await getMarketDataProvider().getQuote(ticker);
  if (!quote) return { title: `${ticker} — Quant Terminal` };
  return {
    title: `${quote.ticker} · ${quote.companyName} — Quant Terminal`,
    description: `AI signal, chart, fundamentals, and news for ${quote.companyName} (${quote.ticker}).`,
  };
}

export default async function StockPage({ params }: { params: { ticker: string } }) {
  const ticker = params.ticker.toUpperCase();
  const provider = getMarketDataProvider();

  const [quote, fundamentals, initialCandles, setupCandles, news, signal] = await Promise.all([
    provider.getQuote(ticker),
    provider.getFundamentals(ticker),
    provider.getCandles(ticker, "3M"),
    provider.getCandles(ticker, "6M"),
    provider.getNews({ ticker, limit: 10 }),
    getSignalForTicker(ticker),
  ]);

  if (!quote) notFound();

  const setups = detectSetups(ticker, quote.companyName, setupCandles);
  const positive = quote.changePct >= 0;

  return (
    <div className="mx-auto max-w-7xl space-y-5">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="font-mono text-2xl font-semibold text-ink-100">{ticker}</h1>
            {signal && <SignalBadge signal={signal.signal} />}
          </div>
          <p className="text-sm text-ink-500">{quote.companyName}</p>
        </div>

        <div className="text-right">
          <p className="stat-tabular text-2xl font-semibold text-ink-100">{formatCurrency(quote.price)}</p>
          <p className={cx("stat-tabular text-sm font-medium", positive ? "text-rise" : "text-fall")}>
            {positive ? "+" : ""}
            {quote.change.toFixed(2)} ({formatPct(quote.changePct)})
          </p>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        <WatchlistAddButton ticker={ticker} />
        <PaperTradeButton ticker={ticker} price={quote.price} />
      </div>

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <StatBox label="Market Cap" value={formatMarketCap(quote.marketCap)} />
        <StatBox label="Volume" value={formatCompactNumber(quote.volume)} />
        <StatBox label="Avg Volume (10D)" value={formatCompactNumber(quote.avgVolume10d)} />
        <StatBox label="Day Range" value={`${quote.dayLow.toFixed(2)} – ${quote.dayHigh.toFixed(2)}`} />
      </div>

      <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <StockChart ticker={ticker} initialCandles={initialCandles} />
          <FundamentalsPanel fundamentals={fundamentals} />
          <Card>
            <CardHeader title="News & Sentiment" subtitle={`Latest headlines for ${ticker}`} />
            <NewsList items={news} />
          </Card>
        </div>

        <div className="space-y-5">
          {signal ? (
            <>
              <ScorePanel opportunityScore={signal.opportunityScore} riskScore={signal.riskScore} />
              <AISignalPanel signal={signal} />
            </>
          ) : (
            <Card>
              <CardHeader title="AI Analysis" />
              <p className="text-sm text-ink-500">Data unavailable — not enough price history to generate a model signal.</p>
            </Card>
          )}

          <Card>
            <CardHeader title="Detected Setups" subtitle="Evidence-based, not predictions" />
            {setups.length === 0 ? (
              <p className="text-sm text-ink-500">No recognizable setups detected right now.</p>
            ) : (
              <ul className="space-y-3">
                {setups.map((s, i) => (
                  <li key={i} className="rounded-md border border-base-600 bg-base-900/50 p-2.5">
                    <p className="text-sm font-medium text-ink-100">{s.setupType}</p>
                    <ul className="mt-1 space-y-0.5">
                      {s.evidence.map((e, j) => (
                        <li key={j} className="text-xs text-ink-500">
                          • {e}
                        </li>
                      ))}
                    </ul>
                  </li>
                ))}
              </ul>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="panel px-3 py-2.5">
      <p className="text-[10px] uppercase tracking-wide text-ink-500">{label}</p>
      <p className="stat-tabular mt-0.5 text-sm font-medium text-ink-100">{value}</p>
    </div>
  );
}
