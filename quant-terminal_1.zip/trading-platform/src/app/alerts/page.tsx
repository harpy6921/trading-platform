import { getCurrentUser } from "@/lib/auth/session";
import { prisma } from "@/lib/db/prisma";
import { evaluateActiveAlerts } from "@/lib/alerts/evaluate";
import { SignInPrompt } from "@/components/ui/SignInPrompt";
import { AlertsClient } from "@/components/alerts/AlertsClient";

export const revalidate = 0;

export default async function AlertsPage() {
  const user = await getCurrentUser();
  if (!user) {
    return (
      <div className="mx-auto max-w-7xl">
        <SignInPrompt feature="alerts" />
      </div>
    );
  }

  await evaluateActiveAlerts(user.id).catch(() => null);
  const alerts = await prisma.alert.findMany({ where: { userId: user.id }, orderBy: { createdAt: "desc" } });

  return (
    <div className="mx-auto max-w-4xl space-y-4">
      <div>
        <h1 className="font-display text-xl font-semibold text-ink-100">Alerts</h1>
        <p className="mt-0.5 text-sm text-ink-500">
          Create conditions to watch for. This build triggers alerts on demand when you check this page — connect
          email or push delivery later by wiring a notifier into this same alert model.
        </p>
      </div>
      <AlertsClient
        initialAlerts={alerts.map((a) => ({
          id: a.id,
          ticker: a.ticker,
          condition: a.condition,
          threshold: a.threshold ? Number(a.threshold) : null,
          status: a.status,
          note: a.note,
          createdAt: a.createdAt.toISOString(),
        }))}
      />
    </div>
  );
}
