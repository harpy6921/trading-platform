import Link from "next/link";
import { SearchX } from "lucide-react";

export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-md flex-col items-center py-20 text-center">
      <SearchX size={28} className="mb-3 text-ink-600" />
      <h1 className="font-display text-lg font-semibold text-ink-100">Not found</h1>
      <p className="mt-1.5 text-sm text-ink-500">
        This ticker or page isn't in the supported universe. Try searching from the top bar, or head back to the
        dashboard.
      </p>
      <Link href="/" className="mt-5 rounded-md bg-amber px-4 py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright">
        Back to Dashboard
      </Link>
    </div>
  );
}
