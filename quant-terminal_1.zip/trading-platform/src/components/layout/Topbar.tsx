"use client";

import { Menu } from "lucide-react";
import { GlobalSearch } from "./GlobalSearch";
import { DemoModeBadge } from "./DemoModeBanner";

export function Topbar({ onMenuClick, isDemo }: { onMenuClick: () => void; isDemo: boolean }) {
  return (
    <header className="flex h-14 items-center gap-3 border-b border-base-600 bg-base-900/80 px-4 backdrop-blur sm:px-6">
      <button onClick={onMenuClick} className="text-ink-300 lg:hidden" aria-label="Open navigation">
        <Menu size={20} />
      </button>
      <GlobalSearch />
      <div className="ml-auto flex items-center gap-3">
        {isDemo && <DemoModeBadge compact />}
      </div>
    </header>
  );
}
