"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, Loader2 } from "lucide-react";

interface SearchResult {
  ticker: string;
  companyName: string;
  type: "stock" | "etf";
}

export function GlobalSearch() {
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [open, setOpen] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const router = useRouter();

  useEffect(() => {
    function onClickOutside(e: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onClickOutside);
    return () => document.removeEventListener("mousedown", onClickOutside);
  }, []);

  useEffect(() => {
    if (query.trim().length === 0) {
      setResults([]);
      return;
    }
    setLoading(true);
    const handle = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(query)}`);
        const json = await res.json();
        setResults(json.ok ? json.data : []);
      } finally {
        setLoading(false);
      }
    }, 200);
    return () => clearTimeout(handle);
  }, [query]);

  function goTo(ticker: string) {
    setOpen(false);
    setQuery("");
    router.push(`/stock/${ticker}`);
  }

  return (
    <div ref={containerRef} className="relative w-full max-w-sm">
      <div className="flex items-center gap-2 rounded-md border border-base-600 bg-base-900 px-3 py-1.5 focus-within:border-amber/50">
        <Search size={14} className="text-ink-500" aria-hidden />
        <input
          type="text"
          value={query}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
          placeholder="Search ticker or company…"
          aria-label="Search ticker or company"
          className="w-full bg-transparent text-sm text-ink-100 placeholder:text-ink-700 focus:outline-none"
        />
        {loading && <Loader2 size={13} className="animate-spin text-ink-500" aria-hidden />}
      </div>

      {open && results.length > 0 && (
        <ul className="absolute z-40 mt-1 w-full overflow-hidden rounded-md border border-base-500 bg-base-700 shadow-panel">
          {results.map((r) => (
            <li key={r.ticker}>
              <button
                onClick={() => goTo(r.ticker)}
                className="flex w-full items-center justify-between px-3 py-2 text-left text-sm hover:bg-base-600"
              >
                <span className="font-mono font-medium text-ink-100">{r.ticker}</span>
                <span className="truncate pl-3 text-xs text-ink-500">{r.companyName}</span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
