import { cx, formatPct } from "@/lib/utils/format";
import type { IndexQuote } from "@/lib/market-data/types";

export function TickerTape({ indices }: { indices: IndexQuote[] }) {
  const doubled = [...indices, ...indices]; // seamless loop

  return (
    <div className="overflow-hidden border-b border-base-600 bg-base-900">
      <div className="flex w-max animate-ticker py-1.5">
        {doubled.map((idx, i) => (
          <div key={`${idx.symbol}-${i}`} className="flex items-center gap-2 whitespace-nowrap px-5 text-xs">
            <span className="font-mono font-semibold text-ink-300">{idx.symbol}</span>
            <span className="stat-tabular text-ink-100">{idx.value.toLocaleString(undefined, { maximumFractionDigits: 2 })}</span>
            <span
              className={cx(
                "stat-tabular font-medium",
                idx.changePct >= 0 ? "text-rise" : "text-fall"
              )}
            >
              {formatPct(idx.changePct)}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
