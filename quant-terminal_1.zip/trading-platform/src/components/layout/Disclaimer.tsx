export function Disclaimer() {
  return (
    <footer className="border-t border-base-600 px-4 py-4 sm:px-6">
      <p className="mx-auto max-w-5xl text-center text-[11px] leading-relaxed text-ink-700">
        AI-generated signals, scores, and scenarios are algorithmic model output for informational and
        educational purposes only — not financial advice, and not a guarantee or promise of future
        results. Predictions are probabilistic and may be wrong. Past performance, including
        backtested and paper-trading performance, does not guarantee future results. Paper trading
        uses simulated money only. Review the model's disclosed reasoning and reach your own
        conclusions before acting on anything shown here.
      </p>
    </footer>
  );
}
