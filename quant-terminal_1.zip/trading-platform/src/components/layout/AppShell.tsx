"use client";

import { useState, type ReactNode } from "react";
import { Sidebar } from "./Sidebar";
import { Topbar } from "./Topbar";
import { TickerTape } from "./TickerTape";
import { DemoModeBanner } from "./DemoModeBanner";
import { Disclaimer } from "./Disclaimer";
import type { IndexQuote } from "@/lib/market-data/types";

export function AppShell({
  children,
  indices,
  isDemo,
}: {
  children: ReactNode;
  indices: IndexQuote[];
  isDemo: boolean;
}) {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="flex min-h-screen">
      <Sidebar mobileOpen={mobileOpen} onClose={() => setMobileOpen(false)} />
      <div className="flex min-h-screen flex-1 flex-col">
        <Topbar onMenuClick={() => setMobileOpen(true)} isDemo={isDemo} />
        {indices.length > 0 && <TickerTape indices={indices} />}
        {isDemo && <DemoModeBanner />}
        <main className="flex-1 px-4 py-5 sm:px-6 sm:py-6">{children}</main>
        <Disclaimer />
      </div>
    </div>
  );
}
