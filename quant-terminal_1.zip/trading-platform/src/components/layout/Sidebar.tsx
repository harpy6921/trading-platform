"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { cx } from "@/lib/utils/format";
import {
  LayoutDashboard,
  Sparkles,
  Target,
  ShieldAlert,
  SlidersHorizontal,
  LineChart,
  PieChart,
  ListChecks,
  Briefcase,
  Wallet,
  BookOpen,
  FlaskConical,
  Newspaper,
  CalendarClock,
  BarChart3,
  Bell,
  Settings,
  X,
} from "lucide-react";

const NAV_GROUPS: { label: string; items: { href: string; label: string; icon: typeof LayoutDashboard }[] }[] = [
  {
    label: "Research",
    items: [
      { href: "/", label: "Dashboard", icon: LayoutDashboard },
      { href: "/signals", label: "AI Signals", icon: Sparkles },
      { href: "/opportunities", label: "Opportunities", icon: Target },
      { href: "/risk-scanner", label: "Risk Scanner", icon: ShieldAlert },
      { href: "/screener", label: "Screener", icon: SlidersHorizontal },
      { href: "/markets", label: "Markets", icon: LineChart },
      { href: "/sectors", label: "Sectors", icon: PieChart },
      { href: "/news", label: "News", icon: Newspaper },
      { href: "/events", label: "Events", icon: CalendarClock },
    ],
  },
  {
    label: "Trading",
    items: [
      { href: "/watchlists", label: "Watchlists", icon: ListChecks },
      { href: "/portfolio", label: "Portfolio", icon: Briefcase },
      { href: "/paper-trading", label: "Paper Trading", icon: Wallet },
      { href: "/journal", label: "Trade Journal", icon: BookOpen },
      { href: "/backtesting", label: "Backtesting", icon: FlaskConical },
      { href: "/performance", label: "Performance", icon: BarChart3 },
    ],
  },
  {
    label: "Account",
    items: [
      { href: "/alerts", label: "Alerts", icon: Bell },
      { href: "/settings", label: "Settings", icon: Settings },
    ],
  },
];

export function Sidebar({ mobileOpen, onClose }: { mobileOpen: boolean; onClose: () => void }) {
  const pathname = usePathname();

  return (
    <>
      {mobileOpen && (
        <div className="fixed inset-0 z-40 bg-black/60 lg:hidden" onClick={onClose} aria-hidden />
      )}
      <aside
        className={cx(
          "fixed inset-y-0 left-0 z-50 w-64 -translate-x-full border-r border-base-600 bg-base-900 transition-transform lg:sticky lg:top-0 lg:h-screen lg:translate-x-0",
          mobileOpen && "translate-x-0"
        )}
      >
        <div className="flex h-14 items-center justify-between border-b border-base-600 px-4">
          <Link href="/" className="flex items-center gap-2">
            <span className="flex h-6 w-6 items-center justify-center rounded bg-amber font-display text-xs font-bold text-base-950">
              Q
            </span>
            <span className="font-display text-sm font-semibold tracking-wide text-ink-100">
              QUANT TERMINAL
            </span>
          </Link>
          <button onClick={onClose} className="text-ink-500 lg:hidden" aria-label="Close navigation">
            <X size={18} />
          </button>
        </div>

        <nav className="h-[calc(100%-3.5rem)] overflow-y-auto px-2 py-4">
          {NAV_GROUPS.map((group) => (
            <div key={group.label} className="mb-5">
              <p className="mb-1.5 px-2 text-[10px] font-semibold uppercase tracking-wider text-ink-700">
                {group.label}
              </p>
              <ul className="space-y-0.5">
                {group.items.map((item) => {
                  const active = pathname === item.href || (item.href !== "/" && pathname?.startsWith(item.href));
                  const Icon = item.icon;
                  return (
                    <li key={item.href}>
                      <Link
                        href={item.href}
                        onClick={onClose}
                        className={cx(
                          "flex items-center gap-2.5 rounded-md px-2.5 py-1.5 text-sm transition-colors",
                          active
                            ? "bg-amber/10 text-amber"
                            : "text-ink-300 hover:bg-base-700 hover:text-ink-100"
                        )}
                      >
                        <Icon size={15} aria-hidden />
                        {item.label}
                      </Link>
                    </li>
                  );
                })}
              </ul>
            </div>
          ))}
        </nav>
      </aside>
    </>
  );
}
