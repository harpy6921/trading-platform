"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Plus, Trash2, X } from "lucide-react";
import { SignalBadge } from "@/components/stock/SignalBadge";
import { formatCurrency, formatPct, cx } from "@/lib/utils/format";
import type { Quote } from "@/lib/market-data/types";

interface WatchlistItem {
  id: string;
  ticker: string;
}
interface Watchlist {
  id: string;
  name: string;
  items: WatchlistItem[];
}

export function WatchlistsClient({ initialWatchlists, quotes }: { initialWatchlists: Watchlist[]; quotes: Quote[] }) {
  const [activeId, setActiveId] = useState(initialWatchlists[0]?.id);
  const [newListName, setNewListName] = useState("");
  const [newTicker, setNewTicker] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  const quoteByTicker = new Map(quotes.map((q) => [q.ticker, q]));
  const active = initialWatchlists.find((w) => w.id === activeId) ?? initialWatchlists[0];

  async function createWatchlist() {
    if (!newListName.trim()) return;
    setBusy(true);
    try {
      await fetch("/api/watchlists", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: newListName.trim() }),
      });
      setNewListName("");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  async function deleteWatchlist(id: string) {
    setBusy(true);
    try {
      await fetch(`/api/watchlists/${id}`, { method: "DELETE" });
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  async function addTicker() {
    if (!active || !newTicker.trim()) return;
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/watchlists/${active.id}/items`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticker: newTicker.trim().toUpperCase() }),
      });
      const json = await res.json();
      if (!json.ok) {
        setError(json.error);
        return;
      }
      setNewTicker("");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  async function removeItem(itemId: string) {
    if (!active) return;
    setBusy(true);
    try {
      await fetch(`/api/watchlists/${active.id}/items/${itemId}`, { method: "DELETE" });
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-4">
      <div className="panel space-y-1 p-3 lg:col-span-1">
        <p className="mb-2 text-xs font-semibold uppercase tracking-wider text-ink-500">Your lists</p>
        <ul className="space-y-0.5">
          {initialWatchlists.map((w) => (
            <li key={w.id} className="group flex items-center">
              <button
                onClick={() => setActiveId(w.id)}
                className={cx(
                  "flex-1 rounded-md px-2.5 py-1.5 text-left text-sm",
                  active?.id === w.id ? "bg-amber/10 text-amber" : "text-ink-300 hover:bg-base-700"
                )}
              >
                {w.name} <span className="text-ink-600">({w.items.length})</span>
              </button>
              <button onClick={() => deleteWatchlist(w.id)} className="hidden pr-1 text-ink-600 hover:text-fall group-hover:block" aria-label={`Delete ${w.name}`}>
                <Trash2 size={13} />
              </button>
            </li>
          ))}
        </ul>

        <div className="mt-3 flex gap-1 border-t border-base-700 pt-3">
          <input
            value={newListName}
            onChange={(e) => setNewListName(e.target.value)}
            placeholder="New list name"
            className="w-full rounded border border-base-600 bg-base-900 px-2 py-1 text-xs text-ink-100"
          />
          <button onClick={createWatchlist} disabled={busy} className="rounded bg-base-600 px-2 text-ink-200 hover:bg-base-500">
            <Plus size={14} />
          </button>
        </div>
      </div>

      <div className="panel p-4 lg:col-span-3">
        {!active ? (
          <p className="text-sm text-ink-500">Create your first watchlist to get started.</p>
        ) : (
          <>
            <div className="mb-3 flex items-center gap-2">
              <input
                value={newTicker}
                onChange={(e) => setNewTicker(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && addTicker()}
                placeholder="Add ticker (e.g. AAPL)"
                className="w-48 rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100"
              />
              <button onClick={addTicker} disabled={busy} className="rounded-md bg-amber px-3 py-1.5 text-xs font-semibold text-base-950 hover:bg-amber-bright">
                Add
              </button>
              {error && <span className="text-xs text-fall">{error}</span>}
            </div>

            {active.items.length === 0 ? (
              <p className="text-sm text-ink-500">No tickers in this list yet.</p>
            ) : (
              <ul className="divide-y divide-base-700">
                {active.items.map((item) => {
                  const q = quoteByTicker.get(item.ticker);
                  return (
                    <li key={item.id} className="flex items-center justify-between gap-3 py-2.5">
                      <Link href={`/stock/${item.ticker}`} className="min-w-0 hover:text-amber">
                        <p className="font-mono text-sm font-medium text-ink-100">{item.ticker}</p>
                        {q && <p className="truncate text-xs text-ink-500">{q.companyName}</p>}
                      </Link>
                      {q && (
                        <>
                          <div className="text-right">
                            <p className="stat-tabular text-sm text-ink-100">{formatCurrency(q.price)}</p>
                            <p className={cx("stat-tabular text-xs font-medium", q.changePct >= 0 ? "text-rise" : "text-fall")}>{formatPct(q.changePct)}</p>
                          </div>
                        </>
                      )}
                      <button onClick={() => removeItem(item.id)} className="text-ink-600 hover:text-fall" aria-label={`Remove ${item.ticker}`}>
                        <X size={15} />
                      </button>
                    </li>
                  );
                })}
              </ul>
            )}
          </>
        )}
      </div>
    </div>
  );
}
