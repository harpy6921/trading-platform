"use client";

import { useId, useState } from "react";
import { HelpCircle } from "lucide-react";

export function Tooltip({ label, children }: { label: string; children: string }) {
  const [open, setOpen] = useState(false);
  const id = useId();

  return (
    <span className="relative inline-flex items-center">
      <button
        type="button"
        aria-describedby={id}
        onMouseEnter={() => setOpen(true)}
        onMouseLeave={() => setOpen(false)}
        onFocus={() => setOpen(true)}
        onBlur={() => setOpen(false)}
        className="ml-1 inline-flex text-ink-500 hover:text-amber transition-colors"
      >
        <span className="sr-only">What is {label}?</span>
        <HelpCircle size={13} aria-hidden />
      </button>
      {open && (
        <span
          id={id}
          role="tooltip"
          className="absolute bottom-full left-1/2 z-50 mb-2 w-56 -translate-x-1/2 rounded-md border border-base-500 bg-base-700 p-2.5 text-xs leading-relaxed text-ink-300 shadow-panel"
        >
          <span className="mb-0.5 block font-semibold text-ink-100">{label}</span>
          {children}
        </span>
      )}
    </span>
  );
}

export const METRIC_GLOSSARY: Record<string, string> = {
  RSI: "Relative Strength Index (0-100). Above 70 is often read as overbought, below 30 as oversold. It measures the speed of recent price changes, not direction on its own.",
  MACD: "Moving Average Convergence/Divergence. Compares two EMAs to gauge momentum; the histogram shows whether that momentum is accelerating or fading.",
  Drawdown: "The decline from a portfolio's (or strategy's) peak value to a subsequent trough, shown as a percentage. A core measure of downside pain, separate from average returns.",
  Volatility: "Annualized standard deviation of daily returns. Higher volatility means wider, faster price swings in both directions.",
  Confidence: "The model's own estimate of how much its underlying factors agree with each other — not a probability that the signal will be correct.",
  "Opportunity Score": "0-100 composite of momentum, technicals, fundamentals, sentiment, and volume, weighted toward bullish characteristics. Higher isn't a guarantee, just a stronger composite read.",
  "Risk Score": "0-100 composite emphasizing bearish momentum, volatility, and deteriorating fundamentals. Higher means more detected downside risk factors, not a predicted loss.",
  Beta: "A stock's historical sensitivity to broad market moves. 1.0 tracks the market; above 1.0 tends to move more than the market in either direction.",
};
