import Link from "next/link";
import { LogIn } from "lucide-react";

export function SignInPrompt({ feature }: { feature: string }) {
  return (
    <div className="panel mx-auto max-w-md p-6 text-center">
      <LogIn size={20} className="mx-auto mb-2 text-ink-500" />
      <h2 className="font-display text-sm font-semibold text-ink-100">Sign in required</h2>
      <p className="mt-1 text-sm text-ink-500">Create a free account to use {feature}.</p>
      <Link href="/login" className="mt-4 inline-block rounded-md bg-amber px-4 py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright">
        Sign in / Create account
      </Link>
    </div>
  );
}
