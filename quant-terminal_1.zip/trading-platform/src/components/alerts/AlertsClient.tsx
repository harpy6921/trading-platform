"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { cx, formatRelativeTime } from "@/lib/utils/format";
import { Card, CardHeader } from "@/components/ui/Card";
import { Bell, X, Check } from "lucide-react";

const CONDITIONS = [
  { value: "SIGNAL_CHANGE", label: "AI signal changes" },
  { value: "OPPORTUNITY_SCORE_ABOVE", label: "Opportunity Score above" },
  { value: "RISK_SCORE_ABOVE", label: "Risk Score above" },
  { value: "PRICE_MOVE_PCT", label: "Price move % (abs.) above" },
  { value: "VOLUME_UNUSUAL", label: "Volume vs. 10d avg ratio above" },
  { value: "VOLATILITY_CHANGE", label: "Volatility change" },
  { value: "BREAKOUT", label: "Technical breakout detected" },
  { value: "BREAKDOWN", label: "Technical breakdown detected" },
  { value: "NEWS_EVENT", label: "Major news event" },
  { value: "EARNINGS_EVENT", label: "Earnings event" },
] as const;

interface Alert {
  id: string;
  ticker: string;
  condition: string;
  threshold: number | null;
  status: "ACTIVE" | "TRIGGERED" | "DISMISSED";
  note: string | null;
  createdAt: string;
}

export function AlertsClient({ initialAlerts }: { initialAlerts: Alert[] }) {
  const router = useRouter();
  const [tab, setTab] = useState<Alert["status"]>("ACTIVE");
  const [ticker, setTicker] = useState("");
  const [condition, setCondition] = useState<(typeof CONDITIONS)[number]["value"]>("PRICE_MOVE_PCT");
  const [threshold, setThreshold] = useState("5");

  async function create() {
    if (!ticker) return;
    await fetch("/api/alerts", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ticker: ticker.toUpperCase(), condition, threshold: threshold ? Number(threshold) : undefined }),
    });
    setTicker("");
    router.refresh();
  }

  async function setStatus(id: string, status: Alert["status"]) {
    await fetch(`/api/alerts/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    router.refresh();
  }

  const filtered = initialAlerts.filter((a) => a.status === tab);

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="lg:col-span-1">
        <Card>
          <CardHeader title="New Alert" />
          <div className="space-y-2.5">
            <input value={ticker} onChange={(e) => setTicker(e.target.value)} placeholder="Ticker" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            <select value={condition} onChange={(e) => setCondition(e.target.value as typeof condition)} className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100">
              {CONDITIONS.map((c) => (
                <option key={c.value} value={c.value}>
                  {c.label}
                </option>
              ))}
            </select>
            {condition !== "SIGNAL_CHANGE" && condition !== "BREAKOUT" && condition !== "BREAKDOWN" && condition !== "NEWS_EVENT" && condition !== "EARNINGS_EVENT" && (
              <input type="number" value={threshold} onChange={(e) => setThreshold(e.target.value)} placeholder="Threshold" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            )}
            <button onClick={create} disabled={!ticker} className="w-full rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright disabled:opacity-50">
              Create alert
            </button>
          </div>
        </Card>
      </div>

      <div className="lg:col-span-2">
        <div className="mb-3 flex gap-1">
          {(["ACTIVE", "TRIGGERED", "DISMISSED"] as const).map((t) => (
            <button key={t} onClick={() => setTab(t)} className={cx("rounded-md px-3 py-1.5 text-xs font-medium", tab === t ? "bg-amber/15 text-amber" : "text-ink-500 hover:bg-base-700")}>
              {t.charAt(0) + t.slice(1).toLowerCase()} ({initialAlerts.filter((a) => a.status === t).length})
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <p className="text-sm text-ink-500">No {tab.toLowerCase()} alerts.</p>
        ) : (
          <ul className="space-y-2">
            {filtered.map((a) => (
              <li key={a.id} className="panel flex items-center justify-between gap-3 p-3">
                <div className="flex items-center gap-2.5">
                  <Bell size={14} className={a.status === "TRIGGERED" ? "text-amber" : "text-ink-500"} />
                  <div>
                    <p className="text-sm text-ink-100">
                      <span className="font-mono font-medium">{a.ticker}</span> · {CONDITIONS.find((c) => c.value === a.condition)?.label}
                      {a.threshold !== null && <span className="text-ink-400"> {a.threshold}</span>}
                    </p>
                    <p className="text-xs text-ink-600">Created {formatRelativeTime(a.createdAt)}</p>
                  </div>
                </div>
                <div className="flex gap-1">
                  {a.status === "TRIGGERED" && (
                    <button onClick={() => setStatus(a.id, "ACTIVE")} className="rounded p-1.5 text-ink-500 hover:bg-base-700 hover:text-rise" aria-label="Reactivate">
                      <Check size={14} />
                    </button>
                  )}
                  {a.status !== "DISMISSED" && (
                    <button onClick={() => setStatus(a.id, "DISMISSED")} className="rounded p-1.5 text-ink-500 hover:bg-base-700 hover:text-fall" aria-label="Dismiss">
                      <X size={14} />
                    </button>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
