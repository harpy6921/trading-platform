"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export function AuthForm() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);
  const router = useRouter();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setError(null);
    try {
      const res = await fetch(`/api/auth/${mode === "login" ? "login" : "register"}`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(mode === "login" ? { email, password } : { email, password, displayName: displayName || undefined }),
      });
      const json = await res.json();
      if (!json.ok) {
        setError(json.error);
        return;
      }
      router.push(mode === "register" ? "/onboarding" : "/");
      router.refresh();
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto mt-16 w-full max-w-sm">
      <div className="panel p-6">
        <h1 className="font-display text-lg font-semibold text-ink-100">
          {mode === "login" ? "Sign in" : "Create your account"}
        </h1>
        <p className="mt-1 text-xs text-ink-500">
          {mode === "login" ? "Access your watchlists and paper trading account." : "Free — starts you with a $100,000 paper account."}
        </p>

        <form onSubmit={submit} className="mt-4 space-y-3">
          {mode === "register" && (
            <label className="block text-xs text-ink-500">
              Display name (optional)
              <input value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="mt-1 w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            </label>
          )}
          <label className="block text-xs text-ink-500">
            Email
            <input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="mt-1 w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
          </label>
          <label className="block text-xs text-ink-500">
            Password
            <input type="password" required minLength={8} value={password} onChange={(e) => setPassword(e.target.value)} className="mt-1 w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
          </label>

          {error && <p className="text-xs text-fall">{error}</p>}

          <button type="submit" disabled={busy} className="w-full rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright disabled:opacity-50">
            {busy ? "Please wait…" : mode === "login" ? "Sign in" : "Create account"}
          </button>
        </form>

        <button
          onClick={() => setMode((m) => (m === "login" ? "register" : "login"))}
          className="mt-4 w-full text-center text-xs text-ink-500 hover:text-amber"
        >
          {mode === "login" ? "Need an account? Create one" : "Already have an account? Sign in"}
        </button>
      </div>
    </div>
  );
}
