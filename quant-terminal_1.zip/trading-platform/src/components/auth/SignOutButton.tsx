"use client";

import { useRouter } from "next/navigation";
import { LogOut } from "lucide-react";

export function SignOutButton() {
  const router = useRouter();
  return (
    <button
      onClick={async () => {
        await fetch("/api/auth/logout", { method: "POST" });
        router.push("/");
        router.refresh();
      }}
      className="flex items-center gap-1.5 rounded-md border border-base-500 px-3 py-1.5 text-xs font-medium text-ink-300 hover:border-fall/40 hover:text-fall"
    >
      <LogOut size={13} /> Sign out
    </button>
  );
}
