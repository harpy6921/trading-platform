"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { Card, CardHeader } from "@/components/ui/Card";
import { cx, formatCurrency, formatPct } from "@/lib/utils/format";

interface Order {
  id: string;
  ticker: string;
  side: "BUY" | "SELL";
  type: "MARKET" | "LIMIT";
  quantity: number;
  fillPrice: number | null;
  commission: number;
  status: string;
  placedAt: string;
  realizedPnl: number | null;
}

interface Portfolio {
  cash: number;
  equity: number;
  totalReturn: number;
  totalReturnPct: number;
  positions: { ticker: string; quantity: number; avgCostBasis: number; currentPrice: number; marketValue: number; unrealizedPnl: number; unrealizedPnlPct: number }[];
}

export function PaperTradingClient({
  account,
  portfolio,
  orders,
}: {
  account: { id: string; name: string; startingBalance: number; commissionPerOrder: number; slippageBps: number };
  portfolio: Portfolio;
  orders: Order[];
}) {
  const router = useRouter();
  const [ticker, setTicker] = useState("");
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [type, setType] = useState<"MARKET" | "LIMIT">("MARKET");
  const [quantity, setQuantity] = useState("10");
  const [limitPrice, setLimitPrice] = useState("");
  const [message, setMessage] = useState<{ kind: "error" | "success"; text: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const [resetBalance, setResetBalance] = useState(String(account.startingBalance));
  const [resetting, setResetting] = useState(false);

  async function submitOrder() {
    setSubmitting(true);
    setMessage(null);
    try {
      const res = await fetch("/api/paper-trading/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ticker: ticker.toUpperCase(),
          side,
          type,
          quantity: Number(quantity),
          limitPrice: type === "LIMIT" ? Number(limitPrice) : undefined,
        }),
      });
      const json = await res.json();
      if (!json.ok) {
        setMessage({ kind: "error", text: json.error });
      } else {
        setMessage({ kind: "success", text: `Filled ${quantity} sh of ${ticker.toUpperCase()} at ${formatCurrency(Number(json.data.fillPrice))}.` });
        router.refresh();
      }
    } finally {
      setSubmitting(false);
    }
  }

  async function resetAccount() {
    if (!confirm("This clears all positions and order history for this paper account. Continue?")) return;
    setResetting(true);
    try {
      await fetch("/api/paper-trading/account", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ startingBalance: Number(resetBalance) }),
      });
      router.refresh();
    } finally {
      setResetting(false);
    }
  }

  const orderColumns: Column<Order>[] = [
    { key: "date", header: "Date", render: (o) => <span className="text-xs text-ink-500">{new Date(o.placedAt).toLocaleString()}</span> },
    { key: "ticker", header: "Ticker", render: (o) => <span className="font-mono text-sm text-ink-100">{o.ticker}</span> },
    {
      key: "side",
      header: "Side",
      render: (o) => <span className={cx("badge border", o.side === "BUY" ? "border-rise/30 text-rise" : "border-fall/30 text-fall")}>{o.side}</span>,
    },
    { key: "type", header: "Type", render: (o) => <span className="text-xs text-ink-400">{o.type}</span> },
    { key: "qty", header: "Qty", align: "right", render: (o) => <span className="stat-tabular">{o.quantity}</span> },
    { key: "fill", header: "Fill", align: "right", render: (o) => <span className="stat-tabular">{o.fillPrice ? formatCurrency(o.fillPrice) : "—"}</span> },
    { key: "commission", header: "Commission", align: "right", render: (o) => <span className="stat-tabular text-ink-500">{formatCurrency(o.commission)}</span> },
    {
      key: "pnl",
      header: "Realized P&L",
      align: "right",
      render: (o) => (o.realizedPnl !== null ? <span className={cx("stat-tabular", o.realizedPnl >= 0 ? "text-rise" : "text-fall")}>{formatCurrency(o.realizedPnl)}</span> : <span className="text-ink-600">—</span>),
    },
    { key: "status", header: "Status", render: (o) => <span className="text-xs text-ink-400">{o.status}</span> },
  ];

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="space-y-5 lg:col-span-2">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <StatBox label="Equity" value={formatCurrency(portfolio.equity)} />
          <StatBox label="Cash" value={formatCurrency(portfolio.cash)} />
          <StatBox label="Total Return" value={`${formatPct(portfolio.totalReturnPct * 100)}`} tone={portfolio.totalReturn >= 0 ? "rise" : "fall"} />
          <StatBox label="Positions" value={String(portfolio.positions.length)} />
        </div>

        <Card>
          <CardHeader title="Order History" />
          <DataTable columns={orderColumns} rows={orders} rowKey={(o) => o.id} emptyLabel="No orders placed yet." />
        </Card>
      </div>

      <div className="space-y-5">
        <Card>
          <CardHeader title="Place Order" subtitle="Simulated fill, commission & slippage applied" />
          <div className="space-y-2.5">
            <input value={ticker} onChange={(e) => setTicker(e.target.value)} placeholder="Ticker (e.g. AAPL)" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />

            <div className="flex gap-1">
              {(["BUY", "SELL"] as const).map((s) => (
                <button key={s} onClick={() => setSide(s)} className={cx("flex-1 rounded px-2 py-1.5 text-xs font-semibold", side === s ? (s === "BUY" ? "bg-rise/20 text-rise" : "bg-fall/20 text-fall") : "bg-base-600 text-ink-400")}>
                  {s}
                </button>
              ))}
            </div>
            <div className="flex gap-1">
              {(["MARKET", "LIMIT"] as const).map((t) => (
                <button key={t} onClick={() => setType(t)} className={cx("flex-1 rounded px-2 py-1.5 text-xs", type === t ? "bg-base-500 text-ink-100" : "bg-base-600 text-ink-500")}>
                  {t}
                </button>
              ))}
            </div>

            <input type="number" min="0" step="any" value={quantity} onChange={(e) => setQuantity(e.target.value)} placeholder="Quantity" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            {type === "LIMIT" && (
              <input type="number" min="0" step="0.01" value={limitPrice} onChange={(e) => setLimitPrice(e.target.value)} placeholder="Limit price" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            )}

            <button onClick={submitOrder} disabled={submitting || !ticker} className="w-full rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright disabled:opacity-50">
              {submitting ? "Submitting…" : `Place ${side.toLowerCase()} order`}
            </button>
            {message && <p className={cx("text-xs", message.kind === "error" ? "text-fall" : "text-rise")}>{message.text}</p>}
          </div>
        </Card>

        <Card>
          <CardHeader title="Account Settings" />
          <p className="mb-2 text-xs text-ink-500">
            Commission: {formatCurrency(account.commissionPerOrder)}/order · Slippage: {account.slippageBps} bps
          </p>
          <label className="block text-xs text-ink-500">
            Reset with new starting balance
            <div className="mt-1 flex gap-1">
              <input type="number" min="1" value={resetBalance} onChange={(e) => setResetBalance(e.target.value)} className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
              <button onClick={resetAccount} disabled={resetting} className="shrink-0 rounded-md border border-fall/30 px-3 py-1.5 text-xs font-medium text-fall hover:bg-fall/10">
                Reset
              </button>
            </div>
          </label>
          <p className="mt-2 text-[11px] text-ink-600">Resetting clears all positions and order history for this account.</p>
        </Card>

        <p className="text-xs text-ink-500">
          Log trades with your reasoning in the{" "}
          <Link href="/journal" className="text-amber hover:underline">
            Trade Journal
          </Link>
          .
        </p>
      </div>
    </div>
  );
}

function StatBox({ label, value, tone }: { label: string; value: string; tone?: "rise" | "fall" }) {
  return (
    <div className="panel px-3 py-2.5">
      <p className="text-[10px] uppercase tracking-wide text-ink-500">{label}</p>
      <p className={cx("stat-tabular mt-0.5 text-sm font-medium", tone === "rise" && "text-rise", tone === "fall" && "text-fall", !tone && "text-ink-100")}>{value}</p>
    </div>
  );
}
