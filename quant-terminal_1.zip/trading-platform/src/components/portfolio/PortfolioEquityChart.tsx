"use client";

import { AreaChart, Area, ResponsiveContainer, XAxis, YAxis, Tooltip as RTooltip, CartesianGrid } from "recharts";
import { formatCurrency } from "@/lib/utils/format";

export function PortfolioEquityChart({ data }: { data: { time: string; equity: number }[] }) {
  if (data.length < 2) {
    return <p className="py-8 text-center text-sm text-ink-500">Not enough history yet — place a few simulated trades to build an equity curve.</p>;
  }

  return (
    <div className="h-56">
      <ResponsiveContainer width="100%" height="100%">
        <AreaChart data={data} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
          <defs>
            <linearGradient id="equityGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#E8A33D" stopOpacity={0.3} />
              <stop offset="100%" stopColor="#E8A33D" stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid stroke="#161C26" vertical={false} />
          <XAxis dataKey="time" tick={{ fontSize: 10, fill: "#5B6274" }} tickFormatter={(v) => new Date(v).toLocaleDateString(undefined, { month: "short", day: "numeric" })} />
          <YAxis tick={{ fontSize: 10, fill: "#5B6274" }} domain={["auto", "auto"]} tickFormatter={(v) => formatCurrency(v, { compact: true })} width={56} />
          <RTooltip
            contentStyle={{ background: "#0F141C", border: "1px solid #1E2530", fontSize: 12 }}
            formatter={(v: number) => formatCurrency(v)}
            labelFormatter={(v) => new Date(v).toLocaleString()}
          />
          <Area type="monotone" dataKey="equity" stroke="#E8A33D" strokeWidth={1.5} fill="url(#equityGrad)" isAnimationActive={false} />
        </AreaChart>
      </ResponsiveContainer>
    </div>
  );
}
