"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { cx } from "@/lib/utils/format";
import { Tooltip, METRIC_GLOSSARY } from "@/components/ui/Tooltip";
import { Sparkles, FlaskConical, Wallet, Check } from "lucide-react";

export function OnboardingClient({ options }: { options: { ticker: string; companyName: string }[] }) {
  const [step, setStep] = useState(0);
  const [selected, setSelected] = useState<Set<string>>(new Set(["AAPL", "MSFT", "NVDA"]));
  const [startingBalance, setStartingBalance] = useState("100000");
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();

  function toggle(ticker: string) {
    setSelected((prev) => {
      const next = new Set(prev);
      next.has(ticker) ? next.delete(ticker) : next.add(ticker);
      return next;
    });
  }

  async function finish() {
    setSubmitting(true);
    try {
      await fetch("/api/onboarding", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ startingBalance: Number(startingBalance), watchlistTickers: Array.from(selected) }),
      });
      router.push("/");
      router.refresh();
    } finally {
      setSubmitting(false);
    }
  }

  const steps = ["Welcome", "Build a watchlist", "Paper account", "How it fits together"];

  return (
    <div className="panel p-6">
      <div className="mb-5 flex items-center gap-1.5">
        {steps.map((s, i) => (
          <div key={s} className={cx("h-1 flex-1 rounded-full", i <= step ? "bg-amber" : "bg-base-600")} />
        ))}
      </div>

      {step === 0 && (
        <div className="space-y-3">
          <h1 className="font-display text-lg font-semibold text-ink-100">Welcome to Quant Terminal</h1>
          <p className="text-sm leading-relaxed text-ink-300">
            An AI-assisted research and paper-trading terminal. Three things to know going in:
          </p>
          <ul className="space-y-2 text-sm text-ink-300">
            <li className="flex gap-2">
              <Sparkles size={15} className="mt-0.5 shrink-0 text-amber" />
              <span>
                <strong className="text-ink-100">AI Signals, Opportunities & Risk Scanner</strong> are algorithmic
                model output — clearly labeled confidence, reasoning, bull/bear cases. Never guarantees.
              </span>
            </li>
            <li className="flex gap-2">
              <FlaskConical size={15} className="mt-0.5 shrink-0 text-amber" />
              <span>
                <strong className="text-ink-100">Backtesting</strong> runs a rule against historical data to sanity-check
                an idea — it's a simulation of the past, not a promise about the future.
              </span>
            </li>
            <li className="flex gap-2">
              <Wallet size={15} className="mt-0.5 shrink-0 text-amber" />
              <span>
                <strong className="text-ink-100">Paper Trading</strong> is simulated money only — practice execution
                and portfolio management with zero real-world risk.
              </span>
            </li>
          </ul>
          <button onClick={() => setStep(1)} className="mt-2 w-full rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright">
            Continue
          </button>
        </div>
      )}

      {step === 1 && (
        <div className="space-y-3">
          <h2 className="font-display text-lg font-semibold text-ink-100">Build your first watchlist</h2>
          <p className="text-sm text-ink-500">Pick a few tickers to start with — you can add more anytime.</p>
          <div className="grid max-h-72 grid-cols-2 gap-1.5 overflow-y-auto sm:grid-cols-3">
            {options.map((o) => (
              <button
                key={o.ticker}
                onClick={() => toggle(o.ticker)}
                className={cx(
                  "flex items-center justify-between rounded-md border px-2.5 py-1.5 text-left text-xs",
                  selected.has(o.ticker) ? "border-amber/50 bg-amber/10 text-amber" : "border-base-600 text-ink-300 hover:border-base-500"
                )}
              >
                <span className="font-mono">{o.ticker}</span>
                {selected.has(o.ticker) && <Check size={12} />}
              </button>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={() => setStep(0)} className="rounded-md border border-base-600 px-4 py-2 text-sm text-ink-400">
              Back
            </button>
            <button onClick={() => setStep(2)} className="flex-1 rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright">
              Continue ({selected.size} selected)
            </button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="space-y-3">
          <h2 className="font-display text-lg font-semibold text-ink-100">Configure your paper account</h2>
          <p className="text-sm text-ink-500">Choose a starting virtual balance. All trades are simulated — no real money is ever involved.</p>
          <label className="block text-xs text-ink-500">
            Starting balance (USD)
            <input
              type="number"
              min="1000"
              step="1000"
              value={startingBalance}
              onChange={(e) => setStartingBalance(e.target.value)}
              className="mt-1 w-full rounded border border-base-600 bg-base-900 px-3 py-2 text-sm text-ink-100"
            />
          </label>
          <div className="flex gap-2">
            <button onClick={() => setStep(1)} className="rounded-md border border-base-600 px-4 py-2 text-sm text-ink-400">
              Back
            </button>
            <button onClick={() => setStep(3)} className="flex-1 rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright">
              Continue
            </button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="space-y-3">
          <h2 className="font-display text-lg font-semibold text-ink-100">A quick glossary</h2>
          <p className="text-sm text-ink-500">You'll see these terms throughout the app — hover the (?) icon anywhere for a reminder.</p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-2">
            {Object.entries(METRIC_GLOSSARY).map(([term, def]) => (
              <div key={term} className="rounded-md border border-base-600 bg-base-900/50 p-2.5">
                <p className="flex items-center text-xs font-semibold text-ink-100">
                  {term}
                  <Tooltip label={term}>{def}</Tooltip>
                </p>
                <p className="mt-0.5 text-[11px] leading-snug text-ink-500">{def}</p>
              </div>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={() => setStep(2)} className="rounded-md border border-base-600 px-4 py-2 text-sm text-ink-400">
              Back
            </button>
            <button onClick={finish} disabled={submitting} className="flex-1 rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright disabled:opacity-50">
              {submitting ? "Setting up…" : "Enter Quant Terminal"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
