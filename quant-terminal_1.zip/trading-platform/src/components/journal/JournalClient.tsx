"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Card, CardHeader } from "@/components/ui/Card";
import { cx, formatCurrency, formatRelativeTime } from "@/lib/utils/format";

interface JournalEntry {
  id: string;
  ticker: string;
  thesis: string;
  setup: string | null;
  confidence: number | null;
  timeHorizon: string | null;
  notes: string | null;
  outcomeNotes: string | null;
  aiReview: string | null;
  createdAt: string;
  closedAt: string | null;
  order: { ticker: string; side: string; fillPrice: number | null } | null;
}
interface OrderOption {
  id: string;
  ticker: string;
  side: string;
  fillPrice: number | null;
  placedAt: string;
}

export function JournalClient({ entries, availableOrders }: { entries: JournalEntry[]; availableOrders: OrderOption[] }) {
  const router = useRouter();
  const [ticker, setTicker] = useState("");
  const [thesis, setThesis] = useState("");
  const [setup, setSetup] = useState("");
  const [confidence, setConfidence] = useState("70");
  const [timeHorizon, setTimeHorizon] = useState("Swing (1-4 weeks)");
  const [orderId, setOrderId] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [closingId, setClosingId] = useState<string | null>(null);
  const [outcomeText, setOutcomeText] = useState("");

  async function submitEntry() {
    if (!ticker || !thesis) return;
    setSubmitting(true);
    try {
      await fetch("/api/journal", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ticker: ticker.toUpperCase(),
          thesis,
          setup: setup || undefined,
          confidence: confidence ? Number(confidence) : undefined,
          timeHorizon,
          orderId: orderId || undefined,
        }),
      });
      setTicker("");
      setThesis("");
      setSetup("");
      setOrderId("");
      router.refresh();
    } finally {
      setSubmitting(false);
    }
  }

  async function closeTrade(id: string) {
    if (!outcomeText.trim()) return;
    await fetch(`/api/journal/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ outcomeNotes: outcomeText }),
    });
    setClosingId(null);
    setOutcomeText("");
    router.refresh();
  }

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="lg:col-span-1">
        <Card>
          <CardHeader title="New Entry" />
          <div className="space-y-2.5">
            <input value={ticker} onChange={(e) => setTicker(e.target.value)} placeholder="Ticker" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            <textarea value={thesis} onChange={(e) => setThesis(e.target.value)} placeholder="Entry reason / thesis…" rows={3} className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            <input value={setup} onChange={(e) => setSetup(e.target.value)} placeholder="Setup (e.g. breakout, pullback)" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            <div className="flex gap-2">
              <input type="number" min="0" max="100" value={confidence} onChange={(e) => setConfidence(e.target.value)} placeholder="Confidence %" className="w-1/2 rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
              <select value={timeHorizon} onChange={(e) => setTimeHorizon(e.target.value)} className="w-1/2 rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100">
                <option>Short-term (days)</option>
                <option>Swing (1-4 weeks)</option>
                <option>Position (1-6 months)</option>
              </select>
            </div>
            {availableOrders.length > 0 && (
              <select value={orderId} onChange={(e) => setOrderId(e.target.value)} className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100">
                <option value="">Link to a filled order (optional)</option>
                {availableOrders.map((o) => (
                  <option key={o.id} value={o.id}>
                    {o.ticker} {o.side} @ {o.fillPrice?.toFixed(2)} · {formatRelativeTime(o.placedAt)}
                  </option>
                ))}
              </select>
            )}
            <button onClick={submitEntry} disabled={submitting || !ticker || !thesis} className="w-full rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright disabled:opacity-50">
              Save entry
            </button>
          </div>
        </Card>
      </div>

      <div className="space-y-3 lg:col-span-2">
        {entries.length === 0 ? (
          <p className="text-sm text-ink-500">No journal entries yet.</p>
        ) : (
          entries.map((e) => (
            <div key={e.id} className="panel p-4">
              <div className="mb-1.5 flex items-center justify-between">
                <span className="font-mono text-sm font-semibold text-ink-100">{e.ticker}</span>
                <span className="text-xs text-ink-500">{formatRelativeTime(e.createdAt)}</span>
              </div>
              <p className="text-sm text-ink-300">{e.thesis}</p>
              <div className="mt-1.5 flex flex-wrap gap-1.5 text-[11px] text-ink-500">
                {e.setup && <span className="badge border border-base-500">{e.setup}</span>}
                {e.confidence !== null && <span className="badge border border-base-500">{e.confidence}% confidence</span>}
                {e.timeHorizon && <span className="badge border border-base-500">{e.timeHorizon}</span>}
                {e.order?.fillPrice && <span className="badge border border-base-500">Entry @ {formatCurrency(e.order.fillPrice)}</span>}
              </div>

              {e.closedAt ? (
                <div className="mt-3 rounded-md border border-base-600 bg-base-900/50 p-2.5">
                  <p className="text-[11px] font-medium uppercase tracking-wide text-ink-500">Outcome</p>
                  <p className="mt-0.5 text-sm text-ink-300">{e.outcomeNotes}</p>
                  {e.aiReview && (
                    <>
                      <p className="mt-2 text-[11px] font-medium uppercase tracking-wide text-amber">AI post-trade review</p>
                      <p className="mt-0.5 text-sm text-ink-300">{e.aiReview}</p>
                    </>
                  )}
                </div>
              ) : closingId === e.id ? (
                <div className="mt-3 space-y-2">
                  <textarea value={outcomeText} onChange={(ev) => setOutcomeText(ev.target.value)} rows={2} placeholder="What actually happened?" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
                  <div className="flex gap-2">
                    <button onClick={() => closeTrade(e.id)} className="rounded-md bg-amber px-3 py-1 text-xs font-semibold text-base-950 hover:bg-amber-bright">
                      Save outcome
                    </button>
                    <button onClick={() => setClosingId(null)} className="rounded-md border border-base-600 px-3 py-1 text-xs text-ink-400">
                      Cancel
                    </button>
                  </div>
                </div>
              ) : (
                <button onClick={() => setClosingId(e.id)} className="mt-3 text-xs text-amber hover:underline">
                  Record outcome →
                </button>
              )}
            </div>
          ))
        )}
      </div>
    </div>
  );
}
