"use client";

import { useState } from "react";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, Tooltip as RTooltip, CartesianGrid } from "recharts";
import { Card, CardHeader } from "@/components/ui/Card";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { cx, formatCurrency, formatPct } from "@/lib/utils/format";
import { AlertTriangle } from "lucide-react";

type Strategy = "sma_crossover" | "rsi_reversion" | "momentum" | "volume_breakout";

const STRATEGY_LABELS: Record<Strategy, string> = {
  sma_crossover: "Moving-Average Crossover",
  rsi_reversion: "RSI Mean-Reversion",
  momentum: "Momentum Breakout",
  volume_breakout: "Volume Breakout",
};

const DEFAULT_PARAMS: Record<Strategy, Record<string, number>> = {
  sma_crossover: { fastPeriod: 20, slowPeriod: 50 },
  rsi_reversion: { period: 14, oversold: 30 },
  momentum: { lookbackDays: 10, thresholdPct: 3 },
  volume_breakout: { volumeMultiplier: 1.8 },
};

interface Trade {
  entryDate: string;
  exitDate: string;
  entryPrice: number;
  exitPrice: number;
  returnPct: number;
  barsHeld: number;
}
interface Result {
  trades: Trade[];
  totalReturnPct: number;
  winRate: number;
  avgTradeReturnPct: number;
  maxDrawdownPct: number;
  profitFactor: number | null;
  equityCurve: { date: string; equity: number }[];
  warnings: string[];
}

export function BacktestClient() {
  const [ticker, setTicker] = useState("AAPL");
  const [strategy, setStrategy] = useState<Strategy>("sma_crossover");
  const [params, setParams] = useState<Record<string, number>>(DEFAULT_PARAMS.sma_crossover);
  const [exitHoldingDays, setExitHoldingDays] = useState(10);
  const [range, setRange] = useState<"1Y" | "5Y">("5Y");
  const [result, setResult] = useState<Result | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function changeStrategy(s: Strategy) {
    setStrategy(s);
    setParams(DEFAULT_PARAMS[s]);
  }

  async function run() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/backtest", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticker: ticker.toUpperCase(), strategy, params, exitHoldingDays, range }),
      });
      const json = await res.json();
      if (!json.ok) {
        setError(json.error);
        return;
      }
      setResult(json.data);
    } finally {
      setLoading(false);
    }
  }

  const tradeColumns: Column<Trade>[] = [
    { key: "entry", header: "Entry Date", render: (t) => <span className="text-xs text-ink-400">{t.entryDate}</span> },
    { key: "exit", header: "Exit Date", render: (t) => <span className="text-xs text-ink-400">{t.exitDate}</span> },
    { key: "entryPrice", header: "Entry", align: "right", render: (t) => <span className="stat-tabular">{formatCurrency(t.entryPrice)}</span> },
    { key: "exitPrice", header: "Exit", align: "right", render: (t) => <span className="stat-tabular">{formatCurrency(t.exitPrice)}</span> },
    { key: "bars", header: "Bars Held", align: "right", render: (t) => <span className="stat-tabular text-ink-400">{t.barsHeld}</span> },
    {
      key: "ret",
      header: "Return",
      align: "right",
      sortValue: (t) => t.returnPct,
      render: (t) => <span className={cx("stat-tabular font-medium", t.returnPct >= 0 ? "text-rise" : "text-fall")}>{formatPct(t.returnPct)}</span>,
    },
  ];

  return (
    <div className="grid grid-cols-1 gap-5 lg:grid-cols-3">
      <div className="lg:col-span-1">
        <Card>
          <CardHeader title="Rule Configuration" />
          <div className="space-y-2.5">
            <input value={ticker} onChange={(e) => setTicker(e.target.value)} placeholder="Ticker" className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />

            <select value={strategy} onChange={(e) => changeStrategy(e.target.value as Strategy)} className="w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100">
              {(Object.keys(STRATEGY_LABELS) as Strategy[]).map((s) => (
                <option key={s} value={s}>
                  {STRATEGY_LABELS[s]}
                </option>
              ))}
            </select>

            {Object.entries(params).map(([key, value]) => (
              <label key={key} className="block text-xs text-ink-500">
                {key}
                <input
                  type="number"
                  value={value}
                  onChange={(e) => setParams((p) => ({ ...p, [key]: Number(e.target.value) }))}
                  className="mt-0.5 w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100"
                />
              </label>
            ))}

            <label className="block text-xs text-ink-500">
              Max holding period (bars)
              <input type="number" value={exitHoldingDays} onChange={(e) => setExitHoldingDays(Number(e.target.value))} className="mt-0.5 w-full rounded border border-base-600 bg-base-900 px-2.5 py-1.5 text-sm text-ink-100" />
            </label>

            <div className="flex gap-1">
              {(["1Y", "5Y"] as const).map((r) => (
                <button key={r} onClick={() => setRange(r)} className={cx("flex-1 rounded px-2 py-1 text-xs", range === r ? "bg-base-500 text-ink-100" : "bg-base-600 text-ink-500")}>
                  {r} history
                </button>
              ))}
            </div>

            <button onClick={run} disabled={loading || !ticker} className="w-full rounded-md bg-amber py-2 text-sm font-semibold text-base-950 hover:bg-amber-bright disabled:opacity-50">
              {loading ? "Running…" : "Run backtest"}
            </button>
            {error && <p className="text-xs text-fall">{error}</p>}
          </div>
        </Card>
      </div>

      <div className="space-y-5 lg:col-span-2">
        {!result ? (
          <p className="text-sm text-ink-500">Configure a rule and run it to see results.</p>
        ) : (
          <>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-5">
              <StatBox label="Total Return" value={formatPct(result.totalReturnPct)} tone={result.totalReturnPct >= 0 ? "rise" : "fall"} />
              <StatBox label="Win Rate" value={`${result.winRate.toFixed(1)}%`} />
              <StatBox label="Avg Trade" value={formatPct(result.avgTradeReturnPct)} />
              <StatBox label="Max Drawdown" value={formatPct(-result.maxDrawdownPct, { signed: false })} />
              <StatBox label="Profit Factor" value={result.profitFactor !== null ? result.profitFactor.toFixed(2) : "N/A"} />
            </div>

            {result.warnings.length > 0 && (
              <div className="space-y-1.5 rounded-md border border-amber/25 bg-amber/5 p-3">
                {result.warnings.map((w, i) => (
                  <p key={i} className="flex gap-2 text-xs text-ink-300">
                    <AlertTriangle size={13} className="mt-0.5 shrink-0 text-amber" />
                    {w}
                  </p>
                ))}
              </div>
            )}

            <Card>
              <CardHeader title="Equity Curve" subtitle="$10,000 notional, one position at a time" />
              <div className="h-56">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={result.equityCurve} margin={{ top: 4, right: 8, left: 0, bottom: 0 }}>
                    <CartesianGrid stroke="#161C26" vertical={false} />
                    <XAxis dataKey="date" tick={{ fontSize: 10, fill: "#5B6274" }} minTickGap={40} />
                    <YAxis tick={{ fontSize: 10, fill: "#5B6274" }} domain={["auto", "auto"]} width={56} tickFormatter={(v) => formatCurrency(v, { compact: true })} />
                    <RTooltip contentStyle={{ background: "#0F141C", border: "1px solid #1E2530", fontSize: 12 }} formatter={(v: number) => formatCurrency(v)} />
                    <Line type="monotone" dataKey="equity" stroke="#E8A33D" strokeWidth={1.5} dot={false} isAnimationActive={false} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </Card>

            <Card>
              <CardHeader title="Trades" subtitle={`${result.trades.length} trade${result.trades.length === 1 ? "" : "s"}`} />
              <DataTable columns={tradeColumns} rows={result.trades} rowKey={(t) => `${t.entryDate}-${t.exitDate}`} emptyLabel="No trades triggered." />
            </Card>
          </>
        )}
      </div>
    </div>
  );
}

function StatBox({ label, value, tone }: { label: string; value: string; tone?: "rise" | "fall" }) {
  return (
    <div className="panel px-3 py-2.5">
      <p className="text-[10px] uppercase tracking-wide text-ink-500">{label}</p>
      <p className={cx("stat-tabular mt-0.5 text-sm font-medium", tone === "rise" && "text-rise", tone === "fall" && "text-fall", !tone && "text-ink-100")}>{value}</p>
    </div>
  );
}
