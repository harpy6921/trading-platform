import { cx } from "@/lib/utils/format";
import type { SignalLabel } from "@/types";
import { TrendingUp, TrendingDown, Minus, ArrowUpRight, ArrowDownRight } from "lucide-react";

const CONFIG: Record<
  SignalLabel,
  { label: string; className: string; Icon: typeof TrendingUp }
> = {
  STRONG_BUY: { label: "STRONG BUY", className: "bg-signal-strongbuy/15 text-signal-strongbuy border-signal-strongbuy/30", Icon: TrendingUp },
  BUY: { label: "BUY", className: "bg-signal-buy/15 text-signal-buy border-signal-buy/30", Icon: ArrowUpRight },
  HOLD: { label: "HOLD", className: "bg-signal-hold/15 text-signal-hold border-signal-hold/30", Icon: Minus },
  SELL: { label: "SELL", className: "bg-signal-sell/15 text-signal-sell border-signal-sell/30", Icon: ArrowDownRight },
  STRONG_SELL: { label: "STRONG SELL", className: "bg-signal-strongsell/15 text-signal-strongsell border-signal-strongsell/30", Icon: TrendingDown },
};

export function SignalBadge({ signal, size = "md" }: { signal: SignalLabel; size?: "sm" | "md" }) {
  const cfg = CONFIG[signal];
  const Icon = cfg.Icon;
  return (
    <span
      className={cx(
        "badge border",
        cfg.className,
        size === "sm" ? "text-[10px]" : "text-xs px-2 py-1"
      )}
    >
      <Icon size={size === "sm" ? 10 : 12} aria-hidden />
      {cfg.label}
    </span>
  );
}

export function RiskLevelBadge({ level }: { level: "Low" | "Moderate" | "Elevated" | "High" }) {
  const styles: Record<typeof level, string> = {
    Low: "bg-rise/10 text-rise border-rise/25",
    Moderate: "bg-amber/10 text-amber border-amber/25",
    Elevated: "bg-signal-sell/10 text-signal-sell border-signal-sell/25",
    High: "bg-fall/10 text-fall border-fall/25",
  };
  return <span className={cx("badge border", styles[level])}>{level.toUpperCase()} RISK</span>;
}
