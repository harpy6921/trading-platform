import { Card, CardHeader } from "@/components/ui/Card";
import { formatPct } from "@/lib/utils/format";
import type { Fundamentals } from "@/lib/market-data/types";

function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-md border border-base-600 bg-base-900/50 p-2.5">
      <p className="text-[10px] uppercase tracking-wide text-ink-500">{label}</p>
      <p className="stat-tabular mt-0.5 text-sm font-medium text-ink-100">{value}</p>
    </div>
  );
}

function fmt(value: number | null, formatter: (v: number) => string): string {
  return value === null ? "Data unavailable" : formatter(value);
}

export function FundamentalsPanel({ fundamentals }: { fundamentals: Fundamentals | null }) {
  if (!fundamentals) {
    return (
      <Card>
        <CardHeader title="Fundamentals" />
        <p className="text-sm text-ink-500">Data unavailable for this security.</p>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader title="Fundamentals" subtitle={`${fundamentals.sector} · ${fundamentals.industry}`} />
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
        <Metric label="P/E (TTM)" value={fmt(fundamentals.peRatio, (v) => v.toFixed(1))} />
        <Metric label="Forward P/E" value={fmt(fundamentals.forwardPe, (v) => v.toFixed(1))} />
        <Metric label="EPS (TTM)" value={fmt(fundamentals.epsTtm, (v) => `$${v.toFixed(2)}`)} />
        <Metric label="Revenue growth YoY" value={fmt(fundamentals.revenueGrowthYoy, (v) => formatPct(v * 100))} />
        <Metric label="Earnings growth YoY" value={fmt(fundamentals.earningsGrowthYoy, (v) => formatPct(v * 100))} />
        <Metric label="Gross margin" value={fmt(fundamentals.grossMargin, (v) => formatPct(v * 100, { signed: false }))} />
        <Metric label="Debt / Equity" value={fmt(fundamentals.debtToEquity, (v) => v.toFixed(2))} />
        <Metric label="Dividend yield" value={fmt(fundamentals.dividendYield, (v) => formatPct(v * 100, { signed: false }))} />
        <Metric label="Beta" value={fmt(fundamentals.beta, (v) => v.toFixed(2))} />
      </div>
    </Card>
  );
}
