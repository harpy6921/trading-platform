"use client";

import { useEffect, useRef, useState, useMemo } from "react";
import type { IChartApi, ISeriesApi, UTCTimestamp } from "lightweight-charts";
import { LineChart, Line, ResponsiveContainer, XAxis, YAxis, ReferenceLine, Tooltip as RTooltip } from "recharts";
import { cx } from "@/lib/utils/format";
import { sma, ema, rsi, macd, bollingerBands } from "@/lib/indicators";
import type { Candle, ChartRange } from "@/lib/market-data/types";

const RANGES: ChartRange[] = ["1D", "5D", "1M", "3M", "6M", "1Y", "5Y"];

type Overlay = "SMA20" | "SMA50" | "SMA200" | "EMA20" | "BOLL";
const OVERLAY_COLORS: Record<Overlay, string> = {
  SMA20: "#7FE0AE",
  SMA50: "#E8A33D",
  SMA200: "#FF9A7A",
  EMA20: "#8FB6FF",
  BOLL: "#8B93A3",
};

export function StockChart({ ticker, initialCandles }: { ticker: string; initialCandles: Candle[] }) {
  const containerRef = useRef<HTMLDivElement>(null);
  const chartRef = useRef<IChartApi | null>(null);
  const candleSeriesRef = useRef<ISeriesApi<"Candlestick"> | null>(null);
  const volumeSeriesRef = useRef<ISeriesApi<"Histogram"> | null>(null);
  const overlaySeriesRef = useRef<Partial<Record<Overlay, ISeriesApi<"Line">[]>>>({});

  const [range, setRange] = useState<ChartRange>("3M");
  const [candles, setCandles] = useState<Candle[]>(initialCandles);
  const [loading, setLoading] = useState(false);
  const [overlays, setOverlays] = useState<Set<Overlay>>(new Set(["SMA50"]));
  const [showVolume, setShowVolume] = useState(true);
  const [showRsi, setShowRsi] = useState(true);
  const [showMacd, setShowMacd] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    fetch(`/api/stocks/${ticker}/candles?range=${range}`)
      .then((r) => r.json())
      .then((json) => {
        if (!cancelled && json.ok) setCandles(json.data.candles);
      })
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [ticker, range]);

  // Init chart once
  useEffect(() => {
    if (!containerRef.current) return;
    let disposed = false;

    import("lightweight-charts").then(({ createChart, ColorType, CrosshairMode }) => {
      if (disposed || !containerRef.current) return;
      const chart = createChart(containerRef.current, {
        layout: { background: { type: ColorType.Solid, color: "transparent" }, textColor: "#8B93A3", fontSize: 11 },
        grid: { vertLines: { color: "#161C26" }, horzLines: { color: "#161C26" } },
        crosshair: { mode: CrosshairMode.Normal },
        rightPriceScale: { borderColor: "#1E2530" },
        timeScale: { borderColor: "#1E2530", timeVisible: true, secondsVisible: false },
        height: 380,
        autoSize: true,
      });

      const candleSeries = chart.addCandlestickSeries({
        upColor: "#2FD48C",
        downColor: "#FF5C6C",
        borderVisible: false,
        wickUpColor: "#2FD48C",
        wickDownColor: "#FF5C6C",
      });

      const volumeSeries = chart.addHistogramSeries({
        priceFormat: { type: "volume" },
        priceScaleId: "volume",
      });
      chart.priceScale("volume").applyOptions({ scaleMargins: { top: 0.85, bottom: 0 } });

      chartRef.current = chart;
      candleSeriesRef.current = candleSeries;
      volumeSeriesRef.current = volumeSeries;
      renderData();
    });

    return () => {
      disposed = true;
      chartRef.current?.remove();
      chartRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function renderData() {
    if (!candleSeriesRef.current || !volumeSeriesRef.current || !chartRef.current) return;
    const cData = candles.map((c) => ({ time: c.time as UTCTimestamp, open: c.open, high: c.high, low: c.low, close: c.close }));
    candleSeriesRef.current.setData(cData);
    volumeSeriesRef.current.setData(
      candles.map((c) => ({
        time: c.time as UTCTimestamp,
        value: c.volume,
        color: c.close >= c.open ? "rgba(47,212,140,0.35)" : "rgba(255,92,108,0.35)",
      }))
    );
    volumeSeriesRef.current.applyOptions({ visible: showVolume });

    // clear old overlay series
    Object.values(overlaySeriesRef.current).forEach((series) => series?.forEach((s) => chartRef.current?.removeSeries(s)));
    overlaySeriesRef.current = {};

    const closes = candles.map((c) => c.close);
    const times = candles.map((c) => c.time as UTCTimestamp);

    function addLine(key: Overlay, values: (number | null)[], color: string) {
      if (!chartRef.current) return;
      const series = chartRef.current.addLineSeries({ color, lineWidth: 1, priceLineVisible: false, lastValueVisible: false });
      series.setData(values.map((v, i) => ({ time: times[i]!, value: v ?? undefined })).filter((d) => d.value !== undefined) as { time: UTCTimestamp; value: number }[]);
      overlaySeriesRef.current[key] = [...(overlaySeriesRef.current[key] ?? []), series];
    }

    if (overlays.has("SMA20")) addLine("SMA20", sma(closes, 20), OVERLAY_COLORS.SMA20);
    if (overlays.has("SMA50")) addLine("SMA50", sma(closes, 50), OVERLAY_COLORS.SMA50);
    if (overlays.has("SMA200")) addLine("SMA200", sma(closes, 200), OVERLAY_COLORS.SMA200);
    if (overlays.has("EMA20")) addLine("EMA20", ema(closes, 20), OVERLAY_COLORS.EMA20);
    if (overlays.has("BOLL")) {
      const bands = bollingerBands(closes, 20, 2);
      addLine("BOLL", bands.upper, OVERLAY_COLORS.BOLL);
      addLine("BOLL", bands.lower, OVERLAY_COLORS.BOLL);
    }

    chartRef.current.timeScale().fitContent();
  }

  useEffect(() => {
    renderData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [candles, overlays, showVolume]);

  const rsiData = useMemo(() => {
    const closes = candles.map((c) => c.close);
    const series = rsi(closes, 14);
    return candles.map((c, i) => ({ time: c.time, value: series[i] }));
  }, [candles]);

  const macdData = useMemo(() => {
    const closes = candles.map((c) => c.close);
    const result = macd(closes);
    return candles.map((c, i) => ({ time: c.time, hist: result.histogram[i], macd: result.macd[i], signal: result.signal[i] }));
  }, [candles]);

  function toggleOverlay(key: Overlay) {
    setOverlays((prev) => {
      const next = new Set(prev);
      next.has(key) ? next.delete(key) : next.add(key);
      return next;
    });
  }

  return (
    <div className="panel p-3 sm:p-4">
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <div className="flex flex-wrap gap-1">
          {RANGES.map((r) => (
            <button
              key={r}
              onClick={() => setRange(r)}
              className={cx(
                "rounded-md px-2.5 py-1 text-xs font-mono font-medium transition-colors",
                range === r ? "bg-amber/15 text-amber" : "text-ink-500 hover:bg-base-700 hover:text-ink-300"
              )}
            >
              {r}
            </button>
          ))}
        </div>
        <div className="flex flex-wrap gap-1">
          {(["SMA20", "SMA50", "SMA200", "EMA20", "BOLL"] as Overlay[]).map((o) => (
            <button
              key={o}
              onClick={() => toggleOverlay(o)}
              className={cx(
                "rounded-md border px-2 py-0.5 text-[11px] font-mono transition-colors",
                overlays.has(o) ? "border-amber/40 text-amber" : "border-base-600 text-ink-500 hover:text-ink-300"
              )}
            >
              {o}
            </button>
          ))}
          <button
            onClick={() => setShowVolume((v) => !v)}
            className={cx(
              "rounded-md border px-2 py-0.5 text-[11px] font-mono transition-colors",
              showVolume ? "border-amber/40 text-amber" : "border-base-600 text-ink-500 hover:text-ink-300"
            )}
          >
            VOL
          </button>
        </div>
      </div>

      <div className="relative">
        {loading && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-base-800/50 text-xs text-ink-500">
            Loading {range} candles…
          </div>
        )}
        <div ref={containerRef} className="h-[380px] w-full" />
      </div>

      <div className="mt-3 flex gap-2">
        <button
          onClick={() => setShowRsi((v) => !v)}
          className={cx("rounded-md border px-2 py-0.5 text-[11px] font-mono", showRsi ? "border-amber/40 text-amber" : "border-base-600 text-ink-500")}
        >
          RSI(14)
        </button>
        <button
          onClick={() => setShowMacd((v) => !v)}
          className={cx("rounded-md border px-2 py-0.5 text-[11px] font-mono", showMacd ? "border-amber/40 text-amber" : "border-base-600 text-ink-500")}
        >
          MACD
        </button>
      </div>

      {showRsi && (
        <div className="mt-2 h-20">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={rsiData} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
              <YAxis domain={[0, 100]} hide />
              <XAxis dataKey="time" hide />
              <ReferenceLine y={70} stroke="#5B6274" strokeDasharray="3 3" />
              <ReferenceLine y={30} stroke="#5B6274" strokeDasharray="3 3" />
              <Line type="monotone" dataKey="value" stroke="#8FB6FF" strokeWidth={1.25} dot={false} isAnimationActive={false} />
              <RTooltip contentStyle={{ background: "#0F141C", border: "1px solid #1E2530", fontSize: 11 }} labelFormatter={() => ""} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}

      {showMacd && (
        <div className="mt-2 h-20">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={macdData} margin={{ top: 4, right: 4, left: 4, bottom: 0 }}>
              <XAxis dataKey="time" hide />
              <YAxis hide />
              <ReferenceLine y={0} stroke="#5B6274" />
              <Line type="monotone" dataKey="macd" stroke="#E8A33D" strokeWidth={1.25} dot={false} isAnimationActive={false} />
              <Line type="monotone" dataKey="signal" stroke="#8FB6FF" strokeWidth={1.25} dot={false} isAnimationActive={false} />
              <RTooltip contentStyle={{ background: "#0F141C", border: "1px solid #1E2530", fontSize: 11 }} labelFormatter={() => ""} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
