import { SignalBadge, RiskLevelBadge } from "@/components/stock/SignalBadge";
import { ScoreGauge } from "@/components/stock/ScoreGauge";
import { Card, CardHeader } from "@/components/ui/Card";
import { Tooltip, METRIC_GLOSSARY } from "@/components/ui/Tooltip";
import { formatCurrency, formatRelativeTime, cx } from "@/lib/utils/format";
import type { AISignal } from "@/types";

export function AISignalPanel({ signal }: { signal: AISignal }) {
  return (
    <Card>
      <CardHeader
        title="AI Analysis"
        subtitle={`Model ${signal.modelVersion} · updated ${formatRelativeTime(signal.timestamp)}`}
      />

      <div className="flex flex-wrap items-center gap-3">
        <SignalBadge signal={signal.signal} />
        <RiskLevelBadge level={signal.riskLevel} />
        <span className="badge border border-base-500 text-ink-300">{signal.timeHorizon}</span>
        <div className="ml-auto flex items-center gap-1">
          <span className="text-xs text-ink-500">Confidence</span>
          <Tooltip label="Confidence">{METRIC_GLOSSARY.Confidence}</Tooltip>
          <span className="stat-tabular ml-1 text-sm font-semibold text-ink-100">{signal.confidence}%</span>
        </div>
      </div>

      <div className="mt-4">
        <p className="mb-1.5 text-xs font-medium uppercase tracking-wider text-ink-500">Key factors</p>
        <ul className="space-y-1.5">
          {signal.reasons.map((reason, i) => (
            <li key={i} className="flex gap-2 text-sm text-ink-300">
              <span className="mt-1.5 h-1 w-1 shrink-0 rounded-full bg-amber" />
              {reason}
            </li>
          ))}
        </ul>
      </div>

      <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
        <div className="rounded-md border border-rise/20 bg-rise/5 p-3">
          <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-rise">Bull case</p>
          <p className="text-sm leading-relaxed text-ink-300">{signal.bullCase}</p>
        </div>
        <div className="rounded-md border border-fall/20 bg-fall/5 p-3">
          <p className="mb-1 text-xs font-semibold uppercase tracking-wide text-fall">Bear case</p>
          <p className="text-sm leading-relaxed text-ink-300">{signal.bearCase}</p>
        </div>
      </div>

      {signal.scenarios.length > 0 && (
        <div className="mt-4">
          <p className="mb-1.5 text-xs font-medium uppercase tracking-wider text-ink-500">
            Model scenarios <span className="normal-case text-ink-700">(not price targets or guarantees)</span>
          </p>
          <div className="grid grid-cols-1 gap-2 sm:grid-cols-3">
            {signal.scenarios.map((s) => (
              <div
                key={s.label}
                className={cx(
                  "rounded-md border p-2.5",
                  s.label === "Bull case" && "border-rise/20 bg-rise/5",
                  s.label === "Bear case" && "border-fall/20 bg-fall/5",
                  s.label === "Base case" && "border-base-600 bg-base-900/50"
                )}
              >
                <p className="text-[11px] font-medium text-ink-500">{s.label}</p>
                <p className="stat-tabular text-base font-semibold text-ink-100">
                  {s.targetPrice !== null ? formatCurrency(s.targetPrice) : "Data unavailable"}
                </p>
                <p className="mt-1 text-[11px] leading-snug text-ink-500">{s.narrative}</p>
              </div>
            ))}
          </div>
        </div>
      )}
    </Card>
  );
}

export function ScorePanel({ opportunityScore, riskScore }: { opportunityScore: number; riskScore: number }) {
  return (
    <Card>
      <CardHeader title="Composite Scores" />
      <div className="flex items-center justify-around">
        <div className="flex flex-col items-center gap-1">
          <ScoreGauge value={opportunityScore} label="Opportunity" tone="rise" />
          <Tooltip label="Opportunity Score">{METRIC_GLOSSARY["Opportunity Score"]}</Tooltip>
        </div>
        <div className="flex flex-col items-center gap-1">
          <ScoreGauge value={riskScore} label="Risk" tone="fall" />
          <Tooltip label="Risk Score">{METRIC_GLOSSARY["Risk Score"]}</Tooltip>
        </div>
      </div>
    </Card>
  );
}
