import { cx } from "@/lib/utils/format";

export function ScoreGauge({
  value,
  label,
  tone = "amber",
  size = 64,
}: {
  value: number; // 0-100
  label: string;
  tone?: "amber" | "rise" | "fall";
  size?: number;
}) {
  const clamped = Math.max(0, Math.min(100, value));
  const radius = (size - 8) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference * (1 - clamped / 100);
  const toneColor = { amber: "#E8A33D", rise: "#2FD48C", fall: "#FF5C6C" }[tone];

  return (
    <div className="flex flex-col items-center gap-1.5">
      <div className="relative" style={{ width: size, height: size }}>
        <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`} className="-rotate-90">
          <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#1E2530" strokeWidth={5} />
          <circle
            cx={size / 2}
            cy={size / 2}
            r={radius}
            fill="none"
            stroke={toneColor}
            strokeWidth={5}
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={offset}
            style={{ transition: "stroke-dashoffset 0.6s ease" }}
          />
        </svg>
        <div className="absolute inset-0 flex items-center justify-center font-mono text-sm font-semibold text-ink-100">
          {Math.round(clamped)}
        </div>
      </div>
      <span className={cx("text-center text-[10px] uppercase tracking-wider text-ink-500")}>{label}</span>
    </div>
  );
}
