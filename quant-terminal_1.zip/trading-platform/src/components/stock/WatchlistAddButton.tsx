"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { ListPlus, Check } from "lucide-react";
import { cx } from "@/lib/utils/format";

interface WatchlistSummary {
  id: string;
  name: string;
  items: { ticker: string }[];
}

export function WatchlistAddButton({ ticker }: { ticker: string }) {
  const [open, setOpen] = useState(false);
  const [watchlists, setWatchlists] = useState<WatchlistSummary[] | null>(null);
  const [needsAuth, setNeedsAuth] = useState(false);
  const [busy, setBusy] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onOutside);
    return () => document.removeEventListener("mousedown", onOutside);
  }, []);

  async function loadWatchlists() {
    const res = await fetch("/api/watchlists");
    if (res.status === 401) {
      setNeedsAuth(true);
      return;
    }
    const json = await res.json();
    if (json.ok) setWatchlists(json.data);
  }

  async function toggle() {
    if (!open) await loadWatchlists();
    setOpen((v) => !v);
  }

  async function addTo(watchlistId: string) {
    setBusy(true);
    try {
      await fetch(`/api/watchlists/${watchlistId}/items`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ ticker }),
      });
      await loadWatchlists();
    } finally {
      setBusy(false);
    }
  }

  const isOnList = (wl: WatchlistSummary) => wl.items.some((i) => i.ticker === ticker);

  return (
    <div ref={ref} className="relative">
      <button
        onClick={toggle}
        className="flex items-center gap-1.5 rounded-md border border-base-500 px-3 py-1.5 text-xs font-medium text-ink-300 hover:border-amber/40 hover:text-amber"
      >
        <ListPlus size={13} /> Watchlist
      </button>

      {open && (
        <div className="absolute left-0 z-30 mt-1 w-56 rounded-md border border-base-500 bg-base-700 p-2 shadow-panel">
          {needsAuth ? (
            <p className="p-2 text-xs text-ink-400">
              <Link href="/login" className="text-amber hover:underline">
                Sign in
              </Link>{" "}
              to save watchlists.
            </p>
          ) : !watchlists ? (
            <p className="p-2 text-xs text-ink-500">Loading…</p>
          ) : watchlists.length === 0 ? (
            <p className="p-2 text-xs text-ink-500">Create a watchlist first from the Watchlists page.</p>
          ) : (
            <ul className="space-y-0.5">
              {watchlists.map((wl) => (
                <li key={wl.id}>
                  <button
                    disabled={busy}
                    onClick={() => addTo(wl.id)}
                    className={cx(
                      "flex w-full items-center justify-between rounded px-2 py-1.5 text-left text-sm hover:bg-base-600",
                      isOnList(wl) && "text-amber"
                    )}
                  >
                    {wl.name}
                    {isOnList(wl) && <Check size={13} />}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}
    </div>
  );
}
