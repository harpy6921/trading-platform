import { cx, formatRelativeTime } from "@/lib/utils/format";
import type { NewsItem, NewsSentiment } from "@/lib/market-data/types";

const SENTIMENT_STYLES: Record<NewsSentiment, { label: string; className: string }> = {
  very_bullish: { label: "Very Bullish", className: "text-rise border-rise/30 bg-rise/10" },
  bullish: { label: "Bullish", className: "text-signal-buy border-signal-buy/30 bg-signal-buy/10" },
  neutral: { label: "Neutral", className: "text-ink-300 border-base-500 bg-base-700" },
  bearish: { label: "Bearish", className: "text-signal-sell border-signal-sell/30 bg-signal-sell/10" },
  very_bearish: { label: "Very Bearish", className: "text-fall border-fall/30 bg-fall/10" },
};

export function NewsList({ items, showTicker = false }: { items: NewsItem[]; showTicker?: boolean }) {
  if (items.length === 0) {
    return <p className="text-sm text-ink-500">No news available for the current filters.</p>;
  }
  return (
    <ul className="divide-y divide-base-700">
      {items.map((item) => {
        const style = SENTIMENT_STYLES[item.sentiment];
        return (
          <li key={item.id} className="py-2.5">
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0">
                <p className="text-sm leading-snug text-ink-100">{item.headline}</p>
                <p className="mt-1 text-xs text-ink-500">
                  {showTicker && item.ticker && <span className="font-mono text-ink-300">{item.ticker} · </span>}
                  {item.source} · {formatRelativeTime(item.publishedAt)}
                  {item.dataSource === "demo" && <span className="ml-1 text-amber/80">(demo)</span>}
                </p>
              </div>
              <span className={cx("badge shrink-0 border", style.className)}>{style.label}</span>
            </div>
          </li>
        );
      })}
    </ul>
  );
}
