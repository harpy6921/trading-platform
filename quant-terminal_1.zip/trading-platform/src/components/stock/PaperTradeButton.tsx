"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import { Wallet } from "lucide-react";
import { formatCurrency } from "@/lib/utils/format";

export function PaperTradeButton({ ticker, price }: { ticker: string; price: number }) {
  const [open, setOpen] = useState(false);
  const [side, setSide] = useState<"BUY" | "SELL">("BUY");
  const [type, setType] = useState<"MARKET" | "LIMIT">("MARKET");
  const [quantity, setQuantity] = useState("10");
  const [limitPrice, setLimitPrice] = useState(price.toFixed(2));
  const [message, setMessage] = useState<{ kind: "error" | "success"; text: string } | null>(null);
  const [needsAuth, setNeedsAuth] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onOutside);
    return () => document.removeEventListener("mousedown", onOutside);
  }, []);

  async function submit() {
    setSubmitting(true);
    setMessage(null);
    try {
      const res = await fetch("/api/paper-trading/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ticker,
          side,
          type,
          quantity: Number(quantity),
          limitPrice: type === "LIMIT" ? Number(limitPrice) : undefined,
        }),
      });
      if (res.status === 401) {
        setNeedsAuth(true);
        return;
      }
      const json = await res.json();
      if (!json.ok) {
        setMessage({ kind: "error", text: json.error });
      } else {
        setMessage({ kind: "success", text: `Filled ${quantity} sh at ${formatCurrency(Number(json.data.fillPrice))}.` });
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="flex items-center gap-1.5 rounded-md border border-amber/40 bg-amber/10 px-3 py-1.5 text-xs font-medium text-amber hover:bg-amber/15"
      >
        <Wallet size={13} /> Paper Trade
      </button>

      {open && (
        <div className="absolute left-0 z-30 mt-1 w-64 rounded-md border border-base-500 bg-base-700 p-3 shadow-panel">
          <p className="mb-2 text-[11px] font-medium uppercase tracking-wide text-amber">PAPER TRADING — simulated only</p>

          {needsAuth ? (
            <p className="text-xs text-ink-400">
              <Link href="/login" className="text-amber hover:underline">
                Sign in
              </Link>{" "}
              and create a paper account first.
            </p>
          ) : (
            <div className="space-y-2">
              <div className="flex gap-1">
                {(["BUY", "SELL"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setSide(s)}
                    className={`flex-1 rounded px-2 py-1 text-xs font-semibold ${
                      side === s ? (s === "BUY" ? "bg-rise/20 text-rise" : "bg-fall/20 text-fall") : "bg-base-600 text-ink-400"
                    }`}
                  >
                    {s}
                  </button>
                ))}
              </div>

              <div className="flex gap-1">
                {(["MARKET", "LIMIT"] as const).map((t) => (
                  <button
                    key={t}
                    onClick={() => setType(t)}
                    className={`flex-1 rounded px-2 py-1 text-[11px] ${
                      type === t ? "bg-base-500 text-ink-100" : "bg-base-600 text-ink-500"
                    }`}
                  >
                    {t}
                  </button>
                ))}
              </div>

              <label className="block text-[11px] text-ink-500">
                Quantity
                <input
                  type="number"
                  min="0"
                  step="any"
                  value={quantity}
                  onChange={(e) => setQuantity(e.target.value)}
                  className="mt-0.5 w-full rounded border border-base-500 bg-base-900 px-2 py-1 text-sm text-ink-100"
                />
              </label>

              {type === "LIMIT" && (
                <label className="block text-[11px] text-ink-500">
                  Limit price
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={limitPrice}
                    onChange={(e) => setLimitPrice(e.target.value)}
                    className="mt-0.5 w-full rounded border border-base-500 bg-base-900 px-2 py-1 text-sm text-ink-100"
                  />
                </label>
              )}

              <p className="text-[11px] text-ink-500">
                Ref. price: <span className="stat-tabular text-ink-300">{formatCurrency(price)}</span>
              </p>

              <button
                onClick={submit}
                disabled={submitting}
                className="w-full rounded bg-amber py-1.5 text-xs font-semibold text-base-950 hover:bg-amber-bright disabled:opacity-50"
              >
                {submitting ? "Submitting…" : `Place ${side.toLowerCase()} order`}
              </button>

              {message && (
                <p className={`text-[11px] ${message.kind === "error" ? "text-fall" : "text-rise"}`}>{message.text}</p>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
