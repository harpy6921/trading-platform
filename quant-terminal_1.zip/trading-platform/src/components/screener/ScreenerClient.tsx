"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { DataTable, type Column } from "@/components/ui/DataTable";
import { cx, formatCurrency, formatPct, formatMarketCap, formatCompactNumber } from "@/lib/utils/format";
import { SECTORS, type Sector } from "@/lib/constants/universe";
import type { ScreenerRow } from "@/lib/market-data/types";

// Prebuilt screens are transparent heuristics over already-computed screener
// fields (not a second scoring model) — see the predicate table below. The
// full AI Opportunity/Risk Score pipeline (which also weighs live news and
// market regime) lives on the dedicated Opportunities/Risk Scanner pages.
type PrebuiltKey =
  | "high_momentum"
  | "potential_breakouts"
  | "oversold"
  | "unusual_volume"
  | "strong_fundamentals"
  | "high_risk"
  | "ai_opportunities"
  | "bearish_setups";

function makePrebuilt(rows: ScreenerRow[]): Record<PrebuiltKey, { label: string; predicate: (r: ScreenerRow) => boolean }> {
  const avgVolume = rows.reduce((s, r) => s + r.volume, 0) / Math.max(1, rows.length);
  return {
    high_momentum: {
      label: "High Momentum",
      predicate: (r) => r.changePct > 1.5 && r.aboveSma50 && r.aboveSma200,
    },
    potential_breakouts: {
      label: "Potential Breakouts",
      predicate: (r) => r.aboveSma50 && r.aboveSma200 && r.rsi14 >= 55 && r.rsi14 <= 70,
    },
    oversold: { label: "Oversold", predicate: (r) => r.rsi14 < 32 },
    unusual_volume: { label: "Unusual Volume", predicate: (r) => r.volume > avgVolume * 1.5 },
    strong_fundamentals: {
      label: "Strong Fundamentals",
      predicate: (r) => (r.earningsGrowthYoy ?? 0) > 0.1 && (r.revenueGrowthYoy ?? 0) > 0.08 && (r.peRatio ?? 999) < 35,
    },
    high_risk: { label: "High Risk", predicate: (r) => r.volatility30d > 0.35 || r.newsSentimentScore < -0.5 },
    ai_opportunities: {
      label: "AI Opportunities",
      predicate: (r) => r.changePct > 0 && r.aboveSma50 && r.newsSentimentScore > 0.3,
    },
    bearish_setups: {
      label: "Bearish Setups",
      predicate: (r) => (!r.aboveSma50 && r.rsi14 > 65) || r.newsSentimentScore < -0.5,
    },
  };
}

export function ScreenerClient({ initialRows }: { initialRows: ScreenerRow[] }) {
  const [search, setSearch] = useState("");
  const [sector, setSector] = useState<Sector | "all">("all");
  const [prebuilt, setPrebuilt] = useState<PrebuiltKey | null>(null);
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const [rsiMax, setRsiMax] = useState("");

  const prebuiltScreens = useMemo(() => makePrebuilt(initialRows), [initialRows]);

  const filtered = useMemo(() => {
    return initialRows.filter((r) => {
      if (search && !r.ticker.includes(search.toUpperCase()) && !r.companyName.toUpperCase().includes(search.toUpperCase())) return false;
      if (sector !== "all" && r.sector !== sector) return false;
      if (minPrice && r.price < Number(minPrice)) return false;
      if (maxPrice && r.price > Number(maxPrice)) return false;
      if (rsiMax && r.rsi14 > Number(rsiMax)) return false;
      if (prebuilt && !prebuiltScreens[prebuilt].predicate(r)) return false;
      return true;
    });
  }, [initialRows, search, sector, minPrice, maxPrice, rsiMax, prebuilt, prebuiltScreens]);

  const columns: Column<ScreenerRow>[] = [
    {
      key: "ticker",
      header: "Ticker",
      sortValue: (r) => r.ticker,
      render: (r) => (
        <Link href={`/stock/${r.ticker}`} className="font-mono font-medium text-ink-100 hover:text-amber">
          {r.ticker}
        </Link>
      ),
    },
    { key: "sector", header: "Sector", sortValue: (r) => r.sector, render: (r) => <span className="text-xs text-ink-500">{r.sector}</span> },
    { key: "price", header: "Price", align: "right", sortValue: (r) => r.price, render: (r) => <span className="stat-tabular">{formatCurrency(r.price)}</span> },
    {
      key: "changePct",
      header: "Chg %",
      align: "right",
      sortValue: (r) => r.changePct,
      render: (r) => <span className={cx("stat-tabular font-medium", r.changePct >= 0 ? "text-rise" : "text-fall")}>{formatPct(r.changePct)}</span>,
    },
    { key: "marketCap", header: "Mkt Cap", align: "right", sortValue: (r) => r.marketCap ?? 0, render: (r) => <span className="stat-tabular text-ink-300">{formatMarketCap(r.marketCap)}</span> },
    { key: "volume", header: "Volume", align: "right", sortValue: (r) => r.volume, render: (r) => <span className="stat-tabular text-ink-300">{formatCompactNumber(r.volume)}</span> },
    { key: "rsi14", header: "RSI(14)", align: "right", sortValue: (r) => r.rsi14, render: (r) => <span className="stat-tabular text-ink-300">{r.rsi14.toFixed(1)}</span> },
    {
      key: "trend",
      header: "Trend",
      align: "center",
      render: (r) => (
        <span className={cx("badge border", r.aboveSma200 ? "border-rise/30 text-rise" : "border-fall/30 text-fall")}>
          {r.aboveSma50 && r.aboveSma200 ? "Uptrend" : !r.aboveSma50 && !r.aboveSma200 ? "Downtrend" : "Mixed"}
        </span>
      ),
    },
    { key: "vol30", header: "Volatility", align: "right", sortValue: (r) => r.volatility30d, render: (r) => <span className="stat-tabular text-ink-300">{formatPct(r.volatility30d * 100, { signed: false })}</span> },
    { key: "pe", header: "P/E", align: "right", sortValue: (r) => r.peRatio ?? 0, render: (r) => <span className="stat-tabular text-ink-300">{r.peRatio?.toFixed(1) ?? "—"}</span> },
  ];

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-1.5">
        {(Object.entries(prebuiltScreens) as [PrebuiltKey, { label: string }][]).map(([key, s]) => (
          <button
            key={key}
            onClick={() => setPrebuilt((p) => (p === key ? null : key))}
            className={cx(
              "rounded-md border px-2.5 py-1 text-xs font-medium transition-colors",
              prebuilt === key ? "border-amber/50 bg-amber/15 text-amber" : "border-base-600 text-ink-400 hover:border-base-500 hover:text-ink-200"
            )}
          >
            {s.label}
          </button>
        ))}
      </div>

      <div className="panel flex flex-wrap items-end gap-3 p-3">
        <label className="text-xs text-ink-500">
          Search
          <input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Ticker or company" className="mt-0.5 block w-40 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100" />
        </label>
        <label className="text-xs text-ink-500">
          Sector
          <select value={sector} onChange={(e) => setSector(e.target.value as Sector | "all")} className="mt-0.5 block w-40 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100">
            <option value="all">All sectors</option>
            {SECTORS.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </label>
        <label className="text-xs text-ink-500">
          Min price
          <input type="number" value={minPrice} onChange={(e) => setMinPrice(e.target.value)} className="mt-0.5 block w-24 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100" />
        </label>
        <label className="text-xs text-ink-500">
          Max price
          <input type="number" value={maxPrice} onChange={(e) => setMaxPrice(e.target.value)} className="mt-0.5 block w-24 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100" />
        </label>
        <label className="text-xs text-ink-500">
          Max RSI
          <input type="number" value={rsiMax} onChange={(e) => setRsiMax(e.target.value)} className="mt-0.5 block w-20 rounded border border-base-600 bg-base-900 px-2 py-1 text-sm text-ink-100" />
        </label>
        <button
          onClick={() => {
            setSearch("");
            setSector("all");
            setMinPrice("");
            setMaxPrice("");
            setRsiMax("");
            setPrebuilt(null);
          }}
          className="ml-auto rounded-md border border-base-600 px-2.5 py-1 text-xs text-ink-400 hover:text-ink-200"
        >
          Reset
        </button>
      </div>

      <p className="text-xs text-ink-500">
        {filtered.length} of {initialRows.length} securities match
      </p>

      <DataTable columns={columns} rows={filtered} rowKey={(r) => r.ticker} defaultSortKey="marketCap" />
    </div>
  );
}
