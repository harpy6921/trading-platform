"use client";

import { useState } from "react";
import Link from "next/link";
import { cx, formatCurrency, formatPct, formatCompactNumber } from "@/lib/utils/format";
import type { MarketMovers, MoverEntry } from "@/lib/market-data/types";

const TABS: { key: keyof Omit<MarketMovers, "source">; label: string }[] = [
  { key: "gainers", label: "Top Gainers" },
  { key: "losers", label: "Top Losers" },
  { key: "mostActive", label: "Most Active" },
  { key: "highestVolume", label: "Highest Volume" },
];

export function MoversTable({ movers }: { movers: MarketMovers }) {
  const [tab, setTab] = useState<(typeof TABS)[number]["key"]>("gainers");
  const rows: MoverEntry[] = movers[tab];

  return (
    <div className="panel p-4 sm:p-5">
      <div className="mb-3 flex flex-wrap gap-1">
        {TABS.map((t) => (
          <button
            key={t.key}
            onClick={() => setTab(t.key)}
            className={cx(
              "rounded-md px-2.5 py-1 text-xs font-medium transition-colors",
              tab === t.key ? "bg-amber/15 text-amber" : "text-ink-500 hover:bg-base-700 hover:text-ink-300"
            )}
          >
            {t.label}
          </button>
        ))}
      </div>

      <ul className="divide-y divide-base-700">
        {rows.map((r) => (
          <li key={r.ticker}>
            <Link href={`/stock/${r.ticker}`} className="flex items-center justify-between gap-3 py-2 hover:bg-base-700/40 rounded-md px-1.5 -mx-1.5">
              <div className="min-w-0">
                <p className="font-mono text-sm font-medium text-ink-100">{r.ticker}</p>
                <p className="truncate text-xs text-ink-500">{r.companyName}</p>
              </div>
              <div className="text-right">
                <p className="stat-tabular text-sm text-ink-100">{formatCurrency(r.price)}</p>
                <p className={cx("stat-tabular text-xs font-medium", r.changePct >= 0 ? "text-rise" : "text-fall")}>
                  {formatPct(r.changePct)}
                </p>
              </div>
              <div className="w-16 text-right">
                <p className="stat-tabular text-xs text-ink-500">{formatCompactNumber(r.volume)}</p>
              </div>
            </Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
