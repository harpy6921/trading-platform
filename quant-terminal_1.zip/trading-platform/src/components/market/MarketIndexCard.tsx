"use client";

import { AreaChart, Area, ResponsiveContainer, YAxis } from "recharts";
import { ArrowUpRight, ArrowDownRight } from "lucide-react";
import { cx, formatPct } from "@/lib/utils/format";
import type { IndexQuote } from "@/lib/market-data/types";

export function MarketIndexCard({ index }: { index: IndexQuote }) {
  const positive = index.changePct >= 0;
  const color = positive ? "#2FD48C" : "#FF5C6C";

  return (
    <div className="panel panel-hover p-3.5">
      <div className="flex items-start justify-between">
        <div>
          <p className="font-mono text-[11px] uppercase tracking-wider text-ink-500">{index.symbol}</p>
          <p className="text-xs text-ink-300">{index.label}</p>
        </div>
        <span className={cx("flex items-center gap-0.5 text-xs font-medium", positive ? "text-rise" : "text-fall")}>
          {positive ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}
          {formatPct(index.changePct)}
        </span>
      </div>
      <p className="stat-tabular mt-2 text-xl font-semibold text-ink-100">
        {index.value.toLocaleString(undefined, { maximumFractionDigits: 2 })}
      </p>
      <div className="mt-1 h-10">
        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={index.intraday} margin={{ top: 2, right: 0, left: 0, bottom: 0 }}>
            <defs>
              <linearGradient id={`grad-${index.symbol}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={color} stopOpacity={0.35} />
                <stop offset="100%" stopColor={color} stopOpacity={0} />
              </linearGradient>
            </defs>
            <YAxis domain={["dataMin", "dataMax"]} hide />
            <Area type="monotone" dataKey="value" stroke={color} strokeWidth={1.5} fill={`url(#grad-${index.symbol})`} isAnimationActive={false} />
          </AreaChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
