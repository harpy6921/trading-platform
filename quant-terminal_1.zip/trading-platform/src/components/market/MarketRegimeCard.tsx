import { cx } from "@/lib/utils/format";
import type { MarketRegime } from "@/types";
import { Activity } from "lucide-react";

const REGIME_STYLES: Record<MarketRegime["label"], string> = {
  Bullish: "text-rise border-rise/30 bg-rise/10",
  Bearish: "text-fall border-fall/30 bg-fall/10",
  Neutral: "text-ink-300 border-base-500 bg-base-700",
  "High Volatility": "text-amber border-amber/30 bg-amber/10",
  Transitional: "text-ink-300 border-base-500 bg-base-700",
};

export function MarketRegimeCard({ regime }: { regime: MarketRegime }) {
  return (
    <div className="panel p-4 sm:p-5">
      <div className="mb-3 flex items-center justify-between">
        <h3 className="font-display text-sm font-semibold uppercase tracking-wider text-ink-300">
          Market Regime Detector
        </h3>
        <Activity size={15} className="text-ink-500" />
      </div>

      <span className={cx("badge border px-2.5 py-1 text-sm", REGIME_STYLES[regime.label])}>
        {regime.label.toUpperCase()}
      </span>

      <p className="mt-3 text-sm leading-relaxed text-ink-300">{regime.explanation}</p>

      <div className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
        {regime.factors.map((f) => (
          <div key={f.name} className="rounded-md border border-base-600 bg-base-900/60 p-2.5">
            <p className="text-[10px] uppercase tracking-wide text-ink-500">{f.name}</p>
            <p
              className={cx(
                "stat-tabular mt-0.5 text-sm font-medium",
                f.leaning === "bullish" ? "text-rise" : f.leaning === "bearish" ? "text-fall" : "text-ink-300"
              )}
            >
              {f.reading}
            </p>
          </div>
        ))}
      </div>

      <p className="mt-3 border-t border-base-700 pt-3 text-xs leading-relaxed text-ink-500">
        <span className="font-medium text-ink-300">Reliability note: </span>
        {regime.reliabilityNote}
      </p>
    </div>
  );
}
