export type SignalLabel = "STRONG_BUY" | "BUY" | "HOLD" | "SELL" | "STRONG_SELL";

export type RiskLevel = "Low" | "Moderate" | "Elevated" | "High";

export type TimeHorizon = "Short-term (days)" | "Swing (1-4 weeks)" | "Position (1-6 months)";

export interface FeatureSnapshot {
  price: number;
  rsi14: number | null;
  macdHistogram: number | null;
  smaTrend: "above_both" | "above_50_below_200" | "below_50_above_200" | "below_both";
  bollingerPosition: "above_upper" | "upper_half" | "lower_half" | "below_lower";
  volatility30d: number;
  volumeVsAvg: number; // ratio, 1.0 = normal
  newsSentimentScore: number; // -2..2
  sectorRelativeStrength: number; // ticker return - sector avg return, fraction
  earningsGrowthYoy: number | null;
  revenueGrowthYoy: number | null;
  peRatio: number | null;
  marketRegime: MarketRegimeLabel;
}

export interface ScenarioCase {
  label: "Bull case" | "Base case" | "Bear case";
  targetPrice: number | null;
  narrative: string;
}

export interface AISignal {
  ticker: string;
  signal: SignalLabel;
  confidence: number; // 0-100
  riskLevel: RiskLevel;
  timeHorizon: TimeHorizon;
  timestamp: string;
  modelVersion: string;
  price: number;
  reasons: string[];
  bullCase: string;
  bearCase: string;
  features: FeatureSnapshot;
  scenarios: ScenarioCase[];
  opportunityScore: number;
  riskScore: number;
}

export interface OpportunityResult {
  ticker: string;
  companyName: string;
  price: number;
  changePct: number;
  opportunityScore: number; // 0-100
  signal: SignalLabel;
  confidence: number;
  riskLevel: RiskLevel;
  explanation: string;
}

export interface RiskScanResult {
  ticker: string;
  companyName: string;
  price: number;
  changePct: number;
  riskScore: number; // 0-100
  signal: SignalLabel;
  confidence: number;
  riskLevel: RiskLevel;
  explanation: string;
}

export type MarketRegimeLabel = "Bullish" | "Bearish" | "Neutral" | "High Volatility" | "Transitional";

export interface MarketRegime {
  label: MarketRegimeLabel;
  detectedAt: string;
  explanation: string;
  factors: { name: string; reading: string; leaning: "bullish" | "bearish" | "neutral" }[];
  reliabilityNote: string;
}

export type SetupType =
  | "Potential Breakout"
  | "Potential Breakdown"
  | "Trend Reversal"
  | "Momentum Continuation"
  | "Moving-Average Crossover"
  | "Support Test"
  | "Resistance Test"
  | "Unusual Volume"
  | "Volatility Expansion";

export interface TechnicalSetup {
  ticker: string;
  companyName: string;
  setupType: SetupType;
  evidence: string[];
  detectedAt: string;
}
